.class public final La5/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ls4/l;


# static fields
.field public static final b:La5/e;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, La5/e;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La5/e;->b:La5/e;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a(Ljava/security/MessageDigest;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final b(Landroid/content/Context;Lu4/y;II)Lu4/y;
    .locals 0

    .line 1
    return-object p2
.end method
