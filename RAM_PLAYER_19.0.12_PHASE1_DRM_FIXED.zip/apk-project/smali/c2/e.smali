.class public final Lc2/e;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc2/d;

.field public final b:La2/p0;

.field public final c:I

.field public final d:I

.field public final e:J

.field public final f:Z

.field public g:I

.field public h:I

.field public i:I

.field public j:I

.field public k:I

.field public l:I

.field public m:J

.field public n:[J

.field public o:[I


# direct methods
.method public constructor <init>(ILc2/d;La2/p0;Z)V
    .locals 10

    .line 1
    iget v0, p2, Lc2/d;->d:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p2, p0, Lc2/e;->a:Lc2/d;

    .line 7
    .line 8
    iput-boolean p4, p0, Lc2/e;->f:Z

    .line 9
    .line 10
    invoke-virtual {p2}, Lc2/d;->b()I

    .line 11
    .line 12
    .line 13
    move-result p4

    .line 14
    const/4 v1, 0x2

    .line 15
    const/4 v2, 0x1

    .line 16
    if-eq p4, v2, :cond_1

    .line 17
    .line 18
    if-ne p4, v1, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v2, 0x0

    .line 22
    :cond_1
    :goto_0
    invoke-static {v2}, Landroid/support/v4/media/session/b;->g(Z)V

    .line 23
    .line 24
    .line 25
    if-ne p4, v1, :cond_2

    .line 26
    .line 27
    const/high16 v2, 0x63640000

    .line 28
    .line 29
    goto :goto_1

    .line 30
    :cond_2
    const/high16 v2, 0x62770000

    .line 31
    .line 32
    :goto_1
    div-int/lit8 v3, p1, 0xa

    .line 33
    .line 34
    rem-int/lit8 p1, p1, 0xa

    .line 35
    .line 36
    add-int/lit8 p1, p1, 0x30

    .line 37
    .line 38
    shl-int/lit8 p1, p1, 0x8

    .line 39
    .line 40
    add-int/lit8 v3, v3, 0x30

    .line 41
    .line 42
    or-int/2addr p1, v3

    .line 43
    or-int/2addr v2, p1

    .line 44
    iput v2, p0, Lc2/e;->c:I

    .line 45
    .line 46
    int-to-long v3, v0

    .line 47
    iget v2, p2, Lc2/d;->b:I

    .line 48
    .line 49
    int-to-long v5, v2

    .line 50
    const-wide/32 v7, 0xf4240

    .line 51
    .line 52
    .line 53
    mul-long/2addr v5, v7

    .line 54
    iget p2, p2, Lc2/d;->c:I

    .line 55
    .line 56
    int-to-long v7, p2

    .line 57
    sget-object p2, Ly0/k0;->a:Ljava/lang/String;

    .line 58
    .line 59
    sget-object v9, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 60
    .line 61
    invoke-static/range {v3 .. v9}, Ly0/k0;->d0(JJJLjava/math/RoundingMode;)J

    .line 62
    .line 63
    .line 64
    move-result-wide v2

    .line 65
    iput-wide v2, p0, Lc2/e;->e:J

    .line 66
    .line 67
    iput-object p3, p0, Lc2/e;->b:La2/p0;

    .line 68
    .line 69
    if-ne p4, v1, :cond_3

    .line 70
    .line 71
    const/high16 p2, 0x62640000

    .line 72
    .line 73
    or-int/2addr p1, p2

    .line 74
    goto :goto_2

    .line 75
    :cond_3
    const/4 p1, -0x1

    .line 76
    :goto_2
    iput p1, p0, Lc2/e;->d:I

    .line 77
    .line 78
    const-wide/16 p1, -0x1

    .line 79
    .line 80
    iput-wide p1, p0, Lc2/e;->m:J

    .line 81
    .line 82
    const/16 p1, 0x200

    .line 83
    .line 84
    new-array p2, p1, [J

    .line 85
    .line 86
    iput-object p2, p0, Lc2/e;->n:[J

    .line 87
    .line 88
    new-array p1, p1, [I

    .line 89
    .line 90
    iput-object p1, p0, Lc2/e;->o:[I

    .line 91
    .line 92
    iput v0, p0, Lc2/e;->g:I

    .line 93
    .line 94
    return-void
.end method


# virtual methods
.method public final a(I)La2/i0;
    .locals 7

    .line 1
    new-instance v0, La2/i0;

    .line 2
    .line 3
    iget-object v1, p0, Lc2/e;->o:[I

    .line 4
    .line 5
    aget v1, v1, p1

    .line 6
    .line 7
    int-to-long v1, v1

    .line 8
    iget-wide v3, p0, Lc2/e;->e:J

    .line 9
    .line 10
    const/4 v5, 0x1

    .line 11
    int-to-long v5, v5

    .line 12
    mul-long/2addr v3, v5

    .line 13
    iget v5, p0, Lc2/e;->g:I

    .line 14
    .line 15
    int-to-long v5, v5

    .line 16
    div-long/2addr v3, v5

    .line 17
    mul-long/2addr v3, v1

    .line 18
    iget-object v1, p0, Lc2/e;->n:[J

    .line 19
    .line 20
    aget-wide v5, v1, p1

    .line 21
    .line 22
    invoke-direct {v0, v3, v4, v5, v6}, La2/i0;-><init>(JJ)V

    .line 23
    .line 24
    .line 25
    return-object v0
.end method

.method public final b(J)La2/g0;
    .locals 5

    .line 1
    iget v0, p0, Lc2/e;->l:I

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance p1, La2/g0;

    .line 6
    .line 7
    new-instance p2, La2/i0;

    .line 8
    .line 9
    const-wide/16 v0, 0x0

    .line 10
    .line 11
    iget-wide v2, p0, Lc2/e;->m:J

    .line 12
    .line 13
    invoke-direct {p2, v0, v1, v2, v3}, La2/i0;-><init>(JJ)V

    .line 14
    .line 15
    .line 16
    invoke-direct {p1, p2, p2}, La2/g0;-><init>(La2/i0;La2/i0;)V

    .line 17
    .line 18
    .line 19
    return-object p1

    .line 20
    :cond_0
    iget-wide v0, p0, Lc2/e;->e:J

    .line 21
    .line 22
    const/4 v2, 0x1

    .line 23
    int-to-long v3, v2

    .line 24
    mul-long/2addr v0, v3

    .line 25
    iget v3, p0, Lc2/e;->g:I

    .line 26
    .line 27
    int-to-long v3, v3

    .line 28
    div-long/2addr v0, v3

    .line 29
    div-long/2addr p1, v0

    .line 30
    long-to-int p1, p1

    .line 31
    iget-object p2, p0, Lc2/e;->o:[I

    .line 32
    .line 33
    invoke-static {p2, p1, v2, v2}, Ly0/k0;->e([IIZZ)I

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    iget-object v0, p0, Lc2/e;->o:[I

    .line 38
    .line 39
    aget v0, v0, p2

    .line 40
    .line 41
    if-ne v0, p1, :cond_1

    .line 42
    .line 43
    new-instance p1, La2/g0;

    .line 44
    .line 45
    invoke-virtual {p0, p2}, Lc2/e;->a(I)La2/i0;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    invoke-direct {p1, p2, p2}, La2/g0;-><init>(La2/i0;La2/i0;)V

    .line 50
    .line 51
    .line 52
    return-object p1

    .line 53
    :cond_1
    invoke-virtual {p0, p2}, Lc2/e;->a(I)La2/i0;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    add-int/2addr p2, v2

    .line 58
    iget-object v0, p0, Lc2/e;->n:[J

    .line 59
    .line 60
    array-length v0, v0

    .line 61
    if-ge p2, v0, :cond_2

    .line 62
    .line 63
    new-instance v0, La2/g0;

    .line 64
    .line 65
    invoke-virtual {p0, p2}, Lc2/e;->a(I)La2/i0;

    .line 66
    .line 67
    .line 68
    move-result-object p2

    .line 69
    invoke-direct {v0, p1, p2}, La2/g0;-><init>(La2/i0;La2/i0;)V

    .line 70
    .line 71
    .line 72
    return-object v0

    .line 73
    :cond_2
    new-instance p2, La2/g0;

    .line 74
    .line 75
    invoke-direct {p2, p1, p1}, La2/g0;-><init>(La2/i0;La2/i0;)V

    .line 76
    .line 77
    .line 78
    return-object p2
.end method
