.class public final Lc/m;
.super La7/i;
.source "SourceFile"

# interfaces
.implements Lz6/a;


# instance fields
.field public final synthetic l:I

.field public final synthetic m:Lc/r;


# direct methods
.method public synthetic constructor <init>(Lc/r;I)V
    .locals 0

    .line 1
    iput p2, p0, Lc/m;->l:I

    iput-object p1, p0, Lc/m;->m:Lc/r;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, La7/i;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lc/m;->l:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lc/m;->m:Lc/r;

    .line 7
    .line 8
    invoke-virtual {v0}, Lc/r;->a()V

    .line 9
    .line 10
    .line 11
    sget-object v0, Ln6/j;->a:Ln6/j;

    .line 12
    .line 13
    return-object v0

    .line 14
    :pswitch_0
    iget-object v0, p0, Lc/m;->m:Lc/r;

    .line 15
    .line 16
    invoke-virtual {v0}, Lc/r;->b()V

    .line 17
    .line 18
    .line 19
    sget-object v0, Ln6/j;->a:Ln6/j;

    .line 20
    .line 21
    return-object v0

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
