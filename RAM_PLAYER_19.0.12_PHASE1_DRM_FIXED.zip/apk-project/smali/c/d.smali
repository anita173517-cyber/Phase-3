.class public final synthetic Lc/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ld/b;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Li/k;


# direct methods
.method public synthetic constructor <init>(Li/k;I)V
    .locals 0

    .line 1
    iput p2, p0, Lc/d;->a:I

    iput-object p1, p0, Lc/d;->b:Li/k;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lc/d;->a:I

    .line 4
    .line 5
    packed-switch v1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lc/d;->b:Li/k;

    .line 9
    .line 10
    iget-object v1, v1, Li/k;->C:Ll6/b;

    .line 11
    .line 12
    iget-object v1, v1, Ll6/b;->k:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Lr0/f;

    .line 15
    .line 16
    iget-object v2, v1, Lr0/f;->n:Li/k;

    .line 17
    .line 18
    iget-object v3, v1, Lr0/f;->m:Lr0/o;

    .line 19
    .line 20
    iget-object v4, v3, Lr0/o;->c:Ll4/i;

    .line 21
    .line 22
    iget-object v5, v3, Lr0/o;->c:Ll4/i;

    .line 23
    .line 24
    iget-object v6, v3, Lr0/o;->r:Lr0/f;

    .line 25
    .line 26
    if-nez v6, :cond_20

    .line 27
    .line 28
    iput-object v1, v3, Lr0/o;->r:Lr0/f;

    .line 29
    .line 30
    iput-object v1, v3, Lr0/o;->s:Lr0/f;

    .line 31
    .line 32
    iget-object v6, v3, Lr0/o;->k:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 33
    .line 34
    invoke-virtual {v6, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    iget-object v1, v2, Lc/k;->q:Lc/r;

    .line 38
    .line 39
    iput-object v1, v3, Lr0/o;->f:Lc/r;

    .line 40
    .line 41
    iget-object v6, v3, Lr0/o;->g:Lr0/k;

    .line 42
    .line 43
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    const-string v7, "onBackPressedCallback"

    .line 47
    .line 48
    invoke-static {v6, v7}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    iget-object v7, v2, Li/k;->D:Landroidx/lifecycle/t;

    .line 52
    .line 53
    iget-object v8, v7, Landroidx/lifecycle/t;->d:Landroidx/lifecycle/k;

    .line 54
    .line 55
    sget-object v9, Landroidx/lifecycle/k;->k:Landroidx/lifecycle/k;

    .line 56
    .line 57
    if-ne v8, v9, :cond_0

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_0
    new-instance v8, Lc/p;

    .line 61
    .line 62
    invoke-direct {v8, v1, v7, v6}, Lc/p;-><init>(Lc/r;Landroidx/lifecycle/t;Lr0/k;)V

    .line 63
    .line 64
    .line 65
    iget-object v7, v6, Lr0/k;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 66
    .line 67
    invoke-virtual {v7, v8}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 71
    .line 72
    const/16 v8, 0x21

    .line 73
    .line 74
    if-lt v7, v8, :cond_1

    .line 75
    .line 76
    invoke-virtual {v1}, Lc/r;->b()V

    .line 77
    .line 78
    .line 79
    iget-object v1, v1, Lc/r;->c:Lc/m;

    .line 80
    .line 81
    iput-object v1, v6, Lr0/k;->c:Lz6/a;

    .line 82
    .line 83
    :cond_1
    :goto_0
    invoke-virtual {v2}, Lc/k;->f()Landroidx/lifecycle/p0;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    new-instance v2, Landroidx/lifecycle/c0;

    .line 88
    .line 89
    sget-object v6, Lr0/q;->f:Lp1/h0;

    .line 90
    .line 91
    invoke-direct {v2, v1, v6}, Landroidx/lifecycle/c0;-><init>(Landroidx/lifecycle/p0;Landroidx/lifecycle/o0;)V

    .line 92
    .line 93
    .line 94
    const-class v1, Lr0/q;

    .line 95
    .line 96
    invoke-virtual {v2, v1}, Landroidx/lifecycle/c0;->v(Ljava/lang/Class;)Landroidx/lifecycle/n0;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    check-cast v1, Lr0/q;

    .line 101
    .line 102
    iput-object v1, v3, Lr0/o;->E:Lr0/q;

    .line 103
    .line 104
    iget-object v1, v3, Lr0/o;->E:Lr0/q;

    .line 105
    .line 106
    iput-object v1, v4, Ll4/i;->n:Ljava/lang/Object;

    .line 107
    .line 108
    iget-object v1, v4, Ll4/i;->l:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v1, Ljava/util/HashMap;

    .line 111
    .line 112
    iget-object v2, v4, Ll4/i;->m:Ljava/lang/Object;

    .line 113
    .line 114
    check-cast v2, Ljava/util/HashMap;

    .line 115
    .line 116
    iget-object v6, v3, Lr0/o;->r:Lr0/f;

    .line 117
    .line 118
    if-eqz v6, :cond_19

    .line 119
    .line 120
    invoke-virtual {v6}, Lr0/f;->a()Lk3/n2;

    .line 121
    .line 122
    .line 123
    move-result-object v6

    .line 124
    new-instance v7, Lc/c;

    .line 125
    .line 126
    const/4 v8, 0x2

    .line 127
    invoke-direct {v7, v8, v3}, Lc/c;-><init>(ILjava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    const-string v8, "android:support:fragments"

    .line 131
    .line 132
    invoke-virtual {v6, v8, v7}, Lk3/n2;->e(Ljava/lang/String;Lt3/d;)V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v6, v8}, Lk3/n2;->d(Ljava/lang/String;)Landroid/os/Bundle;

    .line 136
    .line 137
    .line 138
    move-result-object v6

    .line 139
    if-eqz v6, :cond_19

    .line 140
    .line 141
    invoke-virtual {v6}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 142
    .line 143
    .line 144
    move-result-object v7

    .line 145
    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 146
    .line 147
    .line 148
    move-result-object v7

    .line 149
    :cond_2
    :goto_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 150
    .line 151
    .line 152
    move-result v8

    .line 153
    if-eqz v8, :cond_3

    .line 154
    .line 155
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v8

    .line 159
    check-cast v8, Ljava/lang/String;

    .line 160
    .line 161
    const-string v9, "result_"

    .line 162
    .line 163
    invoke-virtual {v8, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 164
    .line 165
    .line 166
    move-result v9

    .line 167
    if-eqz v9, :cond_2

    .line 168
    .line 169
    invoke-virtual {v6, v8}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 170
    .line 171
    .line 172
    move-result-object v9

    .line 173
    if-eqz v9, :cond_2

    .line 174
    .line 175
    iget-object v10, v3, Lr0/o;->r:Lr0/f;

    .line 176
    .line 177
    iget-object v10, v10, Lr0/f;->k:Li/k;

    .line 178
    .line 179
    invoke-virtual {v10}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 180
    .line 181
    .line 182
    move-result-object v10

    .line 183
    invoke-virtual {v9, v10}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    .line 184
    .line 185
    .line 186
    const/4 v10, 0x7

    .line 187
    invoke-virtual {v8, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v8

    .line 191
    iget-object v10, v3, Lr0/o;->j:Ljava/util/Map;

    .line 192
    .line 193
    invoke-interface {v10, v8, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    goto :goto_1

    .line 197
    :cond_3
    new-instance v7, Ljava/util/ArrayList;

    .line 198
    .line 199
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v6}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 203
    .line 204
    .line 205
    move-result-object v8

    .line 206
    invoke-interface {v8}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 207
    .line 208
    .line 209
    move-result-object v8

    .line 210
    :cond_4
    :goto_2
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 211
    .line 212
    .line 213
    move-result v9

    .line 214
    const-string v10, "state"

    .line 215
    .line 216
    if-eqz v9, :cond_5

    .line 217
    .line 218
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v9

    .line 222
    check-cast v9, Ljava/lang/String;

    .line 223
    .line 224
    const-string v11, "fragment_"

    .line 225
    .line 226
    invoke-virtual {v9, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 227
    .line 228
    .line 229
    move-result v11

    .line 230
    if-eqz v11, :cond_4

    .line 231
    .line 232
    invoke-virtual {v6, v9}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 233
    .line 234
    .line 235
    move-result-object v9

    .line 236
    if-eqz v9, :cond_4

    .line 237
    .line 238
    iget-object v11, v3, Lr0/o;->r:Lr0/f;

    .line 239
    .line 240
    iget-object v11, v11, Lr0/f;->k:Li/k;

    .line 241
    .line 242
    invoke-virtual {v11}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 243
    .line 244
    .line 245
    move-result-object v11

    .line 246
    invoke-virtual {v9, v11}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    .line 247
    .line 248
    .line 249
    invoke-virtual {v9, v10}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 250
    .line 251
    .line 252
    move-result-object v9

    .line 253
    check-cast v9, Lr0/r;

    .line 254
    .line 255
    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    goto :goto_2

    .line 259
    :cond_5
    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    .line 260
    .line 261
    .line 262
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 263
    .line 264
    .line 265
    move-result v8

    .line 266
    const/4 v11, 0x0

    .line 267
    :goto_3
    if-ge v11, v8, :cond_6

    .line 268
    .line 269
    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 270
    .line 271
    .line 272
    move-result-object v12

    .line 273
    add-int/lit8 v11, v11, 0x1

    .line 274
    .line 275
    check-cast v12, Lr0/r;

    .line 276
    .line 277
    iget-object v13, v12, Lr0/r;->l:Ljava/lang/String;

    .line 278
    .line 279
    invoke-virtual {v2, v13, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    goto :goto_3

    .line 283
    :cond_6
    invoke-virtual {v6, v10}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 284
    .line 285
    .line 286
    move-result-object v6

    .line 287
    check-cast v6, Lr0/p;

    .line 288
    .line 289
    if-nez v6, :cond_7

    .line 290
    .line 291
    goto/16 :goto_d

    .line 292
    .line 293
    :cond_7
    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    .line 294
    .line 295
    .line 296
    iget-object v7, v6, Lr0/p;->k:Ljava/util/ArrayList;

    .line 297
    .line 298
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 299
    .line 300
    .line 301
    move-result v8

    .line 302
    const/4 v10, 0x0

    .line 303
    :goto_4
    const/4 v11, 0x0

    .line 304
    if-ge v10, v8, :cond_b

    .line 305
    .line 306
    invoke-virtual {v7, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object v12

    .line 310
    add-int/lit8 v10, v10, 0x1

    .line 311
    .line 312
    check-cast v12, Ljava/lang/String;

    .line 313
    .line 314
    invoke-virtual {v2, v12}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 315
    .line 316
    .line 317
    move-result-object v12

    .line 318
    check-cast v12, Lr0/r;

    .line 319
    .line 320
    if-nez v12, :cond_8

    .line 321
    .line 322
    goto :goto_4

    .line 323
    :cond_8
    iget-object v1, v3, Lr0/o;->E:Lr0/q;

    .line 324
    .line 325
    iget-object v2, v12, Lr0/r;->l:Ljava/lang/String;

    .line 326
    .line 327
    iget-object v1, v1, Lr0/q;->b:Ljava/util/HashMap;

    .line 328
    .line 329
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 330
    .line 331
    .line 332
    move-result-object v1

    .line 333
    if-nez v1, :cond_a

    .line 334
    .line 335
    iget-object v1, v3, Lr0/o;->r:Lr0/f;

    .line 336
    .line 337
    iget-object v1, v1, Lr0/f;->k:Li/k;

    .line 338
    .line 339
    invoke-virtual {v1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 340
    .line 341
    .line 342
    move-result-object v1

    .line 343
    iget-object v2, v3, Lr0/o;->t:Lr0/m;

    .line 344
    .line 345
    iget-object v3, v12, Lr0/r;->k:Ljava/lang/String;

    .line 346
    .line 347
    invoke-virtual {v2, v3}, Lr0/m;->a(Ljava/lang/String;)V

    .line 348
    .line 349
    .line 350
    iget-object v2, v12, Lr0/r;->t:Landroid/os/Bundle;

    .line 351
    .line 352
    if-eqz v2, :cond_9

    .line 353
    .line 354
    invoke-virtual {v2, v1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    .line 355
    .line 356
    .line 357
    :cond_9
    throw v11

    .line 358
    :cond_a
    new-instance v1, Ljava/lang/ClassCastException;

    .line 359
    .line 360
    invoke-direct {v1}, Ljava/lang/ClassCastException;-><init>()V

    .line 361
    .line 362
    .line 363
    throw v1

    .line 364
    :cond_b
    iget-object v2, v3, Lr0/o;->E:Lr0/q;

    .line 365
    .line 366
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 367
    .line 368
    .line 369
    new-instance v7, Ljava/util/ArrayList;

    .line 370
    .line 371
    iget-object v2, v2, Lr0/q;->b:Ljava/util/HashMap;

    .line 372
    .line 373
    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 374
    .line 375
    .line 376
    move-result-object v2

    .line 377
    invoke-direct {v7, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 378
    .line 379
    .line 380
    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 381
    .line 382
    .line 383
    move-result-object v2

    .line 384
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 385
    .line 386
    .line 387
    move-result v7

    .line 388
    if-nez v7, :cond_18

    .line 389
    .line 390
    iget-object v2, v6, Lr0/p;->l:Ljava/util/ArrayList;

    .line 391
    .line 392
    iget-object v4, v4, Ll4/i;->k:Ljava/lang/Object;

    .line 393
    .line 394
    check-cast v4, Ljava/util/ArrayList;

    .line 395
    .line 396
    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 397
    .line 398
    .line 399
    if-eqz v2, :cond_d

    .line 400
    .line 401
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 402
    .line 403
    .line 404
    move-result-object v2

    .line 405
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 406
    .line 407
    .line 408
    move-result v4

    .line 409
    if-nez v4, :cond_c

    .line 410
    .line 411
    goto :goto_5

    .line 412
    :cond_c
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    move-result-object v2

    .line 416
    check-cast v2, Ljava/lang/String;

    .line 417
    .line 418
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 419
    .line 420
    .line 421
    move-result-object v1

    .line 422
    invoke-static {v1}, Lr0/u;->a(Ljava/lang/Object;)V

    .line 423
    .line 424
    .line 425
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 426
    .line 427
    const-string v3, "No instantiated fragment for ("

    .line 428
    .line 429
    const-string v4, ")"

    .line 430
    .line 431
    invoke-static {v3, v2, v4}, Lq3/e;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 432
    .line 433
    .line 434
    move-result-object v2

    .line 435
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 436
    .line 437
    .line 438
    throw v1

    .line 439
    :cond_d
    :goto_5
    iget-object v1, v6, Lr0/p;->m:[Lr0/b;

    .line 440
    .line 441
    if-eqz v1, :cond_15

    .line 442
    .line 443
    new-instance v1, Ljava/util/ArrayList;

    .line 444
    .line 445
    iget-object v2, v6, Lr0/p;->m:[Lr0/b;

    .line 446
    .line 447
    array-length v2, v2

    .line 448
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 449
    .line 450
    .line 451
    iput-object v1, v3, Lr0/o;->d:Ljava/util/ArrayList;

    .line 452
    .line 453
    const/4 v1, 0x0

    .line 454
    :goto_6
    iget-object v2, v6, Lr0/p;->m:[Lr0/b;

    .line 455
    .line 456
    array-length v4, v2

    .line 457
    if-ge v1, v4, :cond_14

    .line 458
    .line 459
    aget-object v2, v2, v1

    .line 460
    .line 461
    iget-object v4, v2, Lr0/b;->l:Ljava/util/ArrayList;

    .line 462
    .line 463
    new-instance v7, Lr0/a;

    .line 464
    .line 465
    invoke-direct {v7, v3}, Lr0/a;-><init>(Lr0/o;)V

    .line 466
    .line 467
    .line 468
    iget-object v8, v2, Lr0/b;->k:[I

    .line 469
    .line 470
    const/4 v10, 0x0

    .line 471
    const/4 v11, 0x0

    .line 472
    :goto_7
    array-length v12, v8

    .line 473
    const/4 v14, 0x1

    .line 474
    if-ge v10, v12, :cond_10

    .line 475
    .line 476
    new-instance v12, Lr0/s;

    .line 477
    .line 478
    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    .line 479
    .line 480
    .line 481
    add-int/lit8 v15, v10, 0x1

    .line 482
    .line 483
    const/16 v16, 0x2

    .line 484
    .line 485
    aget v13, v8, v10

    .line 486
    .line 487
    iput v13, v12, Lr0/s;->a:I

    .line 488
    .line 489
    invoke-static/range {v16 .. v16}, Lr0/o;->h(I)Z

    .line 490
    .line 491
    .line 492
    move-result v13

    .line 493
    if-eqz v13, :cond_e

    .line 494
    .line 495
    invoke-static {v7}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 496
    .line 497
    .line 498
    aget v13, v8, v15

    .line 499
    .line 500
    :cond_e
    invoke-static {}, Landroidx/lifecycle/k;->values()[Landroidx/lifecycle/k;

    .line 501
    .line 502
    .line 503
    move-result-object v13

    .line 504
    iget-object v9, v2, Lr0/b;->m:[I

    .line 505
    .line 506
    aget v9, v9, v11

    .line 507
    .line 508
    aget-object v9, v13, v9

    .line 509
    .line 510
    iput-object v9, v12, Lr0/s;->g:Landroidx/lifecycle/k;

    .line 511
    .line 512
    invoke-static {}, Landroidx/lifecycle/k;->values()[Landroidx/lifecycle/k;

    .line 513
    .line 514
    .line 515
    move-result-object v9

    .line 516
    iget-object v13, v2, Lr0/b;->n:[I

    .line 517
    .line 518
    aget v13, v13, v11

    .line 519
    .line 520
    aget-object v9, v9, v13

    .line 521
    .line 522
    iput-object v9, v12, Lr0/s;->h:Landroidx/lifecycle/k;

    .line 523
    .line 524
    add-int/lit8 v9, v10, 0x2

    .line 525
    .line 526
    aget v13, v8, v15

    .line 527
    .line 528
    if-eqz v13, :cond_f

    .line 529
    .line 530
    goto :goto_8

    .line 531
    :cond_f
    const/4 v14, 0x0

    .line 532
    :goto_8
    iput-boolean v14, v12, Lr0/s;->b:Z

    .line 533
    .line 534
    add-int/lit8 v13, v10, 0x3

    .line 535
    .line 536
    aget v9, v8, v9

    .line 537
    .line 538
    iput v9, v12, Lr0/s;->c:I

    .line 539
    .line 540
    add-int/lit8 v14, v10, 0x4

    .line 541
    .line 542
    aget v13, v8, v13

    .line 543
    .line 544
    iput v13, v12, Lr0/s;->d:I

    .line 545
    .line 546
    add-int/lit8 v15, v10, 0x5

    .line 547
    .line 548
    aget v14, v8, v14

    .line 549
    .line 550
    iput v14, v12, Lr0/s;->e:I

    .line 551
    .line 552
    add-int/lit8 v10, v10, 0x6

    .line 553
    .line 554
    aget v15, v8, v15

    .line 555
    .line 556
    iput v15, v12, Lr0/s;->f:I

    .line 557
    .line 558
    iput v9, v7, Lr0/a;->b:I

    .line 559
    .line 560
    iput v13, v7, Lr0/a;->c:I

    .line 561
    .line 562
    iput v14, v7, Lr0/a;->d:I

    .line 563
    .line 564
    iput v15, v7, Lr0/a;->e:I

    .line 565
    .line 566
    iget-object v9, v7, Lr0/a;->a:Ljava/util/ArrayList;

    .line 567
    .line 568
    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 569
    .line 570
    .line 571
    iget v9, v7, Lr0/a;->b:I

    .line 572
    .line 573
    iput v9, v12, Lr0/s;->c:I

    .line 574
    .line 575
    iget v9, v7, Lr0/a;->c:I

    .line 576
    .line 577
    iput v9, v12, Lr0/s;->d:I

    .line 578
    .line 579
    iget v9, v7, Lr0/a;->d:I

    .line 580
    .line 581
    iput v9, v12, Lr0/s;->e:I

    .line 582
    .line 583
    iget v9, v7, Lr0/a;->e:I

    .line 584
    .line 585
    iput v9, v12, Lr0/s;->f:I

    .line 586
    .line 587
    add-int/lit8 v11, v11, 0x1

    .line 588
    .line 589
    goto :goto_7

    .line 590
    :cond_10
    const/16 v16, 0x2

    .line 591
    .line 592
    iget v8, v2, Lr0/b;->o:I

    .line 593
    .line 594
    iput v8, v7, Lr0/a;->f:I

    .line 595
    .line 596
    iget-object v8, v2, Lr0/b;->p:Ljava/lang/String;

    .line 597
    .line 598
    iput-object v8, v7, Lr0/a;->h:Ljava/lang/String;

    .line 599
    .line 600
    iput-boolean v14, v7, Lr0/a;->g:Z

    .line 601
    .line 602
    iget v8, v2, Lr0/b;->r:I

    .line 603
    .line 604
    iput v8, v7, Lr0/a;->i:I

    .line 605
    .line 606
    iget-object v8, v2, Lr0/b;->s:Ljava/lang/CharSequence;

    .line 607
    .line 608
    iput-object v8, v7, Lr0/a;->j:Ljava/lang/CharSequence;

    .line 609
    .line 610
    iget v8, v2, Lr0/b;->t:I

    .line 611
    .line 612
    iput v8, v7, Lr0/a;->k:I

    .line 613
    .line 614
    iget-object v8, v2, Lr0/b;->u:Ljava/lang/CharSequence;

    .line 615
    .line 616
    iput-object v8, v7, Lr0/a;->l:Ljava/lang/CharSequence;

    .line 617
    .line 618
    iget-object v8, v2, Lr0/b;->v:Ljava/util/ArrayList;

    .line 619
    .line 620
    iput-object v8, v7, Lr0/a;->m:Ljava/util/ArrayList;

    .line 621
    .line 622
    iget-object v8, v2, Lr0/b;->w:Ljava/util/ArrayList;

    .line 623
    .line 624
    iput-object v8, v7, Lr0/a;->n:Ljava/util/ArrayList;

    .line 625
    .line 626
    iget-boolean v8, v2, Lr0/b;->x:Z

    .line 627
    .line 628
    iput-boolean v8, v7, Lr0/a;->o:Z

    .line 629
    .line 630
    iget v2, v2, Lr0/b;->q:I

    .line 631
    .line 632
    iput v2, v7, Lr0/a;->q:I

    .line 633
    .line 634
    const/4 v2, 0x0

    .line 635
    :goto_9
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 636
    .line 637
    .line 638
    move-result v8

    .line 639
    if-ge v2, v8, :cond_12

    .line 640
    .line 641
    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 642
    .line 643
    .line 644
    move-result-object v8

    .line 645
    check-cast v8, Ljava/lang/String;

    .line 646
    .line 647
    if-eqz v8, :cond_11

    .line 648
    .line 649
    iget-object v9, v7, Lr0/a;->a:Ljava/util/ArrayList;

    .line 650
    .line 651
    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 652
    .line 653
    .line 654
    move-result-object v9

    .line 655
    check-cast v9, Lr0/s;

    .line 656
    .line 657
    iget-object v10, v5, Ll4/i;->l:Ljava/lang/Object;

    .line 658
    .line 659
    check-cast v10, Ljava/util/HashMap;

    .line 660
    .line 661
    invoke-virtual {v10, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 662
    .line 663
    .line 664
    move-result-object v8

    .line 665
    invoke-static {v8}, Lr0/u;->a(Ljava/lang/Object;)V

    .line 666
    .line 667
    .line 668
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 669
    .line 670
    .line 671
    :cond_11
    add-int/lit8 v2, v2, 0x1

    .line 672
    .line 673
    goto :goto_9

    .line 674
    :cond_12
    invoke-virtual {v7}, Lr0/a;->a()V

    .line 675
    .line 676
    .line 677
    invoke-static/range {v16 .. v16}, Lr0/o;->h(I)Z

    .line 678
    .line 679
    .line 680
    move-result v2

    .line 681
    if-eqz v2, :cond_13

    .line 682
    .line 683
    invoke-virtual {v7}, Lr0/a;->toString()Ljava/lang/String;

    .line 684
    .line 685
    .line 686
    new-instance v2, Lr0/t;

    .line 687
    .line 688
    invoke-direct {v2}, Lr0/t;-><init>()V

    .line 689
    .line 690
    .line 691
    new-instance v4, Ljava/io/PrintWriter;

    .line 692
    .line 693
    invoke-direct {v4, v2}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    .line 694
    .line 695
    .line 696
    const-string v2, "  "

    .line 697
    .line 698
    const/4 v8, 0x0

    .line 699
    invoke-virtual {v7, v2, v4, v8}, Lr0/a;->b(Ljava/lang/String;Ljava/io/PrintWriter;Z)V

    .line 700
    .line 701
    .line 702
    invoke-virtual {v4}, Ljava/io/PrintWriter;->close()V

    .line 703
    .line 704
    .line 705
    goto :goto_a

    .line 706
    :cond_13
    const/4 v8, 0x0

    .line 707
    :goto_a
    iget-object v2, v3, Lr0/o;->d:Ljava/util/ArrayList;

    .line 708
    .line 709
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 710
    .line 711
    .line 712
    add-int/lit8 v1, v1, 0x1

    .line 713
    .line 714
    goto/16 :goto_6

    .line 715
    .line 716
    :cond_14
    const/4 v8, 0x0

    .line 717
    goto :goto_b

    .line 718
    :cond_15
    const/4 v8, 0x0

    .line 719
    iput-object v11, v3, Lr0/o;->d:Ljava/util/ArrayList;

    .line 720
    .line 721
    :goto_b
    iget-object v1, v3, Lr0/o;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 722
    .line 723
    iget v2, v6, Lr0/p;->n:I

    .line 724
    .line 725
    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    .line 726
    .line 727
    .line 728
    iget-object v1, v6, Lr0/p;->o:Ljava/lang/String;

    .line 729
    .line 730
    if-eqz v1, :cond_16

    .line 731
    .line 732
    iget-object v2, v5, Ll4/i;->l:Ljava/lang/Object;

    .line 733
    .line 734
    check-cast v2, Ljava/util/HashMap;

    .line 735
    .line 736
    invoke-virtual {v2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 737
    .line 738
    .line 739
    move-result-object v1

    .line 740
    invoke-static {v1}, Lr0/u;->a(Ljava/lang/Object;)V

    .line 741
    .line 742
    .line 743
    :cond_16
    iget-object v1, v6, Lr0/p;->p:Ljava/util/ArrayList;

    .line 744
    .line 745
    if-eqz v1, :cond_17

    .line 746
    .line 747
    move v9, v8

    .line 748
    :goto_c
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 749
    .line 750
    .line 751
    move-result v2

    .line 752
    if-ge v9, v2, :cond_17

    .line 753
    .line 754
    iget-object v2, v3, Lr0/o;->i:Ljava/util/Map;

    .line 755
    .line 756
    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 757
    .line 758
    .line 759
    move-result-object v4

    .line 760
    check-cast v4, Ljava/lang/String;

    .line 761
    .line 762
    iget-object v5, v6, Lr0/p;->q:Ljava/util/ArrayList;

    .line 763
    .line 764
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 765
    .line 766
    .line 767
    move-result-object v5

    .line 768
    check-cast v5, Lr0/c;

    .line 769
    .line 770
    invoke-interface {v2, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 771
    .line 772
    .line 773
    add-int/lit8 v9, v9, 0x1

    .line 774
    .line 775
    goto :goto_c

    .line 776
    :cond_17
    new-instance v1, Ljava/util/ArrayDeque;

    .line 777
    .line 778
    iget-object v2, v6, Lr0/p;->r:Ljava/util/ArrayList;

    .line 779
    .line 780
    invoke-direct {v1, v2}, Ljava/util/ArrayDeque;-><init>(Ljava/util/Collection;)V

    .line 781
    .line 782
    .line 783
    iput-object v1, v3, Lr0/o;->x:Ljava/util/ArrayDeque;

    .line 784
    .line 785
    goto :goto_d

    .line 786
    :cond_18
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 787
    .line 788
    .line 789
    move-result-object v1

    .line 790
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 791
    .line 792
    .line 793
    new-instance v1, Ljava/lang/ClassCastException;

    .line 794
    .line 795
    invoke-direct {v1}, Ljava/lang/ClassCastException;-><init>()V

    .line 796
    .line 797
    .line 798
    throw v1

    .line 799
    :cond_19
    :goto_d
    iget-object v1, v3, Lr0/o;->r:Lr0/f;

    .line 800
    .line 801
    if-eqz v1, :cond_1a

    .line 802
    .line 803
    iget-object v1, v1, Lr0/f;->n:Li/k;

    .line 804
    .line 805
    iget-object v1, v1, Lc/k;->u:Lc/f;

    .line 806
    .line 807
    new-instance v2, Lf/a;

    .line 808
    .line 809
    const/4 v4, 0x2

    .line 810
    invoke-direct {v2, v4}, Lf/a;-><init>(I)V

    .line 811
    .line 812
    .line 813
    new-instance v4, Lr0/j;

    .line 814
    .line 815
    const/4 v5, 0x1

    .line 816
    invoke-direct {v4, v3, v5}, Lr0/j;-><init>(Lr0/o;I)V

    .line 817
    .line 818
    .line 819
    const-string v5, "FragmentManager:StartActivityForResult"

    .line 820
    .line 821
    invoke-virtual {v1, v5, v2, v4}, Lc/f;->c(Ljava/lang/String;Lw0/h;Le/b;)Le/e;

    .line 822
    .line 823
    .line 824
    move-result-object v2

    .line 825
    iput-object v2, v3, Lr0/o;->u:Le/e;

    .line 826
    .line 827
    new-instance v2, Lf/a;

    .line 828
    .line 829
    const/4 v4, 0x3

    .line 830
    invoke-direct {v2, v4}, Lf/a;-><init>(I)V

    .line 831
    .line 832
    .line 833
    new-instance v4, Lr0/j;

    .line 834
    .line 835
    const/4 v5, 0x2

    .line 836
    invoke-direct {v4, v3, v5}, Lr0/j;-><init>(Lr0/o;I)V

    .line 837
    .line 838
    .line 839
    const-string v5, "FragmentManager:StartIntentSenderForResult"

    .line 840
    .line 841
    invoke-virtual {v1, v5, v2, v4}, Lc/f;->c(Ljava/lang/String;Lw0/h;Le/b;)Le/e;

    .line 842
    .line 843
    .line 844
    move-result-object v2

    .line 845
    iput-object v2, v3, Lr0/o;->v:Le/e;

    .line 846
    .line 847
    new-instance v2, Lf/a;

    .line 848
    .line 849
    const/4 v4, 0x1

    .line 850
    invoke-direct {v2, v4}, Lf/a;-><init>(I)V

    .line 851
    .line 852
    .line 853
    new-instance v4, Lr0/j;

    .line 854
    .line 855
    const/4 v5, 0x0

    .line 856
    invoke-direct {v4, v3, v5}, Lr0/j;-><init>(Lr0/o;I)V

    .line 857
    .line 858
    .line 859
    const-string v5, "FragmentManager:RequestPermissions"

    .line 860
    .line 861
    invoke-virtual {v1, v5, v2, v4}, Lc/f;->c(Ljava/lang/String;Lw0/h;Le/b;)Le/e;

    .line 862
    .line 863
    .line 864
    move-result-object v1

    .line 865
    iput-object v1, v3, Lr0/o;->w:Le/e;

    .line 866
    .line 867
    :cond_1a
    iget-object v1, v3, Lr0/o;->r:Lr0/f;

    .line 868
    .line 869
    if-eqz v1, :cond_1b

    .line 870
    .line 871
    iget-object v2, v3, Lr0/o;->l:Lr0/i;

    .line 872
    .line 873
    iget-object v1, v1, Lr0/f;->n:Li/k;

    .line 874
    .line 875
    iget-object v1, v1, Lc/k;->v:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 876
    .line 877
    invoke-virtual {v1, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 878
    .line 879
    .line 880
    :cond_1b
    iget-object v1, v3, Lr0/o;->r:Lr0/f;

    .line 881
    .line 882
    if-eqz v1, :cond_1c

    .line 883
    .line 884
    iget-object v2, v3, Lr0/o;->m:Lr0/i;

    .line 885
    .line 886
    iget-object v1, v1, Lr0/f;->n:Li/k;

    .line 887
    .line 888
    iget-object v1, v1, Lc/k;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 889
    .line 890
    invoke-virtual {v1, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 891
    .line 892
    .line 893
    :cond_1c
    iget-object v1, v3, Lr0/o;->r:Lr0/f;

    .line 894
    .line 895
    if-eqz v1, :cond_1d

    .line 896
    .line 897
    iget-object v2, v3, Lr0/o;->n:Lr0/i;

    .line 898
    .line 899
    iget-object v1, v1, Lr0/f;->n:Li/k;

    .line 900
    .line 901
    iget-object v1, v1, Lc/k;->y:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 902
    .line 903
    invoke-virtual {v1, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 904
    .line 905
    .line 906
    :cond_1d
    iget-object v1, v3, Lr0/o;->r:Lr0/f;

    .line 907
    .line 908
    if-eqz v1, :cond_1e

    .line 909
    .line 910
    iget-object v2, v3, Lr0/o;->o:Lr0/i;

    .line 911
    .line 912
    iget-object v1, v1, Lr0/f;->n:Li/k;

    .line 913
    .line 914
    iget-object v1, v1, Lc/k;->z:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 915
    .line 916
    invoke-virtual {v1, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 917
    .line 918
    .line 919
    :cond_1e
    iget-object v1, v3, Lr0/o;->r:Lr0/f;

    .line 920
    .line 921
    if-eqz v1, :cond_1f

    .line 922
    .line 923
    iget-object v2, v3, Lr0/o;->p:Lr0/l;

    .line 924
    .line 925
    iget-object v1, v1, Lr0/f;->n:Li/k;

    .line 926
    .line 927
    iget-object v1, v1, Lc/k;->m:Ll4/t;

    .line 928
    .line 929
    iget-object v3, v1, Ll4/t;->m:Ljava/lang/Object;

    .line 930
    .line 931
    check-cast v3, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 932
    .line 933
    invoke-virtual {v3, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 934
    .line 935
    .line 936
    iget-object v1, v1, Ll4/t;->l:Ljava/lang/Object;

    .line 937
    .line 938
    check-cast v1, Ljava/lang/Runnable;

    .line 939
    .line 940
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    .line 941
    .line 942
    .line 943
    :cond_1f
    return-void

    .line 944
    :cond_20
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 945
    .line 946
    const-string v2, "Already attached"

    .line 947
    .line 948
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 949
    .line 950
    .line 951
    throw v1

    .line 952
    :pswitch_0
    iget-object v1, v0, Lc/d;->b:Li/k;

    .line 953
    .line 954
    iget-object v2, v1, Lc/k;->o:Lh5/u;

    .line 955
    .line 956
    iget-object v2, v2, Lh5/u;->n:Ljava/lang/Object;

    .line 957
    .line 958
    check-cast v2, Lk3/n2;

    .line 959
    .line 960
    const-string v3, "android:support:activity-result"

    .line 961
    .line 962
    invoke-virtual {v2, v3}, Lk3/n2;->d(Ljava/lang/String;)Landroid/os/Bundle;

    .line 963
    .line 964
    .line 965
    move-result-object v2

    .line 966
    if-eqz v2, :cond_23

    .line 967
    .line 968
    iget-object v1, v1, Lc/k;->u:Lc/f;

    .line 969
    .line 970
    iget-object v3, v1, Lc/f;->c:Ljava/util/HashMap;

    .line 971
    .line 972
    iget-object v4, v1, Lc/f;->b:Ljava/util/HashMap;

    .line 973
    .line 974
    iget-object v5, v1, Lc/f;->h:Landroid/os/Bundle;

    .line 975
    .line 976
    const-string v6, "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS"

    .line 977
    .line 978
    invoke-virtual {v2, v6}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 979
    .line 980
    .line 981
    move-result-object v6

    .line 982
    const-string v7, "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS"

    .line 983
    .line 984
    invoke-virtual {v2, v7}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 985
    .line 986
    .line 987
    move-result-object v7

    .line 988
    if-eqz v7, :cond_23

    .line 989
    .line 990
    if-nez v6, :cond_21

    .line 991
    .line 992
    goto :goto_f

    .line 993
    :cond_21
    const-string v8, "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS"

    .line 994
    .line 995
    invoke-virtual {v2, v8}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 996
    .line 997
    .line 998
    move-result-object v8

    .line 999
    iput-object v8, v1, Lc/f;->e:Ljava/util/ArrayList;

    .line 1000
    .line 1001
    const-string v8, "KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT"

    .line 1002
    .line 1003
    invoke-virtual {v2, v8}, Landroid/os/Bundle;->getSerializable(Ljava/lang/String;)Ljava/io/Serializable;

    .line 1004
    .line 1005
    .line 1006
    move-result-object v8

    .line 1007
    check-cast v8, Ljava/util/Random;

    .line 1008
    .line 1009
    iput-object v8, v1, Lc/f;->a:Ljava/util/Random;

    .line 1010
    .line 1011
    const-string v8, "KEY_COMPONENT_ACTIVITY_PENDING_RESULT"

    .line 1012
    .line 1013
    invoke-virtual {v2, v8}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 1014
    .line 1015
    .line 1016
    move-result-object v2

    .line 1017
    invoke-virtual {v5, v2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    .line 1018
    .line 1019
    .line 1020
    const/4 v2, 0x0

    .line 1021
    :goto_e
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 1022
    .line 1023
    .line 1024
    move-result v8

    .line 1025
    if-ge v2, v8, :cond_23

    .line 1026
    .line 1027
    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1028
    .line 1029
    .line 1030
    move-result-object v8

    .line 1031
    check-cast v8, Ljava/lang/String;

    .line 1032
    .line 1033
    invoke-virtual {v3, v8}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 1034
    .line 1035
    .line 1036
    move-result v9

    .line 1037
    if-eqz v9, :cond_22

    .line 1038
    .line 1039
    invoke-virtual {v3, v8}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1040
    .line 1041
    .line 1042
    move-result-object v9

    .line 1043
    check-cast v9, Ljava/lang/Integer;

    .line 1044
    .line 1045
    invoke-virtual {v5, v8}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 1046
    .line 1047
    .line 1048
    move-result v8

    .line 1049
    if-nez v8, :cond_22

    .line 1050
    .line 1051
    invoke-virtual {v4, v9}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1052
    .line 1053
    .line 1054
    :cond_22
    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1055
    .line 1056
    .line 1057
    move-result-object v8

    .line 1058
    check-cast v8, Ljava/lang/Integer;

    .line 1059
    .line 1060
    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    .line 1061
    .line 1062
    .line 1063
    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1064
    .line 1065
    .line 1066
    move-result-object v9

    .line 1067
    check-cast v9, Ljava/lang/String;

    .line 1068
    .line 1069
    invoke-virtual {v4, v8, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1070
    .line 1071
    .line 1072
    iget-object v10, v1, Lc/f;->c:Ljava/util/HashMap;

    .line 1073
    .line 1074
    invoke-virtual {v10, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1075
    .line 1076
    .line 1077
    add-int/lit8 v2, v2, 0x1

    .line 1078
    .line 1079
    goto :goto_e

    .line 1080
    :cond_23
    :goto_f
    return-void

    .line 1081
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
