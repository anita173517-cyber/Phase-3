.class public abstract Lc6/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .locals 8

    .line 1
    new-instance v0, Lc6/a;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-class v2, Lx5/c;

    .line 5
    .line 6
    invoke-direct {v0, v1, v2}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 7
    .line 8
    .line 9
    const/4 v3, 0x1

    .line 10
    new-array v4, v3, [Lc6/a;

    .line 11
    .line 12
    aput-object v0, v4, v1

    .line 13
    .line 14
    new-instance v0, Ljava/util/HashMap;

    .line 15
    .line 16
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 17
    .line 18
    .line 19
    aget-object v5, v4, v1

    .line 20
    .line 21
    iget-object v6, v5, Lc6/a;->a:Ljava/lang/Class;

    .line 22
    .line 23
    invoke-virtual {v0, v6}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v7

    .line 27
    if-nez v7, :cond_1

    .line 28
    .line 29
    invoke-virtual {v0, v6, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    aget-object v4, v4, v1

    .line 33
    .line 34
    iget-object v4, v4, Lc6/a;->a:Ljava/lang/Class;

    .line 35
    .line 36
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 37
    .line 38
    .line 39
    sget v0, Lj6/r1;->CONFIG_NAME_FIELD_NUMBER:I

    .line 40
    .line 41
    :try_start_0
    sget-object v0, Lc6/f;->b:Lc6/f;

    .line 42
    .line 43
    invoke-static {v0}, Lx5/n;->h(Lx5/m;)V

    .line 44
    .line 45
    .line 46
    invoke-static {}, Lb6/a;->a()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-eqz v0, :cond_0

    .line 51
    .line 52
    return-void

    .line 53
    :cond_0
    new-instance v0, Lc6/c;

    .line 54
    .line 55
    const-class v4, Lj6/f0;

    .line 56
    .line 57
    new-instance v5, Lc6/a;

    .line 58
    .line 59
    invoke-direct {v5, v1, v2}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 60
    .line 61
    .line 62
    new-array v2, v3, [Lc6/a;

    .line 63
    .line 64
    aput-object v5, v2, v1

    .line 65
    .line 66
    invoke-direct {v0, v4, v2, v1}, Lc6/c;-><init>(Ljava/lang/Class;[Lc6/a;I)V

    .line 67
    .line 68
    .line 69
    invoke-static {v0, v3}, Lx5/n;->f(Le6/f;Z)V
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 70
    .line 71
    .line 72
    return-void

    .line 73
    :catch_0
    move-exception v0

    .line 74
    new-instance v1, Ljava/lang/ExceptionInInitializerError;

    .line 75
    .line 76
    invoke-direct {v1, v0}, Ljava/lang/ExceptionInInitializerError;-><init>(Ljava/lang/Throwable;)V

    .line 77
    .line 78
    .line 79
    throw v1

    .line 80
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 81
    .line 82
    new-instance v1, Ljava/lang/StringBuilder;

    .line 83
    .line 84
    const-string v2, "KeyTypeManager constructed with duplicate factories for primitive "

    .line 85
    .line 86
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v6}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v2

    .line 93
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 94
    .line 95
    .line 96
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    throw v0
.end method
