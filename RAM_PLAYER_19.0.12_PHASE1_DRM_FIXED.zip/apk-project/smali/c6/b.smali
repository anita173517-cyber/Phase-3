.class public final Lc6/b;
.super Le6/e;
.source "SourceFile"


# instance fields
.field public final synthetic l:I


# direct methods
.method public constructor <init>(Lc6/c;)V
    .locals 0

    const/4 p1, 0x0

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/h0;

    .line 9
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lc6/c;B)V
    .locals 0

    const/4 p1, 0x3

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/j;

    .line 10
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lc6/c;BB)V
    .locals 0

    const/16 p1, 0x8

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/m1;

    .line 2
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lc6/c;BC)V
    .locals 0

    const/16 p1, 0x9

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/p1;

    .line 3
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lc6/c;BI)V
    .locals 0

    const/16 p1, 0xa

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/u1;

    .line 8
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lc6/c;BZ)V
    .locals 0

    const/4 p1, 0x7

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/l0;

    .line 5
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lc6/c;C)V
    .locals 0

    const/4 p1, 0x4

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/t;

    .line 6
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lc6/c;I)V
    .locals 0

    const/4 p1, 0x5

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/z;

    .line 4
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lc6/c;S)V
    .locals 0

    const/4 p1, 0x6

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/d0;

    .line 7
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public constructor <init>(Lf6/b;)V
    .locals 0

    const/4 p1, 0x2

    iput p1, p0, Lc6/b;->l:I

    const-class p1, Lj6/s0;

    .line 11
    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Class;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Lc6/b;->l:I

    invoke-direct {p0, p1}, Le6/e;-><init>(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final N(Lcom/google/crypto/tink/shaded/protobuf/a;)Lcom/google/crypto/tink/shaded/protobuf/a;
    .locals 10

    .line 1
    iget v0, p0, Lc6/b;->l:I

    .line 2
    .line 3
    const/16 v1, 0x20

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    check-cast p1, Lj6/u1;

    .line 10
    .line 11
    invoke-static {}, Lj6/t1;->A()Lj6/s1;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 16
    .line 17
    .line 18
    iget-object v0, p1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 19
    .line 20
    check-cast v0, Lj6/t1;

    .line 21
    .line 22
    invoke-static {v0}, Lj6/t1;->w(Lj6/t1;)V

    .line 23
    .line 24
    .line 25
    invoke-static {v1}, Lk6/m;->a(I)[B

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    array-length v1, v0

    .line 30
    invoke-static {v0, v2, v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 35
    .line 36
    .line 37
    iget-object v1, p1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 38
    .line 39
    check-cast v1, Lj6/t1;

    .line 40
    .line 41
    invoke-static {v1, v0}, Lj6/t1;->x(Lj6/t1;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    check-cast p1, Lj6/t1;

    .line 49
    .line 50
    return-object p1

    .line 51
    :pswitch_0
    check-cast p1, Lj6/p1;

    .line 52
    .line 53
    invoke-static {}, Lj6/o1;->A()Lj6/n1;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 58
    .line 59
    .line 60
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 61
    .line 62
    check-cast v1, Lj6/o1;

    .line 63
    .line 64
    invoke-static {v1, p1}, Lj6/o1;->x(Lj6/o1;Lj6/p1;)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 68
    .line 69
    .line 70
    iget-object p1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 71
    .line 72
    check-cast p1, Lj6/o1;

    .line 73
    .line 74
    invoke-static {p1}, Lj6/o1;->w(Lj6/o1;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    check-cast p1, Lj6/o1;

    .line 82
    .line 83
    return-object p1

    .line 84
    :pswitch_1
    check-cast p1, Lj6/m1;

    .line 85
    .line 86
    invoke-static {}, Lj6/l1;->A()Lj6/k1;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 91
    .line 92
    .line 93
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 94
    .line 95
    check-cast v1, Lj6/l1;

    .line 96
    .line 97
    invoke-static {v1, p1}, Lj6/l1;->x(Lj6/l1;Lj6/m1;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 101
    .line 102
    .line 103
    iget-object p1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 104
    .line 105
    check-cast p1, Lj6/l1;

    .line 106
    .line 107
    invoke-static {p1}, Lj6/l1;->w(Lj6/l1;)V

    .line 108
    .line 109
    .line 110
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    check-cast p1, Lj6/l1;

    .line 115
    .line 116
    return-object p1

    .line 117
    :pswitch_2
    check-cast p1, Lj6/l0;

    .line 118
    .line 119
    invoke-static {}, Lj6/j0;->A()Lj6/i0;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 124
    .line 125
    .line 126
    iget-object v0, p1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 127
    .line 128
    check-cast v0, Lj6/j0;

    .line 129
    .line 130
    invoke-static {v0}, Lj6/j0;->w(Lj6/j0;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v1}, Lk6/m;->a(I)[B

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    array-length v1, v0

    .line 138
    invoke-static {v0, v2, v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 143
    .line 144
    .line 145
    iget-object v1, p1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 146
    .line 147
    check-cast v1, Lj6/j0;

    .line 148
    .line 149
    invoke-static {v1, v0}, Lj6/j0;->x(Lj6/j0;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    check-cast p1, Lj6/j0;

    .line 157
    .line 158
    return-object p1

    .line 159
    :pswitch_3
    check-cast p1, Lj6/d0;

    .line 160
    .line 161
    invoke-static {}, Lj6/b0;->A()Lj6/a0;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    invoke-virtual {p1}, Lj6/d0;->x()I

    .line 166
    .line 167
    .line 168
    move-result p1

    .line 169
    invoke-static {p1}, Lk6/m;->a(I)[B

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    array-length v1, p1

    .line 174
    invoke-static {p1, v2, v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 175
    .line 176
    .line 177
    move-result-object p1

    .line 178
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 179
    .line 180
    .line 181
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 182
    .line 183
    check-cast v1, Lj6/b0;

    .line 184
    .line 185
    invoke-static {v1, p1}, Lj6/b0;->x(Lj6/b0;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 189
    .line 190
    .line 191
    iget-object p1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 192
    .line 193
    check-cast p1, Lj6/b0;

    .line 194
    .line 195
    invoke-static {p1}, Lj6/b0;->w(Lj6/b0;)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 199
    .line 200
    .line 201
    move-result-object p1

    .line 202
    check-cast p1, Lj6/b0;

    .line 203
    .line 204
    return-object p1

    .line 205
    :pswitch_4
    check-cast p1, Lj6/z;

    .line 206
    .line 207
    invoke-static {}, Lj6/x;->A()Lj6/w;

    .line 208
    .line 209
    .line 210
    move-result-object v0

    .line 211
    invoke-virtual {p1}, Lj6/z;->x()I

    .line 212
    .line 213
    .line 214
    move-result p1

    .line 215
    invoke-static {p1}, Lk6/m;->a(I)[B

    .line 216
    .line 217
    .line 218
    move-result-object p1

    .line 219
    array-length v1, p1

    .line 220
    invoke-static {p1, v2, v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 221
    .line 222
    .line 223
    move-result-object p1

    .line 224
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 225
    .line 226
    .line 227
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 228
    .line 229
    check-cast v1, Lj6/x;

    .line 230
    .line 231
    invoke-static {v1, p1}, Lj6/x;->x(Lj6/x;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 235
    .line 236
    .line 237
    iget-object p1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 238
    .line 239
    check-cast p1, Lj6/x;

    .line 240
    .line 241
    invoke-static {p1}, Lj6/x;->w(Lj6/x;)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 245
    .line 246
    .line 247
    move-result-object p1

    .line 248
    check-cast p1, Lj6/x;

    .line 249
    .line 250
    return-object p1

    .line 251
    :pswitch_5
    check-cast p1, Lj6/t;

    .line 252
    .line 253
    invoke-static {}, Lj6/r;->C()Lj6/q;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    invoke-virtual {p1}, Lj6/t;->y()I

    .line 258
    .line 259
    .line 260
    move-result v1

    .line 261
    invoke-static {v1}, Lk6/m;->a(I)[B

    .line 262
    .line 263
    .line 264
    move-result-object v1

    .line 265
    array-length v3, v1

    .line 266
    invoke-static {v1, v2, v3}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 267
    .line 268
    .line 269
    move-result-object v1

    .line 270
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 271
    .line 272
    .line 273
    iget-object v2, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 274
    .line 275
    check-cast v2, Lj6/r;

    .line 276
    .line 277
    invoke-static {v2, v1}, Lj6/r;->y(Lj6/r;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 278
    .line 279
    .line 280
    invoke-virtual {p1}, Lj6/t;->z()Lj6/v;

    .line 281
    .line 282
    .line 283
    move-result-object p1

    .line 284
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 285
    .line 286
    .line 287
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 288
    .line 289
    check-cast v1, Lj6/r;

    .line 290
    .line 291
    invoke-static {v1, p1}, Lj6/r;->x(Lj6/r;Lj6/v;)V

    .line 292
    .line 293
    .line 294
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 295
    .line 296
    .line 297
    iget-object p1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 298
    .line 299
    check-cast p1, Lj6/r;

    .line 300
    .line 301
    invoke-static {p1}, Lj6/r;->w(Lj6/r;)V

    .line 302
    .line 303
    .line 304
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 305
    .line 306
    .line 307
    move-result-object p1

    .line 308
    check-cast p1, Lj6/r;

    .line 309
    .line 310
    return-object p1

    .line 311
    :pswitch_6
    check-cast p1, Lj6/j;

    .line 312
    .line 313
    new-instance v0, Lc6/a;

    .line 314
    .line 315
    const-class v1, Lk6/j;

    .line 316
    .line 317
    const/4 v3, 0x4

    .line 318
    invoke-direct {v0, v3, v1}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 319
    .line 320
    .line 321
    const/4 v1, 0x1

    .line 322
    new-array v3, v1, [Lc6/a;

    .line 323
    .line 324
    aput-object v0, v3, v2

    .line 325
    .line 326
    new-instance v0, Ljava/util/HashMap;

    .line 327
    .line 328
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 329
    .line 330
    .line 331
    array-length v4, v3

    .line 332
    move v5, v2

    .line 333
    :goto_0
    const-string v6, "KeyTypeManager constructed with duplicate factories for primitive "

    .line 334
    .line 335
    if-ge v5, v4, :cond_1

    .line 336
    .line 337
    aget-object v7, v3, v5

    .line 338
    .line 339
    iget-object v8, v7, Lc6/a;->a:Ljava/lang/Class;

    .line 340
    .line 341
    invoke-virtual {v0, v8}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 342
    .line 343
    .line 344
    move-result v9

    .line 345
    if-nez v9, :cond_0

    .line 346
    .line 347
    invoke-virtual {v0, v8, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 348
    .line 349
    .line 350
    add-int/lit8 v5, v5, 0x1

    .line 351
    .line 352
    goto :goto_0

    .line 353
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 354
    .line 355
    new-instance v0, Ljava/lang/StringBuilder;

    .line 356
    .line 357
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 358
    .line 359
    .line 360
    invoke-virtual {v8}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 365
    .line 366
    .line 367
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 368
    .line 369
    .line 370
    move-result-object v0

    .line 371
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 372
    .line 373
    .line 374
    throw p1

    .line 375
    :cond_1
    array-length v4, v3

    .line 376
    if-lez v4, :cond_2

    .line 377
    .line 378
    aget-object v3, v3, v2

    .line 379
    .line 380
    iget-object v3, v3, Lc6/a;->a:Ljava/lang/Class;

    .line 381
    .line 382
    :cond_2
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 383
    .line 384
    .line 385
    invoke-virtual {p1}, Lj6/j;->y()Lj6/n;

    .line 386
    .line 387
    .line 388
    move-result-object v0

    .line 389
    invoke-static {}, Lj6/l;->D()Lj6/k;

    .line 390
    .line 391
    .line 392
    move-result-object v3

    .line 393
    invoke-virtual {v0}, Lj6/n;->A()Lj6/p;

    .line 394
    .line 395
    .line 396
    move-result-object v4

    .line 397
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 398
    .line 399
    .line 400
    iget-object v5, v3, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 401
    .line 402
    check-cast v5, Lj6/l;

    .line 403
    .line 404
    invoke-static {v5, v4}, Lj6/l;->x(Lj6/l;Lj6/p;)V

    .line 405
    .line 406
    .line 407
    invoke-virtual {v0}, Lj6/n;->z()I

    .line 408
    .line 409
    .line 410
    move-result v0

    .line 411
    invoke-static {v0}, Lk6/m;->a(I)[B

    .line 412
    .line 413
    .line 414
    move-result-object v0

    .line 415
    array-length v4, v0

    .line 416
    invoke-static {v0, v2, v4}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 417
    .line 418
    .line 419
    move-result-object v0

    .line 420
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 421
    .line 422
    .line 423
    iget-object v4, v3, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 424
    .line 425
    check-cast v4, Lj6/l;

    .line 426
    .line 427
    invoke-static {v4, v0}, Lj6/l;->y(Lj6/l;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 428
    .line 429
    .line 430
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 431
    .line 432
    .line 433
    iget-object v0, v3, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 434
    .line 435
    check-cast v0, Lj6/l;

    .line 436
    .line 437
    invoke-static {v0}, Lj6/l;->w(Lj6/l;)V

    .line 438
    .line 439
    .line 440
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 441
    .line 442
    .line 443
    move-result-object v0

    .line 444
    check-cast v0, Lj6/l;

    .line 445
    .line 446
    new-instance v3, Lc6/a;

    .line 447
    .line 448
    const-class v4, Lx5/j;

    .line 449
    .line 450
    const/4 v5, 0x2

    .line 451
    invoke-direct {v3, v5, v4}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 452
    .line 453
    .line 454
    new-array v1, v1, [Lc6/a;

    .line 455
    .line 456
    aput-object v3, v1, v2

    .line 457
    .line 458
    new-instance v3, Ljava/util/HashMap;

    .line 459
    .line 460
    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    .line 461
    .line 462
    .line 463
    array-length v4, v1

    .line 464
    move v5, v2

    .line 465
    :goto_1
    if-ge v5, v4, :cond_4

    .line 466
    .line 467
    aget-object v7, v1, v5

    .line 468
    .line 469
    iget-object v8, v7, Lc6/a;->a:Ljava/lang/Class;

    .line 470
    .line 471
    invoke-virtual {v3, v8}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 472
    .line 473
    .line 474
    move-result v9

    .line 475
    if-nez v9, :cond_3

    .line 476
    .line 477
    invoke-virtual {v3, v8, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 478
    .line 479
    .line 480
    add-int/lit8 v5, v5, 0x1

    .line 481
    .line 482
    goto :goto_1

    .line 483
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 484
    .line 485
    new-instance v0, Ljava/lang/StringBuilder;

    .line 486
    .line 487
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 488
    .line 489
    .line 490
    invoke-virtual {v8}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 491
    .line 492
    .line 493
    move-result-object v1

    .line 494
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 495
    .line 496
    .line 497
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 498
    .line 499
    .line 500
    move-result-object v0

    .line 501
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 502
    .line 503
    .line 504
    throw p1

    .line 505
    :cond_4
    array-length v4, v1

    .line 506
    if-lez v4, :cond_5

    .line 507
    .line 508
    aget-object v1, v1, v2

    .line 509
    .line 510
    iget-object v1, v1, Lc6/a;->a:Ljava/lang/Class;

    .line 511
    .line 512
    :cond_5
    invoke-static {v3}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 513
    .line 514
    .line 515
    invoke-virtual {p1}, Lj6/j;->z()Lj6/s0;

    .line 516
    .line 517
    .line 518
    move-result-object p1

    .line 519
    invoke-static {}, Lj6/q0;->D()Lj6/p0;

    .line 520
    .line 521
    .line 522
    move-result-object v1

    .line 523
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 524
    .line 525
    .line 526
    iget-object v3, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 527
    .line 528
    check-cast v3, Lj6/q0;

    .line 529
    .line 530
    invoke-static {v3}, Lj6/q0;->w(Lj6/q0;)V

    .line 531
    .line 532
    .line 533
    invoke-virtual {p1}, Lj6/s0;->A()Lj6/u0;

    .line 534
    .line 535
    .line 536
    move-result-object v3

    .line 537
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 538
    .line 539
    .line 540
    iget-object v4, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 541
    .line 542
    check-cast v4, Lj6/q0;

    .line 543
    .line 544
    invoke-static {v4, v3}, Lj6/q0;->x(Lj6/q0;Lj6/u0;)V

    .line 545
    .line 546
    .line 547
    invoke-virtual {p1}, Lj6/s0;->z()I

    .line 548
    .line 549
    .line 550
    move-result p1

    .line 551
    invoke-static {p1}, Lk6/m;->a(I)[B

    .line 552
    .line 553
    .line 554
    move-result-object p1

    .line 555
    array-length v3, p1

    .line 556
    invoke-static {p1, v2, v3}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 557
    .line 558
    .line 559
    move-result-object p1

    .line 560
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 561
    .line 562
    .line 563
    iget-object v2, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 564
    .line 565
    check-cast v2, Lj6/q0;

    .line 566
    .line 567
    invoke-static {v2, p1}, Lj6/q0;->y(Lj6/q0;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 568
    .line 569
    .line 570
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 571
    .line 572
    .line 573
    move-result-object p1

    .line 574
    check-cast p1, Lj6/q0;

    .line 575
    .line 576
    invoke-static {}, Lj6/h;->C()Lj6/g;

    .line 577
    .line 578
    .line 579
    move-result-object v1

    .line 580
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 581
    .line 582
    .line 583
    iget-object v2, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 584
    .line 585
    check-cast v2, Lj6/h;

    .line 586
    .line 587
    invoke-static {v2, v0}, Lj6/h;->x(Lj6/h;Lj6/l;)V

    .line 588
    .line 589
    .line 590
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 591
    .line 592
    .line 593
    iget-object v0, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 594
    .line 595
    check-cast v0, Lj6/h;

    .line 596
    .line 597
    invoke-static {v0, p1}, Lj6/h;->y(Lj6/h;Lj6/q0;)V

    .line 598
    .line 599
    .line 600
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 601
    .line 602
    .line 603
    iget-object p1, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 604
    .line 605
    check-cast p1, Lj6/h;

    .line 606
    .line 607
    invoke-static {p1}, Lj6/h;->w(Lj6/h;)V

    .line 608
    .line 609
    .line 610
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 611
    .line 612
    .line 613
    move-result-object p1

    .line 614
    check-cast p1, Lj6/h;

    .line 615
    .line 616
    return-object p1

    .line 617
    :pswitch_7
    check-cast p1, Lj6/s0;

    .line 618
    .line 619
    invoke-static {}, Lj6/q0;->D()Lj6/p0;

    .line 620
    .line 621
    .line 622
    move-result-object v0

    .line 623
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 624
    .line 625
    .line 626
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 627
    .line 628
    check-cast v1, Lj6/q0;

    .line 629
    .line 630
    invoke-static {v1}, Lj6/q0;->w(Lj6/q0;)V

    .line 631
    .line 632
    .line 633
    invoke-virtual {p1}, Lj6/s0;->A()Lj6/u0;

    .line 634
    .line 635
    .line 636
    move-result-object v1

    .line 637
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 638
    .line 639
    .line 640
    iget-object v3, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 641
    .line 642
    check-cast v3, Lj6/q0;

    .line 643
    .line 644
    invoke-static {v3, v1}, Lj6/q0;->x(Lj6/q0;Lj6/u0;)V

    .line 645
    .line 646
    .line 647
    invoke-virtual {p1}, Lj6/s0;->z()I

    .line 648
    .line 649
    .line 650
    move-result p1

    .line 651
    invoke-static {p1}, Lk6/m;->a(I)[B

    .line 652
    .line 653
    .line 654
    move-result-object p1

    .line 655
    array-length v1, p1

    .line 656
    invoke-static {p1, v2, v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 657
    .line 658
    .line 659
    move-result-object p1

    .line 660
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 661
    .line 662
    .line 663
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 664
    .line 665
    check-cast v1, Lj6/q0;

    .line 666
    .line 667
    invoke-static {v1, p1}, Lj6/q0;->y(Lj6/q0;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 668
    .line 669
    .line 670
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 671
    .line 672
    .line 673
    move-result-object p1

    .line 674
    check-cast p1, Lj6/q0;

    .line 675
    .line 676
    return-object p1

    .line 677
    :pswitch_8
    check-cast p1, Lj6/d;

    .line 678
    .line 679
    invoke-static {}, Lj6/b;->C()Lj6/a;

    .line 680
    .line 681
    .line 682
    move-result-object v0

    .line 683
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 684
    .line 685
    .line 686
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 687
    .line 688
    check-cast v1, Lj6/b;

    .line 689
    .line 690
    invoke-static {v1}, Lj6/b;->w(Lj6/b;)V

    .line 691
    .line 692
    .line 693
    invoke-virtual {p1}, Lj6/d;->y()I

    .line 694
    .line 695
    .line 696
    move-result v1

    .line 697
    invoke-static {v1}, Lk6/m;->a(I)[B

    .line 698
    .line 699
    .line 700
    move-result-object v1

    .line 701
    array-length v3, v1

    .line 702
    invoke-static {v1, v2, v3}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 703
    .line 704
    .line 705
    move-result-object v1

    .line 706
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 707
    .line 708
    .line 709
    iget-object v2, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 710
    .line 711
    check-cast v2, Lj6/b;

    .line 712
    .line 713
    invoke-static {v2, v1}, Lj6/b;->x(Lj6/b;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 714
    .line 715
    .line 716
    invoke-virtual {p1}, Lj6/d;->z()Lj6/f;

    .line 717
    .line 718
    .line 719
    move-result-object p1

    .line 720
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 721
    .line 722
    .line 723
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 724
    .line 725
    check-cast v1, Lj6/b;

    .line 726
    .line 727
    invoke-static {v1, p1}, Lj6/b;->y(Lj6/b;Lj6/f;)V

    .line 728
    .line 729
    .line 730
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 731
    .line 732
    .line 733
    move-result-object p1

    .line 734
    check-cast p1, Lj6/b;

    .line 735
    .line 736
    return-object p1

    .line 737
    :pswitch_9
    check-cast p1, Lj6/h0;

    .line 738
    .line 739
    invoke-static {}, Lj6/f0;->A()Lj6/e0;

    .line 740
    .line 741
    .line 742
    move-result-object v0

    .line 743
    invoke-virtual {p1}, Lj6/h0;->x()I

    .line 744
    .line 745
    .line 746
    move-result p1

    .line 747
    invoke-static {p1}, Lk6/m;->a(I)[B

    .line 748
    .line 749
    .line 750
    move-result-object p1

    .line 751
    array-length v1, p1

    .line 752
    invoke-static {p1, v2, v1}, Lcom/google/crypto/tink/shaded/protobuf/j;->h([BII)Lcom/google/crypto/tink/shaded/protobuf/i;

    .line 753
    .line 754
    .line 755
    move-result-object p1

    .line 756
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 757
    .line 758
    .line 759
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 760
    .line 761
    check-cast v1, Lj6/f0;

    .line 762
    .line 763
    invoke-static {v1, p1}, Lj6/f0;->x(Lj6/f0;Lcom/google/crypto/tink/shaded/protobuf/i;)V

    .line 764
    .line 765
    .line 766
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 767
    .line 768
    .line 769
    iget-object p1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 770
    .line 771
    check-cast p1, Lj6/f0;

    .line 772
    .line 773
    invoke-static {p1}, Lj6/f0;->w(Lj6/f0;)V

    .line 774
    .line 775
    .line 776
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 777
    .line 778
    .line 779
    move-result-object p1

    .line 780
    check-cast p1, Lj6/f0;

    .line 781
    .line 782
    return-object p1

    .line 783
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public a1()Ljava/util/Map;
    .locals 9

    .line 1
    iget v0, p0, Lc6/b;->l:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    :pswitch_0
    invoke-super {p0}, Le6/e;->a1()Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_1
    new-instance v0, Ljava/util/HashMap;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 14
    .line 15
    .line 16
    new-instance v1, Le6/d;

    .line 17
    .line 18
    invoke-static {}, Lj6/u1;->w()Lj6/u1;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    const/4 v3, 0x1

    .line 23
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 24
    .line 25
    .line 26
    const-string v2, "XCHACHA20_POLY1305"

    .line 27
    .line 28
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    new-instance v1, Le6/d;

    .line 32
    .line 33
    invoke-static {}, Lj6/u1;->w()Lj6/u1;

    .line 34
    .line 35
    .line 36
    move-result-object v2

    .line 37
    const/4 v3, 0x3

    .line 38
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 39
    .line 40
    .line 41
    const-string v2, "XCHACHA20_POLY1305_RAW"

    .line 42
    .line 43
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    return-object v0

    .line 51
    :pswitch_2
    new-instance v0, Ljava/util/HashMap;

    .line 52
    .line 53
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 54
    .line 55
    .line 56
    new-instance v1, Le6/d;

    .line 57
    .line 58
    invoke-static {}, Lj6/l0;->w()Lj6/l0;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    const/4 v3, 0x1

    .line 63
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 64
    .line 65
    .line 66
    const-string v2, "CHACHA20_POLY1305"

    .line 67
    .line 68
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    new-instance v1, Le6/d;

    .line 72
    .line 73
    invoke-static {}, Lj6/l0;->w()Lj6/l0;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    const/4 v3, 0x3

    .line 78
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 79
    .line 80
    .line 81
    const-string v2, "CHACHA20_POLY1305_RAW"

    .line 82
    .line 83
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    return-object v0

    .line 91
    :pswitch_3
    new-instance v0, Ljava/util/HashMap;

    .line 92
    .line 93
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 94
    .line 95
    .line 96
    const/16 v1, 0x10

    .line 97
    .line 98
    const/4 v2, 0x1

    .line 99
    invoke-static {v1, v2}, Lc6/c;->o(II)Le6/d;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    const-string v4, "AES128_GCM_SIV"

    .line 104
    .line 105
    invoke-virtual {v0, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    const/4 v3, 0x3

    .line 109
    invoke-static {v1, v3}, Lc6/c;->o(II)Le6/d;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    const-string v4, "AES128_GCM_SIV_RAW"

    .line 114
    .line 115
    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    const/16 v1, 0x20

    .line 119
    .line 120
    invoke-static {v1, v2}, Lc6/c;->o(II)Le6/d;

    .line 121
    .line 122
    .line 123
    move-result-object v2

    .line 124
    const-string v4, "AES256_GCM_SIV"

    .line 125
    .line 126
    invoke-virtual {v0, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    const-string v2, "AES256_GCM_SIV_RAW"

    .line 130
    .line 131
    invoke-static {v1, v3}, Lc6/c;->o(II)Le6/d;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    return-object v0

    .line 143
    :pswitch_4
    new-instance v0, Ljava/util/HashMap;

    .line 144
    .line 145
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 146
    .line 147
    .line 148
    const/16 v1, 0x10

    .line 149
    .line 150
    const/4 v2, 0x1

    .line 151
    invoke-static {v1, v2}, Lc6/c;->n(II)Le6/d;

    .line 152
    .line 153
    .line 154
    move-result-object v3

    .line 155
    const-string v4, "AES128_GCM"

    .line 156
    .line 157
    invoke-virtual {v0, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    const/4 v3, 0x3

    .line 161
    invoke-static {v1, v3}, Lc6/c;->n(II)Le6/d;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    const-string v4, "AES128_GCM_RAW"

    .line 166
    .line 167
    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    const/16 v1, 0x20

    .line 171
    .line 172
    invoke-static {v1, v2}, Lc6/c;->n(II)Le6/d;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    const-string v4, "AES256_GCM"

    .line 177
    .line 178
    invoke-virtual {v0, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    const-string v2, "AES256_GCM_RAW"

    .line 182
    .line 183
    invoke-static {v1, v3}, Lc6/c;->n(II)Le6/d;

    .line 184
    .line 185
    .line 186
    move-result-object v1

    .line 187
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    return-object v0

    .line 195
    :pswitch_5
    new-instance v0, Ljava/util/HashMap;

    .line 196
    .line 197
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 198
    .line 199
    .line 200
    const/16 v1, 0x10

    .line 201
    .line 202
    const/4 v2, 0x1

    .line 203
    invoke-static {v1, v2}, Lc6/c;->l(II)Le6/d;

    .line 204
    .line 205
    .line 206
    move-result-object v3

    .line 207
    const-string v4, "AES128_EAX"

    .line 208
    .line 209
    invoke-virtual {v0, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    const/4 v3, 0x3

    .line 213
    invoke-static {v1, v3}, Lc6/c;->l(II)Le6/d;

    .line 214
    .line 215
    .line 216
    move-result-object v1

    .line 217
    const-string v4, "AES128_EAX_RAW"

    .line 218
    .line 219
    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    const/16 v1, 0x20

    .line 223
    .line 224
    invoke-static {v1, v2}, Lc6/c;->l(II)Le6/d;

    .line 225
    .line 226
    .line 227
    move-result-object v2

    .line 228
    const-string v4, "AES256_EAX"

    .line 229
    .line 230
    invoke-virtual {v0, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    const-string v2, "AES256_EAX_RAW"

    .line 234
    .line 235
    invoke-static {v1, v3}, Lc6/c;->l(II)Le6/d;

    .line 236
    .line 237
    .line 238
    move-result-object v1

    .line 239
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    return-object v0

    .line 247
    :pswitch_6
    new-instance v0, Ljava/util/HashMap;

    .line 248
    .line 249
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 250
    .line 251
    .line 252
    const/16 v1, 0x10

    .line 253
    .line 254
    const/4 v2, 0x1

    .line 255
    invoke-static {v1, v1, v2}, Lc6/c;->m(III)Le6/d;

    .line 256
    .line 257
    .line 258
    move-result-object v3

    .line 259
    const-string v4, "AES128_CTR_HMAC_SHA256"

    .line 260
    .line 261
    invoke-virtual {v0, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    const/4 v3, 0x3

    .line 265
    invoke-static {v1, v1, v3}, Lc6/c;->m(III)Le6/d;

    .line 266
    .line 267
    .line 268
    move-result-object v1

    .line 269
    const-string v4, "AES128_CTR_HMAC_SHA256_RAW"

    .line 270
    .line 271
    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 272
    .line 273
    .line 274
    const/16 v1, 0x20

    .line 275
    .line 276
    invoke-static {v1, v1, v2}, Lc6/c;->m(III)Le6/d;

    .line 277
    .line 278
    .line 279
    move-result-object v2

    .line 280
    const-string v4, "AES256_CTR_HMAC_SHA256"

    .line 281
    .line 282
    invoke-virtual {v0, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    const-string v2, "AES256_CTR_HMAC_SHA256_RAW"

    .line 286
    .line 287
    invoke-static {v1, v1, v3}, Lc6/c;->m(III)Le6/d;

    .line 288
    .line 289
    .line 290
    move-result-object v1

    .line 291
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 292
    .line 293
    .line 294
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 295
    .line 296
    .line 297
    move-result-object v0

    .line 298
    return-object v0

    .line 299
    :pswitch_7
    new-instance v0, Ljava/util/HashMap;

    .line 300
    .line 301
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 302
    .line 303
    .line 304
    const/16 v1, 0x20

    .line 305
    .line 306
    const/16 v2, 0x10

    .line 307
    .line 308
    sget-object v3, Lj6/o0;->o:Lj6/o0;

    .line 309
    .line 310
    const/4 v4, 0x1

    .line 311
    invoke-static {v1, v2, v3, v4}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 312
    .line 313
    .line 314
    move-result-object v5

    .line 315
    const-string v6, "HMAC_SHA256_128BITTAG"

    .line 316
    .line 317
    invoke-virtual {v0, v6, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    const/4 v5, 0x3

    .line 321
    invoke-static {v1, v2, v3, v5}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 322
    .line 323
    .line 324
    move-result-object v6

    .line 325
    const-string v7, "HMAC_SHA256_128BITTAG_RAW"

    .line 326
    .line 327
    invoke-virtual {v0, v7, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 328
    .line 329
    .line 330
    const-string v6, "HMAC_SHA256_256BITTAG"

    .line 331
    .line 332
    invoke-static {v1, v1, v3, v4}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 333
    .line 334
    .line 335
    move-result-object v7

    .line 336
    invoke-virtual {v0, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 337
    .line 338
    .line 339
    const-string v6, "HMAC_SHA256_256BITTAG_RAW"

    .line 340
    .line 341
    invoke-static {v1, v1, v3, v5}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 342
    .line 343
    .line 344
    move-result-object v3

    .line 345
    invoke-virtual {v0, v6, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 346
    .line 347
    .line 348
    const/16 v3, 0x40

    .line 349
    .line 350
    sget-object v6, Lj6/o0;->p:Lj6/o0;

    .line 351
    .line 352
    invoke-static {v3, v2, v6, v4}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 353
    .line 354
    .line 355
    move-result-object v7

    .line 356
    const-string v8, "HMAC_SHA512_128BITTAG"

    .line 357
    .line 358
    invoke-virtual {v0, v8, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 359
    .line 360
    .line 361
    const-string v7, "HMAC_SHA512_128BITTAG_RAW"

    .line 362
    .line 363
    invoke-static {v3, v2, v6, v5}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 364
    .line 365
    .line 366
    move-result-object v2

    .line 367
    invoke-virtual {v0, v7, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    const-string v2, "HMAC_SHA512_256BITTAG"

    .line 371
    .line 372
    invoke-static {v3, v1, v6, v4}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 373
    .line 374
    .line 375
    move-result-object v7

    .line 376
    invoke-virtual {v0, v2, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 377
    .line 378
    .line 379
    const-string v2, "HMAC_SHA512_256BITTAG_RAW"

    .line 380
    .line 381
    invoke-static {v3, v1, v6, v5}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 382
    .line 383
    .line 384
    move-result-object v1

    .line 385
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 386
    .line 387
    .line 388
    const-string v1, "HMAC_SHA512_512BITTAG"

    .line 389
    .line 390
    invoke-static {v3, v3, v6, v4}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 391
    .line 392
    .line 393
    move-result-object v2

    .line 394
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 395
    .line 396
    .line 397
    const-string v1, "HMAC_SHA512_512BITTAG_RAW"

    .line 398
    .line 399
    invoke-static {v3, v3, v6, v5}, Lf6/b;->l(IILj6/o0;I)Le6/d;

    .line 400
    .line 401
    .line 402
    move-result-object v2

    .line 403
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 404
    .line 405
    .line 406
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 407
    .line 408
    .line 409
    move-result-object v0

    .line 410
    return-object v0

    .line 411
    :pswitch_8
    new-instance v0, Ljava/util/HashMap;

    .line 412
    .line 413
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 414
    .line 415
    .line 416
    new-instance v1, Le6/d;

    .line 417
    .line 418
    invoke-static {}, Lj6/d;->A()Lj6/c;

    .line 419
    .line 420
    .line 421
    move-result-object v2

    .line 422
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 423
    .line 424
    .line 425
    iget-object v3, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 426
    .line 427
    check-cast v3, Lj6/d;

    .line 428
    .line 429
    invoke-static {v3}, Lj6/d;->w(Lj6/d;)V

    .line 430
    .line 431
    .line 432
    invoke-static {}, Lj6/f;->z()Lj6/e;

    .line 433
    .line 434
    .line 435
    move-result-object v3

    .line 436
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 437
    .line 438
    .line 439
    iget-object v4, v3, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 440
    .line 441
    check-cast v4, Lj6/f;

    .line 442
    .line 443
    invoke-static {v4}, Lj6/f;->w(Lj6/f;)V

    .line 444
    .line 445
    .line 446
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 447
    .line 448
    .line 449
    move-result-object v3

    .line 450
    check-cast v3, Lj6/f;

    .line 451
    .line 452
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 453
    .line 454
    .line 455
    iget-object v4, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 456
    .line 457
    check-cast v4, Lj6/d;

    .line 458
    .line 459
    invoke-static {v4, v3}, Lj6/d;->x(Lj6/d;Lj6/f;)V

    .line 460
    .line 461
    .line 462
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 463
    .line 464
    .line 465
    move-result-object v2

    .line 466
    check-cast v2, Lj6/d;

    .line 467
    .line 468
    const/4 v3, 0x1

    .line 469
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 470
    .line 471
    .line 472
    const-string v2, "AES_CMAC"

    .line 473
    .line 474
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 475
    .line 476
    .line 477
    new-instance v1, Le6/d;

    .line 478
    .line 479
    invoke-static {}, Lj6/d;->A()Lj6/c;

    .line 480
    .line 481
    .line 482
    move-result-object v2

    .line 483
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 484
    .line 485
    .line 486
    iget-object v4, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 487
    .line 488
    check-cast v4, Lj6/d;

    .line 489
    .line 490
    invoke-static {v4}, Lj6/d;->w(Lj6/d;)V

    .line 491
    .line 492
    .line 493
    invoke-static {}, Lj6/f;->z()Lj6/e;

    .line 494
    .line 495
    .line 496
    move-result-object v4

    .line 497
    invoke-virtual {v4}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 498
    .line 499
    .line 500
    iget-object v5, v4, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 501
    .line 502
    check-cast v5, Lj6/f;

    .line 503
    .line 504
    invoke-static {v5}, Lj6/f;->w(Lj6/f;)V

    .line 505
    .line 506
    .line 507
    invoke-virtual {v4}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 508
    .line 509
    .line 510
    move-result-object v4

    .line 511
    check-cast v4, Lj6/f;

    .line 512
    .line 513
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 514
    .line 515
    .line 516
    iget-object v5, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 517
    .line 518
    check-cast v5, Lj6/d;

    .line 519
    .line 520
    invoke-static {v5, v4}, Lj6/d;->x(Lj6/d;Lj6/f;)V

    .line 521
    .line 522
    .line 523
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 524
    .line 525
    .line 526
    move-result-object v2

    .line 527
    check-cast v2, Lj6/d;

    .line 528
    .line 529
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 530
    .line 531
    .line 532
    const-string v2, "AES256_CMAC"

    .line 533
    .line 534
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 535
    .line 536
    .line 537
    new-instance v1, Le6/d;

    .line 538
    .line 539
    invoke-static {}, Lj6/d;->A()Lj6/c;

    .line 540
    .line 541
    .line 542
    move-result-object v2

    .line 543
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 544
    .line 545
    .line 546
    iget-object v3, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 547
    .line 548
    check-cast v3, Lj6/d;

    .line 549
    .line 550
    invoke-static {v3}, Lj6/d;->w(Lj6/d;)V

    .line 551
    .line 552
    .line 553
    invoke-static {}, Lj6/f;->z()Lj6/e;

    .line 554
    .line 555
    .line 556
    move-result-object v3

    .line 557
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 558
    .line 559
    .line 560
    iget-object v4, v3, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 561
    .line 562
    check-cast v4, Lj6/f;

    .line 563
    .line 564
    invoke-static {v4}, Lj6/f;->w(Lj6/f;)V

    .line 565
    .line 566
    .line 567
    invoke-virtual {v3}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 568
    .line 569
    .line 570
    move-result-object v3

    .line 571
    check-cast v3, Lj6/f;

    .line 572
    .line 573
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 574
    .line 575
    .line 576
    iget-object v4, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 577
    .line 578
    check-cast v4, Lj6/d;

    .line 579
    .line 580
    invoke-static {v4, v3}, Lj6/d;->x(Lj6/d;Lj6/f;)V

    .line 581
    .line 582
    .line 583
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 584
    .line 585
    .line 586
    move-result-object v2

    .line 587
    check-cast v2, Lj6/d;

    .line 588
    .line 589
    const/4 v3, 0x3

    .line 590
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 591
    .line 592
    .line 593
    const-string v2, "AES256_CMAC_RAW"

    .line 594
    .line 595
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 596
    .line 597
    .line 598
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 599
    .line 600
    .line 601
    move-result-object v0

    .line 602
    return-object v0

    .line 603
    :pswitch_9
    new-instance v0, Ljava/util/HashMap;

    .line 604
    .line 605
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 606
    .line 607
    .line 608
    new-instance v1, Le6/d;

    .line 609
    .line 610
    invoke-static {}, Lj6/h0;->y()Lj6/g0;

    .line 611
    .line 612
    .line 613
    move-result-object v2

    .line 614
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 615
    .line 616
    .line 617
    iget-object v3, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 618
    .line 619
    check-cast v3, Lj6/h0;

    .line 620
    .line 621
    invoke-static {v3}, Lj6/h0;->w(Lj6/h0;)V

    .line 622
    .line 623
    .line 624
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 625
    .line 626
    .line 627
    move-result-object v2

    .line 628
    check-cast v2, Lj6/h0;

    .line 629
    .line 630
    const/4 v3, 0x1

    .line 631
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 632
    .line 633
    .line 634
    const-string v2, "AES256_SIV"

    .line 635
    .line 636
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 637
    .line 638
    .line 639
    new-instance v1, Le6/d;

    .line 640
    .line 641
    invoke-static {}, Lj6/h0;->y()Lj6/g0;

    .line 642
    .line 643
    .line 644
    move-result-object v2

    .line 645
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 646
    .line 647
    .line 648
    iget-object v3, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 649
    .line 650
    check-cast v3, Lj6/h0;

    .line 651
    .line 652
    invoke-static {v3}, Lj6/h0;->w(Lj6/h0;)V

    .line 653
    .line 654
    .line 655
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 656
    .line 657
    .line 658
    move-result-object v2

    .line 659
    check-cast v2, Lj6/h0;

    .line 660
    .line 661
    const/4 v3, 0x3

    .line 662
    invoke-direct {v1, v2, v3}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 663
    .line 664
    .line 665
    const-string v2, "AES256_SIV_RAW"

    .line 666
    .line 667
    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 668
    .line 669
    .line 670
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 671
    .line 672
    .line 673
    move-result-object v0

    .line 674
    return-object v0

    .line 675
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public final c1(Lcom/google/crypto/tink/shaded/protobuf/j;)Lcom/google/crypto/tink/shaded/protobuf/a;
    .locals 1

    .line 1
    iget v0, p0, Lc6/b;->l:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {p1, v0}, Lj6/u1;->x(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/u1;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1

    .line 15
    :pswitch_0
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {p1, v0}, Lj6/p1;->A(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/p1;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1

    .line 24
    :pswitch_1
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {p1, v0}, Lj6/m1;->y(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/m1;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    return-object p1

    .line 33
    :pswitch_2
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {p1, v0}, Lj6/l0;->x(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/l0;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    return-object p1

    .line 42
    :pswitch_3
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-static {p1, v0}, Lj6/d0;->z(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/d0;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    return-object p1

    .line 51
    :pswitch_4
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {p1, v0}, Lj6/z;->z(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/z;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    return-object p1

    .line 60
    :pswitch_5
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-static {p1, v0}, Lj6/t;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/t;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    return-object p1

    .line 69
    :pswitch_6
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-static {p1, v0}, Lj6/j;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/j;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    return-object p1

    .line 78
    :pswitch_7
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-static {p1, v0}, Lj6/s0;->C(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/s0;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    return-object p1

    .line 87
    :pswitch_8
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    invoke-static {p1, v0}, Lj6/d;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/d;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    return-object p1

    .line 96
    :pswitch_9
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    invoke-static {p1, v0}, Lj6/h0;->z(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/h0;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    return-object p1

    .line 105
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final h1(Lcom/google/crypto/tink/shaded/protobuf/a;)V
    .locals 13

    .line 1
    iget v0, p0, Lc6/b;->l:I

    .line 2
    .line 3
    const-string v1, "key too short"

    .line 4
    .line 5
    const/16 v2, 0xc

    .line 6
    .line 7
    const/16 v3, 0x10

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast p1, Lj6/u1;

    .line 13
    .line 14
    return-void

    .line 15
    :pswitch_0
    check-cast p1, Lj6/p1;

    .line 16
    .line 17
    invoke-virtual {p1}, Lj6/p1;->y()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    invoke-virtual {p1}, Lj6/p1;->z()Z

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    if-eqz p1, :cond_0

    .line 32
    .line 33
    return-void

    .line 34
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 35
    .line 36
    const-string v0, "invalid key format: missing KEK URI or DEK template"

    .line 37
    .line 38
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw p1

    .line 42
    :pswitch_1
    check-cast p1, Lj6/m1;

    .line 43
    .line 44
    return-void

    .line 45
    :pswitch_2
    check-cast p1, Lj6/l0;

    .line 46
    .line 47
    return-void

    .line 48
    :pswitch_3
    check-cast p1, Lj6/d0;

    .line 49
    .line 50
    invoke-virtual {p1}, Lj6/d0;->x()I

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    invoke-static {p1}, Lk6/n;->a(I)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :pswitch_4
    check-cast p1, Lj6/z;

    .line 59
    .line 60
    invoke-virtual {p1}, Lj6/z;->x()I

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    invoke-static {p1}, Lk6/n;->a(I)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :pswitch_5
    check-cast p1, Lj6/t;

    .line 69
    .line 70
    invoke-virtual {p1}, Lj6/t;->y()I

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    invoke-static {v0}, Lk6/n;->a(I)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p1}, Lj6/t;->z()Lj6/v;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-virtual {v0}, Lj6/v;->y()I

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-eq v0, v2, :cond_2

    .line 86
    .line 87
    invoke-virtual {p1}, Lj6/t;->z()Lj6/v;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    invoke-virtual {p1}, Lj6/v;->y()I

    .line 92
    .line 93
    .line 94
    move-result p1

    .line 95
    if-ne p1, v3, :cond_1

    .line 96
    .line 97
    goto :goto_0

    .line 98
    :cond_1
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 99
    .line 100
    const-string v0, "invalid IV size; acceptable values have 12 or 16 bytes"

    .line 101
    .line 102
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    throw p1

    .line 106
    :cond_2
    :goto_0
    return-void

    .line 107
    :pswitch_6
    check-cast p1, Lj6/j;

    .line 108
    .line 109
    new-instance v0, Lc6/a;

    .line 110
    .line 111
    const-class v4, Lk6/j;

    .line 112
    .line 113
    const/4 v5, 0x4

    .line 114
    invoke-direct {v0, v5, v4}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 115
    .line 116
    .line 117
    const/4 v4, 0x1

    .line 118
    new-array v5, v4, [Lc6/a;

    .line 119
    .line 120
    const/4 v6, 0x0

    .line 121
    aput-object v0, v5, v6

    .line 122
    .line 123
    new-instance v0, Ljava/util/HashMap;

    .line 124
    .line 125
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 126
    .line 127
    .line 128
    array-length v7, v5

    .line 129
    move v8, v6

    .line 130
    :goto_1
    const-string v9, "KeyTypeManager constructed with duplicate factories for primitive "

    .line 131
    .line 132
    if-ge v8, v7, :cond_4

    .line 133
    .line 134
    aget-object v10, v5, v8

    .line 135
    .line 136
    iget-object v11, v10, Lc6/a;->a:Ljava/lang/Class;

    .line 137
    .line 138
    invoke-virtual {v0, v11}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v12

    .line 142
    if-nez v12, :cond_3

    .line 143
    .line 144
    invoke-virtual {v0, v11, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    add-int/lit8 v8, v8, 0x1

    .line 148
    .line 149
    goto :goto_1

    .line 150
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 151
    .line 152
    new-instance v0, Ljava/lang/StringBuilder;

    .line 153
    .line 154
    invoke-direct {v0, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v11}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 162
    .line 163
    .line 164
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 169
    .line 170
    .line 171
    throw p1

    .line 172
    :cond_4
    array-length v7, v5

    .line 173
    if-lez v7, :cond_5

    .line 174
    .line 175
    aget-object v5, v5, v6

    .line 176
    .line 177
    iget-object v5, v5, Lc6/a;->a:Ljava/lang/Class;

    .line 178
    .line 179
    :cond_5
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 180
    .line 181
    .line 182
    invoke-virtual {p1}, Lj6/j;->y()Lj6/n;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    invoke-virtual {v0}, Lj6/n;->z()I

    .line 187
    .line 188
    .line 189
    move-result v5

    .line 190
    invoke-static {v5}, Lk6/n;->a(I)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v0}, Lj6/n;->A()Lj6/p;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-virtual {v0}, Lj6/p;->y()I

    .line 198
    .line 199
    .line 200
    move-result v5

    .line 201
    if-lt v5, v2, :cond_a

    .line 202
    .line 203
    invoke-virtual {v0}, Lj6/p;->y()I

    .line 204
    .line 205
    .line 206
    move-result v0

    .line 207
    if-gt v0, v3, :cond_a

    .line 208
    .line 209
    new-instance v0, Lc6/a;

    .line 210
    .line 211
    const-class v2, Lx5/j;

    .line 212
    .line 213
    const/4 v5, 0x2

    .line 214
    invoke-direct {v0, v5, v2}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 215
    .line 216
    .line 217
    new-array v2, v4, [Lc6/a;

    .line 218
    .line 219
    aput-object v0, v2, v6

    .line 220
    .line 221
    new-instance v0, Ljava/util/HashMap;

    .line 222
    .line 223
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 224
    .line 225
    .line 226
    array-length v4, v2

    .line 227
    move v5, v6

    .line 228
    :goto_2
    if-ge v5, v4, :cond_7

    .line 229
    .line 230
    aget-object v7, v2, v5

    .line 231
    .line 232
    iget-object v8, v7, Lc6/a;->a:Ljava/lang/Class;

    .line 233
    .line 234
    invoke-virtual {v0, v8}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 235
    .line 236
    .line 237
    move-result v10

    .line 238
    if-nez v10, :cond_6

    .line 239
    .line 240
    invoke-virtual {v0, v8, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    add-int/lit8 v5, v5, 0x1

    .line 244
    .line 245
    goto :goto_2

    .line 246
    :cond_6
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 247
    .line 248
    new-instance v0, Ljava/lang/StringBuilder;

    .line 249
    .line 250
    invoke-direct {v0, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v8}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 258
    .line 259
    .line 260
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object v0

    .line 264
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 265
    .line 266
    .line 267
    throw p1

    .line 268
    :cond_7
    array-length v4, v2

    .line 269
    if-lez v4, :cond_8

    .line 270
    .line 271
    aget-object v2, v2, v6

    .line 272
    .line 273
    iget-object v2, v2, Lc6/a;->a:Ljava/lang/Class;

    .line 274
    .line 275
    :cond_8
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 276
    .line 277
    .line 278
    invoke-virtual {p1}, Lj6/j;->z()Lj6/s0;

    .line 279
    .line 280
    .line 281
    move-result-object v0

    .line 282
    invoke-virtual {v0}, Lj6/s0;->z()I

    .line 283
    .line 284
    .line 285
    move-result v2

    .line 286
    if-lt v2, v3, :cond_9

    .line 287
    .line 288
    invoke-virtual {v0}, Lj6/s0;->A()Lj6/u0;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    invoke-static {v0}, Lf6/b;->n(Lj6/u0;)V

    .line 293
    .line 294
    .line 295
    invoke-virtual {p1}, Lj6/j;->y()Lj6/n;

    .line 296
    .line 297
    .line 298
    move-result-object p1

    .line 299
    invoke-virtual {p1}, Lj6/n;->z()I

    .line 300
    .line 301
    .line 302
    move-result p1

    .line 303
    invoke-static {p1}, Lk6/n;->a(I)V

    .line 304
    .line 305
    .line 306
    return-void

    .line 307
    :cond_9
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 308
    .line 309
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 310
    .line 311
    .line 312
    throw p1

    .line 313
    :cond_a
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 314
    .line 315
    const-string v0, "invalid IV size"

    .line 316
    .line 317
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 318
    .line 319
    .line 320
    throw p1

    .line 321
    :pswitch_7
    check-cast p1, Lj6/s0;

    .line 322
    .line 323
    invoke-virtual {p1}, Lj6/s0;->z()I

    .line 324
    .line 325
    .line 326
    move-result v0

    .line 327
    if-lt v0, v3, :cond_b

    .line 328
    .line 329
    invoke-virtual {p1}, Lj6/s0;->A()Lj6/u0;

    .line 330
    .line 331
    .line 332
    move-result-object p1

    .line 333
    invoke-static {p1}, Lf6/b;->n(Lj6/u0;)V

    .line 334
    .line 335
    .line 336
    return-void

    .line 337
    :cond_b
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 338
    .line 339
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 340
    .line 341
    .line 342
    throw p1

    .line 343
    :pswitch_8
    check-cast p1, Lj6/d;

    .line 344
    .line 345
    invoke-virtual {p1}, Lj6/d;->z()Lj6/f;

    .line 346
    .line 347
    .line 348
    move-result-object v0

    .line 349
    invoke-static {v0}, Lf6/b;->m(Lj6/f;)V

    .line 350
    .line 351
    .line 352
    invoke-virtual {p1}, Lj6/d;->y()I

    .line 353
    .line 354
    .line 355
    move-result p1

    .line 356
    const/16 v0, 0x20

    .line 357
    .line 358
    if-ne p1, v0, :cond_c

    .line 359
    .line 360
    return-void

    .line 361
    :cond_c
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 362
    .line 363
    const-string v0, "AesCmacKey size wrong, must be 32 bytes"

    .line 364
    .line 365
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 366
    .line 367
    .line 368
    throw p1

    .line 369
    :pswitch_9
    check-cast p1, Lj6/h0;

    .line 370
    .line 371
    invoke-virtual {p1}, Lj6/h0;->x()I

    .line 372
    .line 373
    .line 374
    move-result v0

    .line 375
    const/16 v1, 0x40

    .line 376
    .line 377
    if-ne v0, v1, :cond_d

    .line 378
    .line 379
    return-void

    .line 380
    :cond_d
    new-instance v0, Ljava/security/InvalidAlgorithmParameterException;

    .line 381
    .line 382
    new-instance v1, Ljava/lang/StringBuilder;

    .line 383
    .line 384
    const-string v2, "invalid key size: "

    .line 385
    .line 386
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 387
    .line 388
    .line 389
    invoke-virtual {p1}, Lj6/h0;->x()I

    .line 390
    .line 391
    .line 392
    move-result p1

    .line 393
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 394
    .line 395
    .line 396
    const-string p1, ". Valid keys must have 64 bytes."

    .line 397
    .line 398
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object p1

    .line 405
    invoke-direct {v0, p1}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    .line 406
    .line 407
    .line 408
    throw v0

    .line 409
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
