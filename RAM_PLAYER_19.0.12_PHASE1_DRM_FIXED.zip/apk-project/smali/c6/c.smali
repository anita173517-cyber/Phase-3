.class public final Lc6/c;
.super Le6/f;
.source "SourceFile"


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Class;[Lc6/a;I)V
    .locals 0

    .line 1
    iput p3, p0, Lc6/c;->d:I

    invoke-direct {p0, p1, p2}, Le6/f;-><init>(Ljava/lang/Class;[Lc6/a;)V

    return-void
.end method

.method public static l(II)Le6/d;
    .locals 2

    .line 1
    invoke-static {}, Lj6/t;->A()Lj6/s;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 9
    .line 10
    check-cast v1, Lj6/t;

    .line 11
    .line 12
    invoke-static {v1, p0}, Lj6/t;->x(Lj6/t;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {}, Lj6/v;->z()Lj6/u;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-virtual {p0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 20
    .line 21
    .line 22
    iget-object v1, p0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 23
    .line 24
    check-cast v1, Lj6/v;

    .line 25
    .line 26
    invoke-static {v1}, Lj6/v;->w(Lj6/v;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    check-cast p0, Lj6/v;

    .line 34
    .line 35
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 36
    .line 37
    .line 38
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 39
    .line 40
    check-cast v1, Lj6/t;

    .line 41
    .line 42
    invoke-static {v1, p0}, Lj6/t;->w(Lj6/t;Lj6/v;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    check-cast p0, Lj6/t;

    .line 50
    .line 51
    new-instance v0, Le6/d;

    .line 52
    .line 53
    invoke-direct {v0, p0, p1}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 54
    .line 55
    .line 56
    return-object v0
.end method

.method public static m(III)Le6/d;
    .locals 5

    .line 1
    new-instance v0, Le6/d;

    .line 2
    .line 3
    invoke-static {}, Lj6/n;->B()Lj6/m;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {}, Lj6/p;->z()Lj6/o;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 12
    .line 13
    .line 14
    iget-object v3, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 15
    .line 16
    check-cast v3, Lj6/p;

    .line 17
    .line 18
    invoke-static {v3}, Lj6/p;->w(Lj6/p;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Lj6/p;

    .line 26
    .line 27
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 28
    .line 29
    .line 30
    iget-object v3, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 31
    .line 32
    check-cast v3, Lj6/n;

    .line 33
    .line 34
    invoke-static {v3, v2}, Lj6/n;->w(Lj6/n;Lj6/p;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 38
    .line 39
    .line 40
    iget-object v2, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 41
    .line 42
    check-cast v2, Lj6/n;

    .line 43
    .line 44
    invoke-static {v2, p0}, Lj6/n;->x(Lj6/n;I)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    check-cast p0, Lj6/n;

    .line 52
    .line 53
    invoke-static {}, Lj6/s0;->B()Lj6/r0;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    invoke-static {}, Lj6/u0;->B()Lj6/t0;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 62
    .line 63
    .line 64
    iget-object v3, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 65
    .line 66
    check-cast v3, Lj6/u0;

    .line 67
    .line 68
    sget-object v4, Lj6/o0;->o:Lj6/o0;

    .line 69
    .line 70
    invoke-static {v3, v4}, Lj6/u0;->w(Lj6/u0;Lj6/o0;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 74
    .line 75
    .line 76
    iget-object v3, v2, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 77
    .line 78
    check-cast v3, Lj6/u0;

    .line 79
    .line 80
    invoke-static {v3, p1}, Lj6/u0;->x(Lj6/u0;I)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v2}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    check-cast p1, Lj6/u0;

    .line 88
    .line 89
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 90
    .line 91
    .line 92
    iget-object v2, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 93
    .line 94
    check-cast v2, Lj6/s0;

    .line 95
    .line 96
    invoke-static {v2, p1}, Lj6/s0;->w(Lj6/s0;Lj6/u0;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 100
    .line 101
    .line 102
    iget-object p1, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 103
    .line 104
    check-cast p1, Lj6/s0;

    .line 105
    .line 106
    const/16 v2, 0x20

    .line 107
    .line 108
    invoke-static {p1, v2}, Lj6/s0;->x(Lj6/s0;I)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    check-cast p1, Lj6/s0;

    .line 116
    .line 117
    invoke-static {}, Lj6/j;->A()Lj6/i;

    .line 118
    .line 119
    .line 120
    move-result-object v1

    .line 121
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 122
    .line 123
    .line 124
    iget-object v2, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 125
    .line 126
    check-cast v2, Lj6/j;

    .line 127
    .line 128
    invoke-static {v2, p0}, Lj6/j;->w(Lj6/j;Lj6/n;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 132
    .line 133
    .line 134
    iget-object p0, v1, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 135
    .line 136
    check-cast p0, Lj6/j;

    .line 137
    .line 138
    invoke-static {p0, p1}, Lj6/j;->x(Lj6/j;Lj6/s0;)V

    .line 139
    .line 140
    .line 141
    invoke-virtual {v1}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 142
    .line 143
    .line 144
    move-result-object p0

    .line 145
    check-cast p0, Lj6/j;

    .line 146
    .line 147
    invoke-direct {v0, p0, p2}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 148
    .line 149
    .line 150
    return-object v0
.end method

.method public static n(II)Le6/d;
    .locals 2

    .line 1
    invoke-static {}, Lj6/z;->y()Lj6/y;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 9
    .line 10
    check-cast v1, Lj6/z;

    .line 11
    .line 12
    invoke-static {v1, p0}, Lj6/z;->w(Lj6/z;I)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    check-cast p0, Lj6/z;

    .line 20
    .line 21
    new-instance v0, Le6/d;

    .line 22
    .line 23
    invoke-direct {v0, p0, p1}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 24
    .line 25
    .line 26
    return-object v0
.end method

.method public static o(II)Le6/d;
    .locals 2

    .line 1
    invoke-static {}, Lj6/d0;->y()Lj6/c0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->e()V

    .line 6
    .line 7
    .line 8
    iget-object v1, v0, Lcom/google/crypto/tink/shaded/protobuf/x;->l:Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 9
    .line 10
    check-cast v1, Lj6/d0;

    .line 11
    .line 12
    invoke-static {v1, p0}, Lj6/d0;->w(Lj6/d0;I)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/x;->b()Lcom/google/crypto/tink/shaded/protobuf/z;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    check-cast p0, Lj6/d0;

    .line 20
    .line 21
    new-instance v0, Le6/d;

    .line 22
    .line 23
    invoke-direct {v0, p0, p1}, Le6/d;-><init>(Lcom/google/crypto/tink/shaded/protobuf/z;I)V

    .line 24
    .line 25
    .line 26
    return-object v0
.end method


# virtual methods
.method public d()I
    .locals 1

    .line 1
    iget v0, p0, Lc6/c;->d:I

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    invoke-super {p0}, Le6/f;->d()I

    move-result v0

    return v0

    :pswitch_1
    const/4 v0, 0x2

    return v0

    :pswitch_2
    const/4 v0, 0x2

    return v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public final e()Ljava/lang/String;
    .locals 1

    .line 1
    iget v0, p0, Lc6/c;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key"

    .line 7
    .line 8
    return-object v0

    .line 9
    :pswitch_0
    const-string v0, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    .line 10
    .line 11
    return-object v0

    .line 12
    :pswitch_1
    const-string v0, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_2
    const-string v0, "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key"

    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_3
    const-string v0, "type.googleapis.com/google.crypto.tink.AesGcmSivKey"

    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_4
    const-string v0, "type.googleapis.com/google.crypto.tink.AesGcmKey"

    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_5
    const-string v0, "type.googleapis.com/google.crypto.tink.AesEaxKey"

    .line 25
    .line 26
    return-object v0

    .line 27
    :pswitch_6
    const-string v0, "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey"

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_7
    const-string v0, "type.googleapis.com/google.crypto.tink.AesSivKey"

    .line 31
    .line 32
    return-object v0

    .line 33
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final g()Le6/e;
    .locals 3

    .line 1
    iget v0, p0, Lc6/c;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, Lc6/b;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-direct {v0, p0, v1, v2}, Lc6/b;-><init>(Lc6/c;BI)V

    .line 11
    .line 12
    .line 13
    return-object v0

    .line 14
    :pswitch_0
    new-instance v0, Lc6/b;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-direct {v0, p0, v1, v2}, Lc6/b;-><init>(Lc6/c;BC)V

    .line 19
    .line 20
    .line 21
    return-object v0

    .line 22
    :pswitch_1
    new-instance v0, Lc6/b;

    .line 23
    .line 24
    const/4 v1, 0x0

    .line 25
    invoke-direct {v0, p0, v1, v1}, Lc6/b;-><init>(Lc6/c;BB)V

    .line 26
    .line 27
    .line 28
    return-object v0

    .line 29
    :pswitch_2
    new-instance v0, Lc6/b;

    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    const/4 v2, 0x0

    .line 33
    invoke-direct {v0, p0, v1, v2}, Lc6/b;-><init>(Lc6/c;BZ)V

    .line 34
    .line 35
    .line 36
    return-object v0

    .line 37
    :pswitch_3
    new-instance v0, Lc6/b;

    .line 38
    .line 39
    const/4 v1, 0x0

    .line 40
    invoke-direct {v0, p0, v1}, Lc6/b;-><init>(Lc6/c;S)V

    .line 41
    .line 42
    .line 43
    return-object v0

    .line 44
    :pswitch_4
    new-instance v0, Lc6/b;

    .line 45
    .line 46
    const/4 v1, 0x0

    .line 47
    invoke-direct {v0, p0, v1}, Lc6/b;-><init>(Lc6/c;I)V

    .line 48
    .line 49
    .line 50
    return-object v0

    .line 51
    :pswitch_5
    new-instance v0, Lc6/b;

    .line 52
    .line 53
    const/4 v1, 0x0

    .line 54
    invoke-direct {v0, p0, v1}, Lc6/b;-><init>(Lc6/c;C)V

    .line 55
    .line 56
    .line 57
    return-object v0

    .line 58
    :pswitch_6
    new-instance v0, Lc6/b;

    .line 59
    .line 60
    const/4 v1, 0x0

    .line 61
    invoke-direct {v0, p0, v1}, Lc6/b;-><init>(Lc6/c;B)V

    .line 62
    .line 63
    .line 64
    return-object v0

    .line 65
    :pswitch_7
    new-instance v0, Lc6/b;

    .line 66
    .line 67
    invoke-direct {v0, p0}, Lc6/b;-><init>(Lc6/c;)V

    .line 68
    .line 69
    .line 70
    return-object v0

    .line 71
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final h()Lj6/w0;
    .locals 1

    .line 1
    iget v0, p0, Lc6/c;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget-object v0, Lj6/w0;->m:Lj6/w0;

    .line 7
    .line 8
    return-object v0

    .line 9
    :pswitch_0
    sget-object v0, Lj6/w0;->p:Lj6/w0;

    .line 10
    .line 11
    return-object v0

    .line 12
    :pswitch_1
    sget-object v0, Lj6/w0;->p:Lj6/w0;

    .line 13
    .line 14
    return-object v0

    .line 15
    :pswitch_2
    sget-object v0, Lj6/w0;->m:Lj6/w0;

    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_3
    sget-object v0, Lj6/w0;->m:Lj6/w0;

    .line 19
    .line 20
    return-object v0

    .line 21
    :pswitch_4
    sget-object v0, Lj6/w0;->m:Lj6/w0;

    .line 22
    .line 23
    return-object v0

    .line 24
    :pswitch_5
    sget-object v0, Lj6/w0;->m:Lj6/w0;

    .line 25
    .line 26
    return-object v0

    .line 27
    :pswitch_6
    sget-object v0, Lj6/w0;->m:Lj6/w0;

    .line 28
    .line 29
    return-object v0

    .line 30
    :pswitch_7
    sget-object v0, Lj6/w0;->m:Lj6/w0;

    .line 31
    .line 32
    return-object v0

    .line 33
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final i(Lcom/google/crypto/tink/shaded/protobuf/j;)Lcom/google/crypto/tink/shaded/protobuf/a;
    .locals 1

    .line 1
    iget v0, p0, Lc6/c;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    invoke-static {p1, v0}, Lj6/t1;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/t1;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    return-object p1

    .line 15
    :pswitch_0
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {p1, v0}, Lj6/o1;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/o1;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1

    .line 24
    :pswitch_1
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-static {p1, v0}, Lj6/l1;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/l1;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    return-object p1

    .line 33
    :pswitch_2
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-static {p1, v0}, Lj6/j0;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/j0;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    return-object p1

    .line 42
    :pswitch_3
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-static {p1, v0}, Lj6/b0;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/b0;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    return-object p1

    .line 51
    :pswitch_4
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {p1, v0}, Lj6/x;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/x;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    return-object p1

    .line 60
    :pswitch_5
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    invoke-static {p1, v0}, Lj6/r;->D(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/r;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    return-object p1

    .line 69
    :pswitch_6
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-static {p1, v0}, Lj6/h;->D(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/h;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    return-object p1

    .line 78
    :pswitch_7
    invoke-static {}, Lcom/google/crypto/tink/shaded/protobuf/r;->a()Lcom/google/crypto/tink/shaded/protobuf/r;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-static {p1, v0}, Lj6/f0;->B(Lcom/google/crypto/tink/shaded/protobuf/j;Lcom/google/crypto/tink/shaded/protobuf/r;)Lj6/f0;

    .line 83
    .line 84
    .line 85
    move-result-object p1

    .line 86
    return-object p1

    .line 87
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final k(Lcom/google/crypto/tink/shaded/protobuf/a;)V
    .locals 10

    .line 1
    iget v0, p0, Lc6/c;->d:I

    .line 2
    .line 3
    const/16 v1, 0x10

    .line 4
    .line 5
    const/16 v2, 0xc

    .line 6
    .line 7
    const/16 v3, 0x20

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    check-cast p1, Lj6/t1;

    .line 13
    .line 14
    invoke-virtual {p1}, Lj6/t1;->z()I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    invoke-static {v0}, Lk6/n;->c(I)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1}, Lj6/t1;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 26
    .line 27
    .line 28
    move-result p1

    .line 29
    if-ne p1, v3, :cond_0

    .line 30
    .line 31
    return-void

    .line 32
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 33
    .line 34
    const-string v0, "invalid XChaCha20Poly1305Key: incorrect key length"

    .line 35
    .line 36
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    throw p1

    .line 40
    :pswitch_0
    check-cast p1, Lj6/o1;

    .line 41
    .line 42
    invoke-virtual {p1}, Lj6/o1;->z()I

    .line 43
    .line 44
    .line 45
    move-result p1

    .line 46
    invoke-static {p1}, Lk6/n;->c(I)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :pswitch_1
    check-cast p1, Lj6/l1;

    .line 51
    .line 52
    invoke-virtual {p1}, Lj6/l1;->z()I

    .line 53
    .line 54
    .line 55
    move-result p1

    .line 56
    invoke-static {p1}, Lk6/n;->c(I)V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :pswitch_2
    check-cast p1, Lj6/j0;

    .line 61
    .line 62
    invoke-virtual {p1}, Lj6/j0;->z()I

    .line 63
    .line 64
    .line 65
    move-result v0

    .line 66
    invoke-static {v0}, Lk6/n;->c(I)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1}, Lj6/j0;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    if-ne p1, v3, :cond_1

    .line 78
    .line 79
    return-void

    .line 80
    :cond_1
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 81
    .line 82
    const-string v0, "invalid ChaCha20Poly1305Key: incorrect key length"

    .line 83
    .line 84
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    throw p1

    .line 88
    :pswitch_3
    check-cast p1, Lj6/b0;

    .line 89
    .line 90
    invoke-virtual {p1}, Lj6/b0;->z()I

    .line 91
    .line 92
    .line 93
    move-result v0

    .line 94
    invoke-static {v0}, Lk6/n;->c(I)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {p1}, Lj6/b0;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 102
    .line 103
    .line 104
    move-result p1

    .line 105
    invoke-static {p1}, Lk6/n;->a(I)V

    .line 106
    .line 107
    .line 108
    return-void

    .line 109
    :pswitch_4
    check-cast p1, Lj6/x;

    .line 110
    .line 111
    invoke-virtual {p1}, Lj6/x;->z()I

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    invoke-static {v0}, Lk6/n;->c(I)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {p1}, Lj6/x;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 119
    .line 120
    .line 121
    move-result-object p1

    .line 122
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 123
    .line 124
    .line 125
    move-result p1

    .line 126
    invoke-static {p1}, Lk6/n;->a(I)V

    .line 127
    .line 128
    .line 129
    return-void

    .line 130
    :pswitch_5
    check-cast p1, Lj6/r;

    .line 131
    .line 132
    invoke-virtual {p1}, Lj6/r;->B()I

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    invoke-static {v0}, Lk6/n;->c(I)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {p1}, Lj6/r;->z()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 144
    .line 145
    .line 146
    move-result v0

    .line 147
    invoke-static {v0}, Lk6/n;->a(I)V

    .line 148
    .line 149
    .line 150
    invoke-virtual {p1}, Lj6/r;->A()Lj6/v;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    invoke-virtual {v0}, Lj6/v;->y()I

    .line 155
    .line 156
    .line 157
    move-result v0

    .line 158
    if-eq v0, v2, :cond_3

    .line 159
    .line 160
    invoke-virtual {p1}, Lj6/r;->A()Lj6/v;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    invoke-virtual {p1}, Lj6/v;->y()I

    .line 165
    .line 166
    .line 167
    move-result p1

    .line 168
    if-ne p1, v1, :cond_2

    .line 169
    .line 170
    goto :goto_0

    .line 171
    :cond_2
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 172
    .line 173
    const-string v0, "invalid IV size; acceptable values have 12 or 16 bytes"

    .line 174
    .line 175
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 176
    .line 177
    .line 178
    throw p1

    .line 179
    :cond_3
    :goto_0
    return-void

    .line 180
    :pswitch_6
    check-cast p1, Lj6/h;

    .line 181
    .line 182
    invoke-virtual {p1}, Lj6/h;->B()I

    .line 183
    .line 184
    .line 185
    move-result v0

    .line 186
    invoke-static {v0}, Lk6/n;->c(I)V

    .line 187
    .line 188
    .line 189
    new-instance v0, Lc6/a;

    .line 190
    .line 191
    const-class v3, Lk6/j;

    .line 192
    .line 193
    const/4 v4, 0x4

    .line 194
    invoke-direct {v0, v4, v3}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 195
    .line 196
    .line 197
    const/4 v3, 0x1

    .line 198
    new-array v4, v3, [Lc6/a;

    .line 199
    .line 200
    const/4 v5, 0x0

    .line 201
    aput-object v0, v4, v5

    .line 202
    .line 203
    new-instance v0, Ljava/util/HashMap;

    .line 204
    .line 205
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 206
    .line 207
    .line 208
    aget-object v6, v4, v5

    .line 209
    .line 210
    iget-object v7, v6, Lc6/a;->a:Ljava/lang/Class;

    .line 211
    .line 212
    invoke-virtual {v0, v7}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 213
    .line 214
    .line 215
    move-result v8

    .line 216
    const-string v9, "KeyTypeManager constructed with duplicate factories for primitive "

    .line 217
    .line 218
    if-nez v8, :cond_7

    .line 219
    .line 220
    invoke-virtual {v0, v7, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 221
    .line 222
    .line 223
    aget-object v4, v4, v5

    .line 224
    .line 225
    iget-object v4, v4, Lc6/a;->a:Ljava/lang/Class;

    .line 226
    .line 227
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 228
    .line 229
    .line 230
    invoke-virtual {p1}, Lj6/h;->z()Lj6/l;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    invoke-virtual {v0}, Lj6/l;->C()I

    .line 235
    .line 236
    .line 237
    move-result v4

    .line 238
    invoke-static {v4}, Lk6/n;->c(I)V

    .line 239
    .line 240
    .line 241
    invoke-virtual {v0}, Lj6/l;->A()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 242
    .line 243
    .line 244
    move-result-object v4

    .line 245
    invoke-virtual {v4}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 246
    .line 247
    .line 248
    move-result v4

    .line 249
    invoke-static {v4}, Lk6/n;->a(I)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v0}, Lj6/l;->B()Lj6/p;

    .line 253
    .line 254
    .line 255
    move-result-object v0

    .line 256
    invoke-virtual {v0}, Lj6/p;->y()I

    .line 257
    .line 258
    .line 259
    move-result v4

    .line 260
    if-lt v4, v2, :cond_6

    .line 261
    .line 262
    invoke-virtual {v0}, Lj6/p;->y()I

    .line 263
    .line 264
    .line 265
    move-result v0

    .line 266
    if-gt v0, v1, :cond_6

    .line 267
    .line 268
    new-instance v0, Lc6/a;

    .line 269
    .line 270
    const-class v2, Lx5/j;

    .line 271
    .line 272
    const/4 v4, 0x2

    .line 273
    invoke-direct {v0, v4, v2}, Lc6/a;-><init>(ILjava/lang/Class;)V

    .line 274
    .line 275
    .line 276
    new-array v2, v3, [Lc6/a;

    .line 277
    .line 278
    aput-object v0, v2, v5

    .line 279
    .line 280
    new-instance v0, Ljava/util/HashMap;

    .line 281
    .line 282
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 283
    .line 284
    .line 285
    aget-object v3, v2, v5

    .line 286
    .line 287
    iget-object v4, v3, Lc6/a;->a:Ljava/lang/Class;

    .line 288
    .line 289
    invoke-virtual {v0, v4}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 290
    .line 291
    .line 292
    move-result v6

    .line 293
    if-nez v6, :cond_5

    .line 294
    .line 295
    invoke-virtual {v0, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 296
    .line 297
    .line 298
    aget-object v2, v2, v5

    .line 299
    .line 300
    iget-object v2, v2, Lc6/a;->a:Ljava/lang/Class;

    .line 301
    .line 302
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 303
    .line 304
    .line 305
    invoke-virtual {p1}, Lj6/h;->A()Lj6/q0;

    .line 306
    .line 307
    .line 308
    move-result-object p1

    .line 309
    invoke-virtual {p1}, Lj6/q0;->C()I

    .line 310
    .line 311
    .line 312
    move-result v0

    .line 313
    invoke-static {v0}, Lk6/n;->c(I)V

    .line 314
    .line 315
    .line 316
    invoke-virtual {p1}, Lj6/q0;->A()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 317
    .line 318
    .line 319
    move-result-object v0

    .line 320
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 321
    .line 322
    .line 323
    move-result v0

    .line 324
    if-lt v0, v1, :cond_4

    .line 325
    .line 326
    invoke-virtual {p1}, Lj6/q0;->B()Lj6/u0;

    .line 327
    .line 328
    .line 329
    move-result-object p1

    .line 330
    invoke-static {p1}, Lf6/b;->n(Lj6/u0;)V

    .line 331
    .line 332
    .line 333
    return-void

    .line 334
    :cond_4
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 335
    .line 336
    const-string v0, "key too short"

    .line 337
    .line 338
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 339
    .line 340
    .line 341
    throw p1

    .line 342
    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 343
    .line 344
    new-instance v0, Ljava/lang/StringBuilder;

    .line 345
    .line 346
    invoke-direct {v0, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 347
    .line 348
    .line 349
    invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object v1

    .line 353
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 354
    .line 355
    .line 356
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 357
    .line 358
    .line 359
    move-result-object v0

    .line 360
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    throw p1

    .line 364
    :cond_6
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 365
    .line 366
    const-string v0, "invalid IV size"

    .line 367
    .line 368
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 369
    .line 370
    .line 371
    throw p1

    .line 372
    :cond_7
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 373
    .line 374
    new-instance v0, Ljava/lang/StringBuilder;

    .line 375
    .line 376
    invoke-direct {v0, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 377
    .line 378
    .line 379
    invoke-virtual {v7}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 380
    .line 381
    .line 382
    move-result-object v1

    .line 383
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 384
    .line 385
    .line 386
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 387
    .line 388
    .line 389
    move-result-object v0

    .line 390
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 391
    .line 392
    .line 393
    throw p1

    .line 394
    :pswitch_7
    check-cast p1, Lj6/f0;

    .line 395
    .line 396
    invoke-virtual {p1}, Lj6/f0;->z()I

    .line 397
    .line 398
    .line 399
    move-result v0

    .line 400
    invoke-static {v0}, Lk6/n;->c(I)V

    .line 401
    .line 402
    .line 403
    invoke-virtual {p1}, Lj6/f0;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 404
    .line 405
    .line 406
    move-result-object v0

    .line 407
    invoke-virtual {v0}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 408
    .line 409
    .line 410
    move-result v0

    .line 411
    const/16 v1, 0x40

    .line 412
    .line 413
    if-ne v0, v1, :cond_8

    .line 414
    .line 415
    return-void

    .line 416
    :cond_8
    new-instance v0, Ljava/security/InvalidKeyException;

    .line 417
    .line 418
    new-instance v1, Ljava/lang/StringBuilder;

    .line 419
    .line 420
    const-string v2, "invalid key size: "

    .line 421
    .line 422
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 423
    .line 424
    .line 425
    invoke-virtual {p1}, Lj6/f0;->y()Lcom/google/crypto/tink/shaded/protobuf/j;

    .line 426
    .line 427
    .line 428
    move-result-object p1

    .line 429
    invoke-virtual {p1}, Lcom/google/crypto/tink/shaded/protobuf/j;->size()I

    .line 430
    .line 431
    .line 432
    move-result p1

    .line 433
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 434
    .line 435
    .line 436
    const-string p1, ". Valid keys must have 64 bytes."

    .line 437
    .line 438
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 439
    .line 440
    .line 441
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 442
    .line 443
    .line 444
    move-result-object p1

    .line 445
    invoke-direct {v0, p1}, Ljava/security/InvalidKeyException;-><init>(Ljava/lang/String;)V

    .line 446
    .line 447
    .line 448
    throw v0

    .line 449
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
