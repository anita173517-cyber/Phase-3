.class public final Lc1/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I

.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;

.field public h:Ljava/lang/Object;

.field public final i:Ljava/lang/Object;

.field public final j:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    new-instance v0, Landroid/media/MediaCodec$CryptoInfo;

    invoke-direct {v0}, Landroid/media/MediaCodec$CryptoInfo;-><init>()V

    iput-object v0, p0, Lc1/c;->i:Ljava/lang/Object;

    .line 18
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x18

    if-lt v1, v2, :cond_0

    new-instance v1, Ll4/l;

    .line 19
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 20
    iput-object v0, v1, Ll4/l;->k:Ljava/lang/Object;

    .line 21
    invoke-static {}, La0/k;->e()Landroid/media/MediaCodec$CryptoInfo$Pattern;

    move-result-object v0

    iput-object v0, v1, Ll4/l;->l:Ljava/lang/Object;

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    .line 22
    :goto_0
    iput-object v1, p0, Lc1/c;->j:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lc4/r;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    .line 2
    invoke-static {p1}, Lw0/h;->a(Z)Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    iput-object p1, p0, Lc1/c;->e:Ljava/lang/Object;

    const/4 p1, 0x1

    .line 3
    invoke-static {p1}, Lw0/h;->a(Z)Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    iput-object p1, p0, Lc1/c;->f:Ljava/lang/Object;

    .line 4
    new-instance p1, Lc4/r;

    .line 5
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Lc1/c;->g:Ljava/lang/Object;

    .line 7
    new-instance p1, Lc4/d0;

    .line 8
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 9
    iput-object p1, p0, Lc1/c;->h:Ljava/lang/Object;

    .line 10
    sget-object p1, Lc4/r;->a:Lc4/r;

    iput-object p1, p0, Lc1/c;->i:Ljava/lang/Object;

    .line 11
    new-instance p1, Landroidx/lifecycle/c0;

    const/4 v0, 0x6

    invoke-direct {p1, v0}, Landroidx/lifecycle/c0;-><init>(I)V

    iput-object p1, p0, Lc1/c;->j:Ljava/lang/Object;

    const/4 p1, 0x4

    .line 12
    iput p1, p0, Lc1/c;->a:I

    const p1, 0x7fffffff

    .line 13
    iput p1, p0, Lc1/c;->b:I

    .line 14
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x17

    if-ne p1, v0, :cond_0

    const/16 p1, 0xa

    goto :goto_0

    :cond_0
    const/16 p1, 0x14

    :goto_0
    iput p1, p0, Lc1/c;->d:I

    const/16 p1, 0x8

    .line 15
    iput p1, p0, Lc1/c;->c:I

    return-void
.end method
