.class public interface abstract Lc1/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract dequeueInputBuffer()Ljava/lang/Object;
.end method

.method public abstract dequeueOutputBuffer()Ljava/lang/Object;
.end method

.method public abstract flush()V
.end method

.method public abstract getName()Ljava/lang/String;
.end method

.method public abstract queueInputBuffer(Ljava/lang/Object;)V
.end method

.method public abstract release()V
.end method

.method public abstract setCallback(Lc1/d;Ljava/util/concurrent/Executor;)V
.end method

.method public abstract setOutputStartTimeUs(J)V
.end method
