.class public abstract Lc1/i;
.super Lc1/a;
.source "SourceFile"


# instance fields
.field public m:J

.field public n:I

.field public o:Z


# virtual methods
.method public abstract h()V
.end method

.method public abstract i()V
.end method
