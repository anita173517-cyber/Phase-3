.class public abstract La2/a0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La2/h0;


# instance fields
.field public final a:La2/h0;


# direct methods
.method public constructor <init>(La2/h0;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La2/a0;->a:La2/h0;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c()Z
    .locals 1

    .line 1
    iget-object v0, p0, La2/a0;->a:La2/h0;

    .line 2
    .line 3
    invoke-interface {v0}, La2/h0;->c()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public final d()Z
    .locals 1

    .line 1
    iget-object v0, p0, La2/a0;->a:La2/h0;

    .line 2
    .line 3
    invoke-interface {v0}, La2/h0;->d()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public e(J)La2/g0;
    .locals 1

    .line 1
    iget-object v0, p0, La2/a0;->a:La2/h0;

    .line 2
    .line 3
    invoke-interface {v0, p1, p2}, La2/h0;->e(J)La2/g0;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method

.method public g()J
    .locals 2

    .line 1
    iget-object v0, p0, La2/a0;->a:La2/h0;

    .line 2
    .line 3
    invoke-interface {v0}, La2/h0;->g()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method
