.class public abstract Lc4/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/util/ArrayList;)Lc4/f;
.end method
