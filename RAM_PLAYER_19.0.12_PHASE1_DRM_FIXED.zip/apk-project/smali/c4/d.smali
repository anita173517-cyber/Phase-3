.class public final Lc4/d;
.super Lt6/h;
.source "SourceFile"

# interfaces
.implements Lz6/p;


# instance fields
.field public final synthetic o:I

.field public p:I

.field public q:Ljava/lang/Object;

.field public r:Ljava/lang/Object;

.field public final synthetic s:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V
    .locals 0

    .line 1
    iput p5, p0, Lc4/d;->o:I

    iput-object p1, p0, Lc4/d;->q:Ljava/lang/Object;

    iput-object p2, p0, Lc4/d;->r:Ljava/lang/Object;

    iput-object p3, p0, Lc4/d;->s:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lt6/h;-><init>(ILr6/d;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V
    .locals 0

    .line 2
    iput p4, p0, Lc4/d;->o:I

    iput-object p1, p0, Lc4/d;->r:Ljava/lang/Object;

    iput-object p2, p0, Lc4/d;->s:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lt6/h;-><init>(ILr6/d;)V

    return-void
.end method

.method public constructor <init>(Ll4/c;Lr6/d;)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, Lc4/d;->o:I

    .line 3
    iput-object p1, p0, Lc4/d;->s:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lt6/h;-><init>(ILr6/d;)V

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lc4/d;->o:I

    .line 2
    .line 3
    check-cast p1, Lf7/s;

    .line 4
    .line 5
    check-cast p2, Lr6/d;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lc4/d;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lc4/d;

    .line 15
    .line 16
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, Lc4/d;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    return-object p1

    .line 23
    :pswitch_0
    invoke-virtual {p0, p1, p2}, Lc4/d;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Lc4/d;

    .line 28
    .line 29
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 30
    .line 31
    invoke-virtual {p1, p2}, Lc4/d;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    return-object p1

    .line 36
    :pswitch_1
    invoke-virtual {p0, p1, p2}, Lc4/d;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Lc4/d;

    .line 41
    .line 42
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 43
    .line 44
    invoke-virtual {p1, p2}, Lc4/d;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    return-object p1

    .line 49
    :pswitch_2
    invoke-virtual {p0, p1, p2}, Lc4/d;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    check-cast p1, Lc4/d;

    .line 54
    .line 55
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 56
    .line 57
    invoke-virtual {p1, p2}, Lc4/d;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    return-object p1

    .line 62
    :pswitch_3
    invoke-virtual {p0, p1, p2}, Lc4/d;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    check-cast p1, Lc4/d;

    .line 67
    .line 68
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 69
    .line 70
    invoke-virtual {p1, p2}, Lc4/d;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    return-object p1

    .line 75
    :pswitch_4
    invoke-virtual {p0, p1, p2}, Lc4/d;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    check-cast p1, Lc4/d;

    .line 80
    .line 81
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 82
    .line 83
    invoke-virtual {p1, p2}, Lc4/d;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    return-object p2

    .line 87
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final g(Ljava/lang/Object;Lr6/d;)Lr6/d;
    .locals 8

    .line 1
    iget v0, p0, Lc4/d;->o:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v1, Lc4/d;

    .line 7
    .line 8
    iget-object p1, p0, Lc4/d;->q:Ljava/lang/Object;

    .line 9
    .line 10
    move-object v2, p1

    .line 11
    check-cast v2, Lcom/harindra/iptvpro/PlayerActivity;

    .line 12
    .line 13
    iget-object p1, p0, Lc4/d;->r:Ljava/lang/Object;

    .line 14
    .line 15
    move-object v3, p1

    .line 16
    check-cast v3, Lm6/n;

    .line 17
    .line 18
    iget-object p1, p0, Lc4/d;->s:Ljava/lang/Object;

    .line 19
    .line 20
    move-object v4, p1

    .line 21
    check-cast v4, Lm6/w8;

    .line 22
    .line 23
    const/4 v6, 0x5

    .line 24
    move-object v5, p2

    .line 25
    invoke-direct/range {v1 .. v6}, Lc4/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V

    .line 26
    .line 27
    .line 28
    return-object v1

    .line 29
    :pswitch_0
    move-object v6, p2

    .line 30
    new-instance v2, Lc4/d;

    .line 31
    .line 32
    iget-object p1, p0, Lc4/d;->q:Ljava/lang/Object;

    .line 33
    .line 34
    move-object v3, p1

    .line 35
    check-cast v3, Lcom/harindra/iptvpro/PlayerActivity;

    .line 36
    .line 37
    iget-object p1, p0, Lc4/d;->r:Ljava/lang/Object;

    .line 38
    .line 39
    move-object v4, p1

    .line 40
    check-cast v4, Ljava/lang/String;

    .line 41
    .line 42
    iget-object p1, p0, Lc4/d;->s:Ljava/lang/Object;

    .line 43
    .line 44
    move-object v5, p1

    .line 45
    check-cast v5, Ljava/util/Map;

    .line 46
    .line 47
    const/4 v7, 0x4

    .line 48
    invoke-direct/range {v2 .. v7}, Lc4/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V

    .line 49
    .line 50
    .line 51
    return-object v2

    .line 52
    :pswitch_1
    move-object v6, p2

    .line 53
    new-instance p1, Lc4/d;

    .line 54
    .line 55
    iget-object p2, p0, Lc4/d;->s:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast p2, Ll4/c;

    .line 58
    .line 59
    invoke-direct {p1, p2, v6}, Lc4/d;-><init>(Ll4/c;Lr6/d;)V

    .line 60
    .line 61
    .line 62
    return-object p1

    .line 63
    :pswitch_2
    move-object v6, p2

    .line 64
    new-instance p2, Lc4/d;

    .line 65
    .line 66
    iget-object v0, p0, Lc4/d;->r:Ljava/lang/Object;

    .line 67
    .line 68
    check-cast v0, Li7/e;

    .line 69
    .line 70
    iget-object v1, p0, Lc4/d;->s:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v1, Lh4/h;

    .line 73
    .line 74
    const/4 v2, 0x2

    .line 75
    invoke-direct {p2, v0, v1, v6, v2}, Lc4/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V

    .line 76
    .line 77
    .line 78
    iput-object p1, p2, Lc4/d;->q:Ljava/lang/Object;

    .line 79
    .line 80
    return-object p2

    .line 81
    :pswitch_3
    move-object v6, p2

    .line 82
    new-instance v2, Lc4/d;

    .line 83
    .line 84
    iget-object p1, p0, Lc4/d;->q:Ljava/lang/Object;

    .line 85
    .line 86
    move-object v3, p1

    .line 87
    check-cast v3, Lh4/i;

    .line 88
    .line 89
    iget-object p1, p0, Lc4/d;->r:Ljava/lang/Object;

    .line 90
    .line 91
    move-object v4, p1

    .line 92
    check-cast v4, Ll4/q;

    .line 93
    .line 94
    iget-object p1, p0, Lc4/d;->s:Ljava/lang/Object;

    .line 95
    .line 96
    move-object v5, p1

    .line 97
    check-cast v5, Lh4/e;

    .line 98
    .line 99
    const/4 v7, 0x1

    .line 100
    invoke-direct/range {v2 .. v7}, Lc4/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V

    .line 101
    .line 102
    .line 103
    return-object v2

    .line 104
    :pswitch_4
    move-object v6, p2

    .line 105
    new-instance p1, Lc4/d;

    .line 106
    .line 107
    iget-object p2, p0, Lc4/d;->r:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast p2, Lc4/k;

    .line 110
    .line 111
    iget-object v0, p0, Lc4/d;->s:Ljava/lang/Object;

    .line 112
    .line 113
    check-cast v0, Landroidx/work/CoroutineWorker;

    .line 114
    .line 115
    const/4 v1, 0x0

    .line 116
    invoke-direct {p1, p2, v0, v6, v1}, Lc4/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lr6/d;I)V

    .line 117
    .line 118
    .line 119
    return-object p1

    .line 120
    nop

    .line 121
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 20

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iget v2, v1, Lc4/d;->o:I

    .line 6
    .line 7
    const/16 v3, 0xa

    .line 8
    .line 9
    const/4 v5, 0x0

    .line 10
    const-string v6, "call to \'resume\' before \'invoke\' with coroutine"

    .line 11
    .line 12
    const/4 v7, 0x1

    .line 13
    packed-switch v2, :pswitch_data_0

    .line 14
    .line 15
    .line 16
    iget-object v2, v1, Lc4/d;->s:Ljava/lang/Object;

    .line 17
    .line 18
    move-object v10, v2

    .line 19
    check-cast v10, Lm6/w8;

    .line 20
    .line 21
    sget-object v2, Ln6/j;->a:Ln6/j;

    .line 22
    .line 23
    iget-object v4, v1, Lc4/d;->r:Ljava/lang/Object;

    .line 24
    .line 25
    move-object v11, v4

    .line 26
    check-cast v11, Lm6/n;

    .line 27
    .line 28
    iget-object v4, v11, Lm6/n;->c:Ljava/lang/String;

    .line 29
    .line 30
    iget-object v8, v1, Lc4/d;->q:Ljava/lang/Object;

    .line 31
    .line 32
    move-object v9, v8

    .line 33
    check-cast v9, Lcom/harindra/iptvpro/PlayerActivity;

    .line 34
    .line 35
    sget-object v8, Ls6/a;->k:Ls6/a;

    .line 36
    .line 37
    iget v12, v1, Lc4/d;->p:I

    .line 38
    .line 39
    if-eqz v12, :cond_1

    .line 40
    .line 41
    if-ne v12, v7, :cond_0

    .line 42
    .line 43
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    check-cast v0, Ln6/f;

    .line 47
    .line 48
    iget-object v0, v0, Ln6/f;->k:Ljava/lang/Object;

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 52
    .line 53
    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    throw v0

    .line 57
    :cond_1
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    new-instance v0, Ljava/lang/StringBuilder;

    .line 61
    .line 62
    const-string v6, "\u23ea Checking provider archive for "

    .line 63
    .line 64
    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    .line 69
    .line 70
    const-string v6, "..."

    .line 71
    .line 72
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-static {v9, v0, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 84
    .line 85
    .line 86
    iget-object v0, v9, Lcom/harindra/iptvpro/PlayerActivity;->W1:Ld/a;

    .line 87
    .line 88
    iget-object v6, v11, Lm6/n;->a:Ljava/lang/String;

    .line 89
    .line 90
    iput v7, v1, Lc4/d;->p:I

    .line 91
    .line 92
    invoke-virtual {v0, v10, v6, v1}, Ld/a;->i(Lm6/w8;Ljava/lang/String;Lt6/c;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    if-ne v0, v8, :cond_2

    .line 97
    .line 98
    move-object v2, v8

    .line 99
    goto/16 :goto_5

    .line 100
    .line 101
    :cond_2
    :goto_0
    invoke-static {v0}, Ln6/f;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 102
    .line 103
    .line 104
    move-result-object v6

    .line 105
    if-nez v6, :cond_9

    .line 106
    .line 107
    check-cast v0, Ljava/util/List;

    .line 108
    .line 109
    sget-object v6, Lm6/m;->a:La7/m;

    .line 110
    .line 111
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 112
    .line 113
    .line 114
    move-result-wide v12

    .line 115
    const-wide/16 v14, 0x3e8

    .line 116
    .line 117
    div-long/2addr v12, v14

    .line 118
    const-string v6, "all"

    .line 119
    .line 120
    invoke-static {v0, v6}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-static {v0}, Lo6/j;->S(Ljava/util/Collection;)Ld7/o;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    new-instance v6, Lm6/j;

    .line 128
    .line 129
    invoke-direct {v6, v12, v13}, Lm6/j;-><init>(J)V

    .line 130
    .line 131
    .line 132
    new-instance v8, Ld7/c;

    .line 133
    .line 134
    invoke-direct {v8, v0, v6, v7}, Ld7/c;-><init>(Ld7/j;Ljava/lang/Object;I)V

    .line 135
    .line 136
    .line 137
    new-instance v0, Ld7/n;

    .line 138
    .line 139
    const/4 v6, 0x2

    .line 140
    invoke-direct {v0, v6}, Ld7/n;-><init>(I)V

    .line 141
    .line 142
    .line 143
    new-instance v12, Ld7/c;

    .line 144
    .line 145
    invoke-direct {v12, v8, v0, v5}, Ld7/c;-><init>(Ld7/j;Ljava/lang/Object;I)V

    .line 146
    .line 147
    .line 148
    new-instance v0, Lm6/l;

    .line 149
    .line 150
    invoke-direct {v0, v5}, Lm6/l;-><init>(I)V

    .line 151
    .line 152
    .line 153
    new-instance v5, Ld7/c;

    .line 154
    .line 155
    invoke-direct {v5, v12, v0, v6}, Ld7/c;-><init>(Ld7/j;Ljava/lang/Object;I)V

    .line 156
    .line 157
    .line 158
    instance-of v0, v5, Ld7/f;

    .line 159
    .line 160
    if-eqz v0, :cond_3

    .line 161
    .line 162
    check-cast v5, Ld7/f;

    .line 163
    .line 164
    invoke-interface {v5}, Ld7/f;->take()Ld7/j;

    .line 165
    .line 166
    .line 167
    move-result-object v0

    .line 168
    goto :goto_1

    .line 169
    :cond_3
    new-instance v0, Ld7/s;

    .line 170
    .line 171
    invoke-direct {v0, v5}, Ld7/s;-><init>(Ld7/j;)V

    .line 172
    .line 173
    .line 174
    :goto_1
    invoke-static {v0}, Ld7/l;->U(Ld7/j;)Ljava/util/List;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 179
    .line 180
    .line 181
    move-result v5

    .line 182
    if-eqz v5, :cond_4

    .line 183
    .line 184
    new-instance v0, Ljava/lang/StringBuilder;

    .line 185
    .line 186
    const-string v3, "Your provider has no recorded programmes for "

    .line 187
    .line 188
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 192
    .line 193
    .line 194
    const-string v3, ". Live channels cannot be rewound without a provider archive."

    .line 195
    .line 196
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 200
    .line 201
    .line 202
    move-result-object v0

    .line 203
    invoke-static {v9, v0, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 204
    .line 205
    .line 206
    move-result-object v0

    .line 207
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 208
    .line 209
    .line 210
    goto/16 :goto_5

    .line 211
    .line 212
    :cond_4
    new-instance v5, Ljava/util/ArrayList;

    .line 213
    .line 214
    invoke-static {v0, v3}, Lo6/l;->O(Ljava/lang/Iterable;I)I

    .line 215
    .line 216
    .line 217
    move-result v3

    .line 218
    invoke-direct {v5, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 219
    .line 220
    .line 221
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 222
    .line 223
    .line 224
    move-result-object v3

    .line 225
    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 226
    .line 227
    .line 228
    move-result v6

    .line 229
    if-eqz v6, :cond_8

    .line 230
    .line 231
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object v6

    .line 235
    move-object v12, v6

    .line 236
    check-cast v12, Lm6/k;

    .line 237
    .line 238
    iget-object v15, v12, Lm6/k;->a:Ljava/lang/String;

    .line 239
    .line 240
    iget-object v6, v12, Lm6/k;->b:Ljava/lang/String;

    .line 241
    .line 242
    iget-boolean v7, v12, Lm6/k;->g:Z

    .line 243
    .line 244
    new-instance v8, Ljava/lang/StringBuilder;

    .line 245
    .line 246
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 247
    .line 248
    .line 249
    invoke-static {v12}, Lm6/m;->a(Lm6/k;)Ljava/lang/String;

    .line 250
    .line 251
    .line 252
    move-result-object v13

    .line 253
    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 254
    .line 255
    .line 256
    if-eqz v7, :cond_5

    .line 257
    .line 258
    const-string v13, " \u2022 ON AIR (from start)"

    .line 259
    .line 260
    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 261
    .line 262
    .line 263
    :cond_5
    invoke-static {v6}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 264
    .line 265
    .line 266
    move-result v13

    .line 267
    if-nez v13, :cond_6

    .line 268
    .line 269
    const-string v13, " \u2022 "

    .line 270
    .line 271
    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 272
    .line 273
    .line 274
    const/16 v13, 0x5a

    .line 275
    .line 276
    invoke-static {v6, v13}, Le7/e;->n0(Ljava/lang/String;I)Ljava/lang/String;

    .line 277
    .line 278
    .line 279
    move-result-object v6

    .line 280
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 281
    .line 282
    .line 283
    :cond_6
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 284
    .line 285
    .line 286
    move-result-object v16

    .line 287
    if-eqz v7, :cond_7

    .line 288
    .line 289
    const-string v6, "FROM START"

    .line 290
    .line 291
    :goto_3
    move-object/from16 v17, v6

    .line 292
    .line 293
    goto :goto_4

    .line 294
    :cond_7
    const-string v6, "ARCHIVE"

    .line 295
    .line 296
    goto :goto_3

    .line 297
    :goto_4
    new-instance v19, Lm6/d;

    .line 298
    .line 299
    const/4 v13, 0x2

    .line 300
    move-object/from16 v8, v19

    .line 301
    .line 302
    invoke-direct/range {v8 .. v13}, Lm6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 303
    .line 304
    .line 305
    new-instance v13, Lm6/v0;

    .line 306
    .line 307
    const/16 v18, 0x0

    .line 308
    .line 309
    const v14, 0x7f0800c3

    .line 310
    .line 311
    .line 312
    invoke-direct/range {v13 .. v19}, Lm6/v0;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLz6/a;)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {v5, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 316
    .line 317
    .line 318
    goto :goto_2

    .line 319
    :cond_8
    const-string v3, "Catch-up TV \u2022 "

    .line 320
    .line 321
    invoke-static {v3, v4}, La0/h;->s(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 322
    .line 323
    .line 324
    move-result-object v14

    .line 325
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 326
    .line 327
    .line 328
    move-result v0

    .line 329
    const-string v3, " SHOWS"

    .line 330
    .line 331
    invoke-static {v3, v0}, Lq3/e;->c(Ljava/lang/String;I)Ljava/lang/String;

    .line 332
    .line 333
    .line 334
    move-result-object v16

    .line 335
    const-string v18, "Back"

    .line 336
    .line 337
    const v13, 0x7f0800c3

    .line 338
    .line 339
    .line 340
    const-string v15, "Provider-recorded programmes (provider time zone) \u2022 BACK returns to Live TV"

    .line 341
    .line 342
    move-object/from16 v17, v5

    .line 343
    .line 344
    move-object v12, v9

    .line 345
    invoke-static/range {v12 .. v18}, Landroid/support/v4/media/session/b;->Y(Lcom/harindra/iptvpro/PlayerActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;)V

    .line 346
    .line 347
    .line 348
    goto :goto_5

    .line 349
    :cond_9
    sget-object v0, Lm6/f1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 350
    .line 351
    invoke-virtual {v6}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    if-nez v0, :cond_a

    .line 356
    .line 357
    const-string v0, "provider error"

    .line 358
    .line 359
    :cond_a
    invoke-static {v0}, Lm6/f1;->f(Ljava/lang/String;)Ljava/lang/String;

    .line 360
    .line 361
    .line 362
    move-result-object v0

    .line 363
    const-string v3, "Catch-up unavailable: "

    .line 364
    .line 365
    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 366
    .line 367
    .line 368
    move-result-object v0

    .line 369
    invoke-static {v9, v0, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 370
    .line 371
    .line 372
    move-result-object v0

    .line 373
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 374
    .line 375
    .line 376
    :goto_5
    return-object v2

    .line 377
    :pswitch_0
    sget-object v2, Ln6/j;->a:Ln6/j;

    .line 378
    .line 379
    sget-object v3, Ls6/a;->k:Ls6/a;

    .line 380
    .line 381
    iget v4, v1, Lc4/d;->p:I

    .line 382
    .line 383
    if-eqz v4, :cond_c

    .line 384
    .line 385
    if-ne v4, v7, :cond_b

    .line 386
    .line 387
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 388
    .line 389
    .line 390
    goto :goto_7

    .line 391
    :cond_b
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 392
    .line 393
    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 394
    .line 395
    .line 396
    throw v0

    .line 397
    :cond_c
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 398
    .line 399
    .line 400
    iget-object v0, v1, Lc4/d;->q:Ljava/lang/Object;

    .line 401
    .line 402
    check-cast v0, Lcom/harindra/iptvpro/PlayerActivity;

    .line 403
    .line 404
    invoke-virtual {v0}, Lcom/harindra/iptvpro/PlayerActivity;->v()Ll4/c;

    .line 405
    .line 406
    .line 407
    move-result-object v9

    .line 408
    iget-object v0, v1, Lc4/d;->r:Ljava/lang/Object;

    .line 409
    .line 410
    move-object v11, v0

    .line 411
    check-cast v11, Ljava/lang/String;

    .line 412
    .line 413
    iget-object v0, v1, Lc4/d;->s:Ljava/lang/Object;

    .line 414
    .line 415
    move-object v10, v0

    .line 416
    check-cast v10, Ljava/util/Map;

    .line 417
    .line 418
    iput v7, v1, Lc4/d;->p:I

    .line 419
    .line 420
    invoke-interface {v10}, Ljava/util/Map;->isEmpty()Z

    .line 421
    .line 422
    .line 423
    move-result v0

    .line 424
    if-eqz v0, :cond_e

    .line 425
    .line 426
    :cond_d
    move-object v0, v2

    .line 427
    goto :goto_6

    .line 428
    :cond_e
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 429
    .line 430
    .line 431
    move-result-wide v12

    .line 432
    new-instance v0, Lm6/i;

    .line 433
    .line 434
    invoke-direct {v0, v11, v12, v13, v10}, Lm6/i;-><init>(Ljava/lang/String;JLjava/util/Map;)V

    .line 435
    .line 436
    .line 437
    sput-object v0, Ll4/c;->m:Lm6/i;

    .line 438
    .line 439
    sget-object v0, Lf7/b0;->b:Lm7/d;

    .line 440
    .line 441
    new-instance v8, Lm6/j0;

    .line 442
    .line 443
    const/4 v14, 0x0

    .line 444
    invoke-direct/range {v8 .. v14}, Lm6/j0;-><init>(Ll4/c;Ljava/util/Map;Ljava/lang/String;JLr6/d;)V

    .line 445
    .line 446
    .line 447
    invoke-static {v0, v8, v1}, Lf7/v;->o(Lr6/i;Lz6/p;Lr6/d;)Ljava/lang/Object;

    .line 448
    .line 449
    .line 450
    move-result-object v0

    .line 451
    if-ne v0, v3, :cond_d

    .line 452
    .line 453
    :goto_6
    if-ne v0, v3, :cond_f

    .line 454
    .line 455
    move-object v2, v3

    .line 456
    :cond_f
    :goto_7
    return-object v2

    .line 457
    :pswitch_1
    sget-object v2, Ls6/a;->k:Ls6/a;

    .line 458
    .line 459
    iget v3, v1, Lc4/d;->p:I

    .line 460
    .line 461
    if-eqz v3, :cond_11

    .line 462
    .line 463
    if-ne v3, v7, :cond_10

    .line 464
    .line 465
    iget-object v2, v1, Lc4/d;->r:Ljava/lang/Object;

    .line 466
    .line 467
    check-cast v2, Ll4/c;

    .line 468
    .line 469
    iget-object v3, v1, Lc4/d;->q:Ljava/lang/Object;

    .line 470
    .line 471
    check-cast v3, Ln7/d;

    .line 472
    .line 473
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 474
    .line 475
    .line 476
    goto :goto_8

    .line 477
    :cond_10
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 478
    .line 479
    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 480
    .line 481
    .line 482
    throw v0

    .line 483
    :cond_11
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 484
    .line 485
    .line 486
    sget-object v0, Ll4/c;->m:Lm6/i;

    .line 487
    .line 488
    if-eqz v0, :cond_12

    .line 489
    .line 490
    iget-object v3, v0, Lm6/i;->c:Ljava/util/Map;

    .line 491
    .line 492
    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    .line 493
    .line 494
    .line 495
    move-result v3

    .line 496
    if-nez v3, :cond_12

    .line 497
    .line 498
    move-object v2, v0

    .line 499
    goto/16 :goto_14

    .line 500
    .line 501
    :cond_12
    iget-object v0, v1, Lc4/d;->s:Ljava/lang/Object;

    .line 502
    .line 503
    check-cast v0, Ll4/c;

    .line 504
    .line 505
    iget-object v3, v0, Ll4/c;->k:Ljava/lang/Object;

    .line 506
    .line 507
    check-cast v3, Ln7/d;

    .line 508
    .line 509
    iput-object v3, v1, Lc4/d;->q:Ljava/lang/Object;

    .line 510
    .line 511
    iput-object v0, v1, Lc4/d;->r:Ljava/lang/Object;

    .line 512
    .line 513
    iput v7, v1, Lc4/d;->p:I

    .line 514
    .line 515
    invoke-virtual {v3, v1}, Ln7/d;->c(Lr6/d;)Ljava/lang/Object;

    .line 516
    .line 517
    .line 518
    move-result-object v5

    .line 519
    if-ne v5, v2, :cond_13

    .line 520
    .line 521
    goto/16 :goto_14

    .line 522
    .line 523
    :cond_13
    move-object v2, v0

    .line 524
    :goto_8
    :try_start_0
    iget-object v0, v2, Ll4/c;->l:Ljava/lang/Object;

    .line 525
    .line 526
    check-cast v0, Ljava/io/File;

    .line 527
    .line 528
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 529
    .line 530
    .line 531
    move-result v0

    .line 532
    if-eqz v0, :cond_15

    .line 533
    .line 534
    iget-object v0, v2, Ll4/c;->l:Ljava/lang/Object;

    .line 535
    .line 536
    check-cast v0, Ljava/io/File;

    .line 537
    .line 538
    invoke-virtual {v0}, Ljava/io/File;->length()J

    .line 539
    .line 540
    .line 541
    move-result-wide v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 542
    const-wide/16 v7, 0xa

    .line 543
    .line 544
    cmp-long v0, v5, v7

    .line 545
    .line 546
    if-gtz v0, :cond_14

    .line 547
    .line 548
    goto :goto_9

    .line 549
    :cond_14
    :try_start_1
    new-instance v0, Ljava/util/HashMap;

    .line 550
    .line 551
    const/16 v5, 0x400

    .line 552
    .line 553
    invoke-direct {v0, v5}, Ljava/util/HashMap;-><init>(I)V

    .line 554
    .line 555
    .line 556
    new-instance v5, Landroid/util/JsonReader;

    .line 557
    .line 558
    new-instance v6, Ljava/io/BufferedReader;

    .line 559
    .line 560
    new-instance v7, Ljava/io/InputStreamReader;

    .line 561
    .line 562
    new-instance v8, Ljava/io/FileInputStream;

    .line 563
    .line 564
    iget-object v9, v2, Ll4/c;->l:Ljava/lang/Object;

    .line 565
    .line 566
    check-cast v9, Ljava/io/File;

    .line 567
    .line 568
    invoke-direct {v8, v9}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 569
    .line 570
    .line 571
    sget-object v9, Le7/a;->a:Ljava/nio/charset/Charset;

    .line 572
    .line 573
    invoke-direct {v7, v8, v9}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    .line 574
    .line 575
    .line 576
    const v8, 0x8000

    .line 577
    .line 578
    .line 579
    invoke-direct {v6, v7, v8}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    .line 580
    .line 581
    .line 582
    invoke-direct {v5, v6}, Landroid/util/JsonReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 583
    .line 584
    .line 585
    :try_start_2
    invoke-virtual {v5}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 586
    .line 587
    .line 588
    move-result-object v6

    .line 589
    sget-object v7, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 590
    .line 591
    if-eq v6, v7, :cond_16

    .line 592
    .line 593
    iget-object v0, v2, Ll4/c;->l:Ljava/lang/Object;

    .line 594
    .line 595
    check-cast v0, Ljava/io/File;

    .line 596
    .line 597
    invoke-static {v0}, Ll3/e;->H(Ljava/io/File;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 598
    .line 599
    .line 600
    :try_start_3
    invoke-virtual {v5}, Landroid/util/JsonReader;->close()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 601
    .line 602
    .line 603
    :cond_15
    :goto_9
    const/4 v4, 0x0

    .line 604
    goto/16 :goto_13

    .line 605
    .line 606
    :catchall_0
    move-exception v0

    .line 607
    goto/16 :goto_15

    .line 608
    .line 609
    :catch_0
    move-exception v0

    .line 610
    goto/16 :goto_12

    .line 611
    .line 612
    :catchall_1
    move-exception v0

    .line 613
    move-object v4, v0

    .line 614
    goto/16 :goto_11

    .line 615
    .line 616
    :cond_16
    :try_start_4
    invoke-virtual {v5}, Landroid/util/JsonReader;->beginObject()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 617
    .line 618
    .line 619
    const-string v8, ""

    .line 620
    .line 621
    move-object v9, v8

    .line 622
    :goto_a
    const-wide/16 v10, 0x0

    .line 623
    .line 624
    :goto_b
    :try_start_5
    invoke-virtual {v5}, Landroid/util/JsonReader;->hasNext()Z

    .line 625
    .line 626
    .line 627
    move-result v12

    .line 628
    if-eqz v12, :cond_2e

    .line 629
    .line 630
    invoke-virtual {v5}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 631
    .line 632
    .line 633
    move-result-object v12

    .line 634
    if-eqz v12, :cond_2d

    .line 635
    .line 636
    invoke-virtual {v12}, Ljava/lang/String;->hashCode()I

    .line 637
    .line 638
    .line 639
    move-result v13
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 640
    const/16 v14, 0xe7f

    .line 641
    .line 642
    if-eq v13, v14, :cond_2a

    .line 643
    .line 644
    const v14, 0x1c56f

    .line 645
    .line 646
    .line 647
    const-string v15, "nextString(...)"

    .line 648
    .line 649
    if-eq v13, v14, :cond_27

    .line 650
    .line 651
    const v14, 0x5fde7c0

    .line 652
    .line 653
    .line 654
    if-eq v13, v14, :cond_17

    .line 655
    .line 656
    goto/16 :goto_10

    .line 657
    .line 658
    :cond_17
    :try_start_6
    const-string v13, "items"

    .line 659
    .line 660
    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 661
    .line 662
    .line 663
    move-result v12

    .line 664
    if-nez v12, :cond_18

    .line 665
    .line 666
    goto/16 :goto_10

    .line 667
    .line 668
    :cond_18
    invoke-virtual {v5}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 669
    .line 670
    .line 671
    move-result-object v12

    .line 672
    sget-object v13, Landroid/util/JsonToken;->BEGIN_ARRAY:Landroid/util/JsonToken;

    .line 673
    .line 674
    if-ne v12, v13, :cond_26

    .line 675
    .line 676
    invoke-virtual {v5}, Landroid/util/JsonReader;->beginArray()V

    .line 677
    .line 678
    .line 679
    :cond_19
    :goto_c
    invoke-virtual {v5}, Landroid/util/JsonReader;->hasNext()Z

    .line 680
    .line 681
    .line 682
    move-result v12

    .line 683
    if-eqz v12, :cond_25

    .line 684
    .line 685
    invoke-virtual {v5}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 686
    .line 687
    .line 688
    move-result-object v12

    .line 689
    sget-object v13, Landroid/util/JsonToken;->BEGIN_OBJECT:Landroid/util/JsonToken;

    .line 690
    .line 691
    if-eq v12, v13, :cond_1a

    .line 692
    .line 693
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 694
    .line 695
    .line 696
    goto :goto_c

    .line 697
    :cond_1a
    const-string v12, "Live Broadcast"

    .line 698
    .line 699
    const-string v13, "Upcoming Show"

    .line 700
    .line 701
    invoke-virtual {v5}, Landroid/util/JsonReader;->beginObject()V

    .line 702
    .line 703
    .line 704
    :goto_d
    move-object v14, v8

    .line 705
    :goto_e
    invoke-virtual {v5}, Landroid/util/JsonReader;->hasNext()Z

    .line 706
    .line 707
    .line 708
    move-result v16

    .line 709
    if-eqz v16, :cond_24

    .line 710
    .line 711
    invoke-virtual {v5}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    .line 712
    .line 713
    .line 714
    move-result-object v6

    .line 715
    if-eqz v6, :cond_23

    .line 716
    .line 717
    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    .line 718
    .line 719
    .line 720
    move-result v7

    .line 721
    const/16 v4, 0xd1b

    .line 722
    .line 723
    if-eq v7, v4, :cond_21

    .line 724
    .line 725
    const v4, 0x1aad6

    .line 726
    .line 727
    .line 728
    if-eq v7, v4, :cond_1e

    .line 729
    .line 730
    const v4, 0x338af3

    .line 731
    .line 732
    .line 733
    if-eq v7, v4, :cond_1b

    .line 734
    .line 735
    goto :goto_f

    .line 736
    :cond_1b
    const-string v4, "next"

    .line 737
    .line 738
    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 739
    .line 740
    .line 741
    move-result v4

    .line 742
    if-nez v4, :cond_1c

    .line 743
    .line 744
    goto :goto_f

    .line 745
    :cond_1c
    invoke-virtual {v5}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 746
    .line 747
    .line 748
    move-result-object v4

    .line 749
    sget-object v6, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 750
    .line 751
    if-ne v4, v6, :cond_1d

    .line 752
    .line 753
    invoke-virtual {v5}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 754
    .line 755
    .line 756
    move-result-object v4

    .line 757
    invoke-static {v4, v15}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 758
    .line 759
    .line 760
    move-object v13, v4

    .line 761
    goto :goto_e

    .line 762
    :cond_1d
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 763
    .line 764
    .line 765
    move-object v13, v8

    .line 766
    goto :goto_e

    .line 767
    :cond_1e
    const-string v4, "now"

    .line 768
    .line 769
    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 770
    .line 771
    .line 772
    move-result v4

    .line 773
    if-nez v4, :cond_1f

    .line 774
    .line 775
    goto :goto_f

    .line 776
    :cond_1f
    invoke-virtual {v5}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 777
    .line 778
    .line 779
    move-result-object v4

    .line 780
    sget-object v6, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 781
    .line 782
    if-ne v4, v6, :cond_20

    .line 783
    .line 784
    invoke-virtual {v5}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 785
    .line 786
    .line 787
    move-result-object v4

    .line 788
    invoke-static {v4, v15}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 789
    .line 790
    .line 791
    move-object v12, v4

    .line 792
    goto :goto_e

    .line 793
    :cond_20
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 794
    .line 795
    .line 796
    move-object v12, v8

    .line 797
    goto :goto_e

    .line 798
    :cond_21
    const-string v4, "id"

    .line 799
    .line 800
    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 801
    .line 802
    .line 803
    move-result v4

    .line 804
    if-eqz v4, :cond_23

    .line 805
    .line 806
    invoke-virtual {v5}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 807
    .line 808
    .line 809
    move-result-object v4

    .line 810
    sget-object v6, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 811
    .line 812
    if-ne v4, v6, :cond_22

    .line 813
    .line 814
    invoke-virtual {v5}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 815
    .line 816
    .line 817
    move-result-object v4

    .line 818
    invoke-static {v4, v15}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 819
    .line 820
    .line 821
    move-object v14, v4

    .line 822
    goto :goto_e

    .line 823
    :cond_22
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 824
    .line 825
    .line 826
    goto :goto_d

    .line 827
    :cond_23
    :goto_f
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 828
    .line 829
    .line 830
    goto :goto_e

    .line 831
    :cond_24
    invoke-virtual {v5}, Landroid/util/JsonReader;->endObject()V

    .line 832
    .line 833
    .line 834
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    .line 835
    .line 836
    .line 837
    move-result v4

    .line 838
    if-lez v4, :cond_19

    .line 839
    .line 840
    new-instance v4, Ln6/d;

    .line 841
    .line 842
    invoke-direct {v4, v12, v13}, Ln6/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 843
    .line 844
    .line 845
    invoke-virtual {v0, v14, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 846
    .line 847
    .line 848
    invoke-static {v14}, Lm6/v8;->c(Ljava/lang/String;)Ljava/lang/String;

    .line 849
    .line 850
    .line 851
    move-result-object v6

    .line 852
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    .line 853
    .line 854
    .line 855
    move-result v7

    .line 856
    if-lez v7, :cond_19

    .line 857
    .line 858
    invoke-static {v0, v6, v4}, Lw7/l;->k(Ljava/util/HashMap;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 859
    .line 860
    .line 861
    goto/16 :goto_c

    .line 862
    .line 863
    :cond_25
    invoke-virtual {v5}, Landroid/util/JsonReader;->endArray()V

    .line 864
    .line 865
    .line 866
    goto/16 :goto_b

    .line 867
    .line 868
    :cond_26
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 869
    .line 870
    .line 871
    goto/16 :goto_b

    .line 872
    .line 873
    :cond_27
    const-string v4, "url"

    .line 874
    .line 875
    invoke-virtual {v12, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 876
    .line 877
    .line 878
    move-result v4

    .line 879
    if-nez v4, :cond_28

    .line 880
    .line 881
    goto :goto_10

    .line 882
    :cond_28
    invoke-virtual {v5}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 883
    .line 884
    .line 885
    move-result-object v4

    .line 886
    sget-object v6, Landroid/util/JsonToken;->STRING:Landroid/util/JsonToken;

    .line 887
    .line 888
    if-ne v4, v6, :cond_29

    .line 889
    .line 890
    invoke-virtual {v5}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    .line 891
    .line 892
    .line 893
    move-result-object v4

    .line 894
    invoke-static {v4, v15}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 895
    .line 896
    .line 897
    move-object v9, v4

    .line 898
    goto/16 :goto_b

    .line 899
    .line 900
    :cond_29
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 901
    .line 902
    .line 903
    move-object v9, v8

    .line 904
    goto/16 :goto_b

    .line 905
    .line 906
    :cond_2a
    const-string v4, "ts"

    .line 907
    .line 908
    invoke-virtual {v12, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 909
    .line 910
    .line 911
    move-result v4

    .line 912
    if-nez v4, :cond_2b

    .line 913
    .line 914
    goto :goto_10

    .line 915
    :cond_2b
    invoke-virtual {v5}, Landroid/util/JsonReader;->peek()Landroid/util/JsonToken;

    .line 916
    .line 917
    .line 918
    move-result-object v4

    .line 919
    sget-object v6, Landroid/util/JsonToken;->NUMBER:Landroid/util/JsonToken;

    .line 920
    .line 921
    if-ne v4, v6, :cond_2c

    .line 922
    .line 923
    invoke-virtual {v5}, Landroid/util/JsonReader;->nextLong()J

    .line 924
    .line 925
    .line 926
    move-result-wide v6

    .line 927
    move-wide v10, v6

    .line 928
    goto/16 :goto_b

    .line 929
    .line 930
    :cond_2c
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 931
    .line 932
    .line 933
    goto/16 :goto_a

    .line 934
    .line 935
    :cond_2d
    :goto_10
    invoke-virtual {v5}, Landroid/util/JsonReader;->skipValue()V

    .line 936
    .line 937
    .line 938
    goto/16 :goto_b

    .line 939
    .line 940
    :cond_2e
    invoke-virtual {v5}, Landroid/util/JsonReader;->endObject()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    .line 941
    .line 942
    .line 943
    :try_start_7
    invoke-virtual {v5}, Landroid/util/JsonReader;->close()V

    .line 944
    .line 945
    .line 946
    invoke-virtual {v0}, Ljava/util/HashMap;->isEmpty()Z

    .line 947
    .line 948
    .line 949
    move-result v4

    .line 950
    if-eqz v4, :cond_2f

    .line 951
    .line 952
    goto/16 :goto_9

    .line 953
    .line 954
    :cond_2f
    new-instance v4, Lm6/i;

    .line 955
    .line 956
    invoke-direct {v4, v9, v10, v11, v0}, Lm6/i;-><init>(Ljava/lang/String;JLjava/util/Map;)V

    .line 957
    .line 958
    .line 959
    sput-object v4, Ll4/c;->m:Lm6/i;
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 960
    .line 961
    goto :goto_13

    .line 962
    :goto_11
    :try_start_8
    throw v4
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 963
    :catchall_2
    move-exception v0

    .line 964
    :try_start_9
    invoke-static {v5, v4}, Ll3/e;->n(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 965
    .line 966
    .line 967
    throw v0
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0
    .catchall {:try_start_9 .. :try_end_9} :catchall_0

    .line 968
    :goto_12
    :try_start_a
    instance-of v4, v0, Ljava/util/concurrent/CancellationException;

    .line 969
    .line 970
    if-nez v4, :cond_30

    .line 971
    .line 972
    const-string v4, "StreamX"

    .line 973
    .line 974
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 975
    .line 976
    .line 977
    move-result-object v0

    .line 978
    new-instance v5, Ljava/lang/StringBuilder;

    .line 979
    .line 980
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 981
    .line 982
    .line 983
    const-string v6, "Corrupted EPG cache quarantined: "

    .line 984
    .line 985
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 986
    .line 987
    .line 988
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 989
    .line 990
    .line 991
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 992
    .line 993
    .line 994
    move-result-object v0

    .line 995
    invoke-static {v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 996
    .line 997
    .line 998
    iget-object v0, v2, Ll4/c;->l:Ljava/lang/Object;

    .line 999
    .line 1000
    check-cast v0, Ljava/io/File;

    .line 1001
    .line 1002
    invoke-static {v0}, Ll3/e;->H(Ljava/io/File;)V

    .line 1003
    .line 1004
    .line 1005
    goto/16 :goto_9

    .line 1006
    .line 1007
    :cond_30
    throw v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    .line 1008
    :goto_13
    invoke-virtual {v3}, Ln7/d;->d()V

    .line 1009
    .line 1010
    .line 1011
    move-object v2, v4

    .line 1012
    :goto_14
    return-object v2

    .line 1013
    :goto_15
    invoke-virtual {v3}, Ln7/d;->d()V

    .line 1014
    .line 1015
    .line 1016
    throw v0

    .line 1017
    :pswitch_2
    sget-object v2, Ln6/j;->a:Ln6/j;

    .line 1018
    .line 1019
    sget-object v3, Ls6/a;->k:Ls6/a;

    .line 1020
    .line 1021
    iget v4, v1, Lc4/d;->p:I

    .line 1022
    .line 1023
    if-eqz v4, :cond_32

    .line 1024
    .line 1025
    if-ne v4, v7, :cond_31

    .line 1026
    .line 1027
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 1028
    .line 1029
    .line 1030
    goto :goto_17

    .line 1031
    :cond_31
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1032
    .line 1033
    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1034
    .line 1035
    .line 1036
    throw v0

    .line 1037
    :cond_32
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 1038
    .line 1039
    .line 1040
    iget-object v0, v1, Lc4/d;->q:Ljava/lang/Object;

    .line 1041
    .line 1042
    check-cast v0, Lf7/s;

    .line 1043
    .line 1044
    iget-object v4, v1, Lc4/d;->r:Ljava/lang/Object;

    .line 1045
    .line 1046
    check-cast v4, Li7/e;

    .line 1047
    .line 1048
    iget-object v5, v1, Lc4/d;->s:Ljava/lang/Object;

    .line 1049
    .line 1050
    check-cast v5, Lh4/h;

    .line 1051
    .line 1052
    sget-object v6, Lr6/j;->k:Lr6/j;

    .line 1053
    .line 1054
    sget-object v8, Lh7/a;->k:Lh7/a;

    .line 1055
    .line 1056
    sget-object v9, Lf7/t;->l:Lf7/t;

    .line 1057
    .line 1058
    new-instance v10, Li4/d;

    .line 1059
    .line 1060
    const/4 v11, 0x0

    .line 1061
    invoke-direct {v10, v5, v11, v7}, Li4/d;-><init>(Ljava/lang/Object;Lr6/d;I)V

    .line 1062
    .line 1063
    .line 1064
    const/4 v5, 0x4

    .line 1065
    const/4 v11, -0x2

    .line 1066
    invoke-static {v11, v8, v5}, Ll3/e;->a(ILh7/a;I)Lh7/e;

    .line 1067
    .line 1068
    .line 1069
    move-result-object v5

    .line 1070
    invoke-interface {v0}, Lf7/s;->g()Lr6/i;

    .line 1071
    .line 1072
    .line 1073
    move-result-object v0

    .line 1074
    invoke-static {v0, v6, v7}, Lf7/v;->d(Lr6/i;Lr6/i;Z)Lr6/i;

    .line 1075
    .line 1076
    .line 1077
    move-result-object v0

    .line 1078
    sget-object v6, Lf7/b0;->a:Lm7/e;

    .line 1079
    .line 1080
    if-eq v0, v6, :cond_33

    .line 1081
    .line 1082
    sget-object v8, Lr6/e;->k:Lr6/e;

    .line 1083
    .line 1084
    invoke-interface {v0, v8}, Lr6/i;->e(Lr6/h;)Lr6/g;

    .line 1085
    .line 1086
    .line 1087
    move-result-object v8

    .line 1088
    if-nez v8, :cond_33

    .line 1089
    .line 1090
    invoke-interface {v0, v6}, Lr6/i;->n(Lr6/i;)Lr6/i;

    .line 1091
    .line 1092
    .line 1093
    move-result-object v0

    .line 1094
    :cond_33
    new-instance v6, Lh7/r;

    .line 1095
    .line 1096
    invoke-direct {v6, v0, v5}, Lh7/r;-><init>(Lr6/i;Lh7/e;)V

    .line 1097
    .line 1098
    .line 1099
    invoke-virtual {v6, v9, v6, v10}, Lf7/a;->V(Lf7/t;Lf7/a;Lz6/p;)V

    .line 1100
    .line 1101
    .line 1102
    iput v7, v1, Lc4/d;->p:I

    .line 1103
    .line 1104
    invoke-static {v4, v6, v7, v1}, Li7/j;->a(Li7/e;Lh7/r;ZLt6/c;)Ljava/lang/Object;

    .line 1105
    .line 1106
    .line 1107
    move-result-object v0

    .line 1108
    if-ne v0, v3, :cond_34

    .line 1109
    .line 1110
    goto :goto_16

    .line 1111
    :cond_34
    move-object v0, v2

    .line 1112
    :goto_16
    if-ne v0, v3, :cond_35

    .line 1113
    .line 1114
    move-object v2, v3

    .line 1115
    :cond_35
    :goto_17
    return-object v2

    .line 1116
    :pswitch_3
    iget-object v2, v1, Lc4/d;->r:Ljava/lang/Object;

    .line 1117
    .line 1118
    check-cast v2, Ll4/q;

    .line 1119
    .line 1120
    sget-object v4, Ls6/a;->k:Ls6/a;

    .line 1121
    .line 1122
    iget v8, v1, Lc4/d;->p:I

    .line 1123
    .line 1124
    if-eqz v8, :cond_37

    .line 1125
    .line 1126
    if-ne v8, v7, :cond_36

    .line 1127
    .line 1128
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 1129
    .line 1130
    .line 1131
    goto/16 :goto_1b

    .line 1132
    .line 1133
    :cond_36
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1134
    .line 1135
    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1136
    .line 1137
    .line 1138
    throw v0

    .line 1139
    :cond_37
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 1140
    .line 1141
    .line 1142
    iget-object v0, v1, Lc4/d;->q:Ljava/lang/Object;

    .line 1143
    .line 1144
    check-cast v0, Lh4/i;

    .line 1145
    .line 1146
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1147
    .line 1148
    .line 1149
    iget-object v0, v0, Lh4/i;->k:Ljava/util/List;

    .line 1150
    .line 1151
    new-instance v6, Ljava/util/ArrayList;

    .line 1152
    .line 1153
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 1154
    .line 1155
    .line 1156
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1157
    .line 1158
    .line 1159
    move-result-object v0

    .line 1160
    :cond_38
    :goto_18
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 1161
    .line 1162
    .line 1163
    move-result v8

    .line 1164
    if-eqz v8, :cond_39

    .line 1165
    .line 1166
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1167
    .line 1168
    .line 1169
    move-result-object v8

    .line 1170
    move-object v9, v8

    .line 1171
    check-cast v9, Li4/e;

    .line 1172
    .line 1173
    invoke-virtual {v9, v2}, Li4/e;->b(Ll4/q;)Z

    .line 1174
    .line 1175
    .line 1176
    move-result v9

    .line 1177
    if-eqz v9, :cond_38

    .line 1178
    .line 1179
    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1180
    .line 1181
    .line 1182
    goto :goto_18

    .line 1183
    :cond_39
    new-instance v0, Ljava/util/ArrayList;

    .line 1184
    .line 1185
    invoke-static {v6, v3}, Lo6/l;->O(Ljava/lang/Iterable;I)I

    .line 1186
    .line 1187
    .line 1188
    move-result v3

    .line 1189
    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 1190
    .line 1191
    .line 1192
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 1193
    .line 1194
    .line 1195
    move-result v3

    .line 1196
    move v8, v5

    .line 1197
    :goto_19
    if-ge v8, v3, :cond_3a

    .line 1198
    .line 1199
    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1200
    .line 1201
    .line 1202
    move-result-object v9

    .line 1203
    add-int/lit8 v8, v8, 0x1

    .line 1204
    .line 1205
    check-cast v9, Li4/e;

    .line 1206
    .line 1207
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1208
    .line 1209
    .line 1210
    new-instance v10, Li4/d;

    .line 1211
    .line 1212
    const/4 v11, 0x0

    .line 1213
    invoke-direct {v10, v9, v11, v5}, Li4/d;-><init>(Ljava/lang/Object;Lr6/d;I)V

    .line 1214
    .line 1215
    .line 1216
    new-instance v9, Lh4/h;

    .line 1217
    .line 1218
    invoke-direct {v9, v7, v10}, Lh4/h;-><init>(ILjava/io/Serializable;)V

    .line 1219
    .line 1220
    .line 1221
    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1222
    .line 1223
    .line 1224
    goto :goto_19

    .line 1225
    :cond_3a
    invoke-static {v0}, Lo6/j;->k0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 1226
    .line 1227
    .line 1228
    move-result-object v0

    .line 1229
    new-array v3, v5, [Li7/d;

    .line 1230
    .line 1231
    invoke-interface {v0, v3}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 1232
    .line 1233
    .line 1234
    move-result-object v0

    .line 1235
    check-cast v0, [Li7/d;

    .line 1236
    .line 1237
    new-instance v3, Lh4/h;

    .line 1238
    .line 1239
    invoke-direct {v3, v5, v0}, Lh4/h;-><init>(ILjava/io/Serializable;)V

    .line 1240
    .line 1241
    .line 1242
    instance-of v0, v3, Li7/g;

    .line 1243
    .line 1244
    if-eqz v0, :cond_3b

    .line 1245
    .line 1246
    goto :goto_1a

    .line 1247
    :cond_3b
    new-instance v0, Li7/c;

    .line 1248
    .line 1249
    invoke-direct {v0, v3}, Li7/c;-><init>(Lh4/h;)V

    .line 1250
    .line 1251
    .line 1252
    move-object v3, v0

    .line 1253
    :goto_1a
    new-instance v0, Ll4/l;

    .line 1254
    .line 1255
    iget-object v5, v1, Lc4/d;->s:Ljava/lang/Object;

    .line 1256
    .line 1257
    check-cast v5, Lh4/e;

    .line 1258
    .line 1259
    invoke-direct {v0, v5, v2}, Ll4/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1260
    .line 1261
    .line 1262
    iput v7, v1, Lc4/d;->p:I

    .line 1263
    .line 1264
    invoke-interface {v3, v0, v1}, Li7/d;->a(Li7/e;Lr6/d;)Ljava/lang/Object;

    .line 1265
    .line 1266
    .line 1267
    move-result-object v0

    .line 1268
    if-ne v0, v4, :cond_3c

    .line 1269
    .line 1270
    goto :goto_1c

    .line 1271
    :cond_3c
    :goto_1b
    sget-object v4, Ln6/j;->a:Ln6/j;

    .line 1272
    .line 1273
    :goto_1c
    return-object v4

    .line 1274
    :pswitch_4
    iget v2, v1, Lc4/d;->p:I

    .line 1275
    .line 1276
    if-eqz v2, :cond_3e

    .line 1277
    .line 1278
    if-ne v2, v7, :cond_3d

    .line 1279
    .line 1280
    iget-object v2, v1, Lc4/d;->q:Ljava/lang/Object;

    .line 1281
    .line 1282
    check-cast v2, Lc4/k;

    .line 1283
    .line 1284
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 1285
    .line 1286
    .line 1287
    iget-object v2, v2, Lc4/k;->k:Ln4/k;

    .line 1288
    .line 1289
    invoke-virtual {v2, v0}, Ln4/k;->i(Ljava/lang/Object;)Z

    .line 1290
    .line 1291
    .line 1292
    sget-object v0, Ln6/j;->a:Ln6/j;

    .line 1293
    .line 1294
    return-object v0

    .line 1295
    :cond_3d
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1296
    .line 1297
    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1298
    .line 1299
    .line 1300
    throw v0

    .line 1301
    :cond_3e
    invoke-static {v0}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 1302
    .line 1303
    .line 1304
    iget-object v0, v1, Lc4/d;->r:Ljava/lang/Object;

    .line 1305
    .line 1306
    check-cast v0, Lc4/k;

    .line 1307
    .line 1308
    iput-object v0, v1, Lc4/d;->q:Ljava/lang/Object;

    .line 1309
    .line 1310
    iput v7, v1, Lc4/d;->p:I

    .line 1311
    .line 1312
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 1313
    .line 1314
    const-string v2, "Not implemented"

    .line 1315
    .line 1316
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1317
    .line 1318
    .line 1319
    throw v0

    .line 1320
    nop

    .line 1321
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
