.class public final Lb8/w;
.super Lb8/x;
.source "SourceFile"


# virtual methods
.method public final d(J)Lb8/x;
    .locals 0

    .line 1
    return-object p0
.end method

.method public final f()V
    .locals 0

    .line 1
    return-void
.end method

.method public final g(J)Lb8/x;
    .locals 0

    .line 1
    sget-object p1, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-string p2, "unit"

    invoke-static {p1, p2}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method
