.class public interface abstract Lb5/o;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/graphics/Bitmap;Lv4/a;)V
.end method

.method public abstract k()V
.end method
