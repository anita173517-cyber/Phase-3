.class public interface abstract Landroidx/lifecycle/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/q;


# virtual methods
.method public abstract a(Landroidx/lifecycle/r;Landroidx/lifecycle/j;)V
.end method
