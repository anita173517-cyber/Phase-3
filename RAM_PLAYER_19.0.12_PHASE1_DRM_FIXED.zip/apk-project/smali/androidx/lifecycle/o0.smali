.class public interface abstract Landroidx/lifecycle/o0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(Ljava/lang/Class;)Landroidx/lifecycle/n0;
.end method

.method public abstract g(Ljava/lang/Class;Ls0/b;)Landroidx/lifecycle/n0;
.end method

.method public abstract p(La7/e;Ls0/b;)Landroidx/lifecycle/n0;
.end method
