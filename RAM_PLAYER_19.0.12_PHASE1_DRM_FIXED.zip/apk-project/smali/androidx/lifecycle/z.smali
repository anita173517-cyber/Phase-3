.class public final synthetic Landroidx/lifecycle/z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic k:I

.field public final synthetic l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Landroidx/lifecycle/z;->k:I

    iput-object p2, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ld1/u0;I)V
    .locals 0

    .line 2
    const/4 p2, 0x6

    iput p2, p0, Landroidx/lifecycle/z;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ld1/u0;Ld1/u1;)V
    .locals 0

    .line 3
    const/4 p1, 0x7

    iput p1, p0, Landroidx/lifecycle/z;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 4
    const/16 v0, 0x17

    iput v0, p0, Landroidx/lifecycle/z;->k:I

    sget-object v0, Lm6/f1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    return-void
.end method

.method private final a()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lcom/harindra/iptvpro/RamPlayerPlaybackService;

    .line 4
    .line 5
    iget-object v0, v0, Lcom/harindra/iptvpro/RamPlayerPlaybackService;->l:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    monitor-exit v0

    .line 9
    return-void

    .line 10
    :catchall_0
    move-exception v1

    .line 11
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    throw v1
.end method

.method private final b()V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lm0/q;

    .line 4
    .line 5
    const-string v1, "fetchFonts result is not OK. ("

    .line 6
    .line 7
    iget-object v2, v0, Lm0/q;->n:Ljava/lang/Object;

    .line 8
    .line 9
    monitor-enter v2

    .line 10
    :try_start_0
    iget-object v3, v0, Lm0/q;->r:Lw7/d;

    .line 11
    .line 12
    if-nez v3, :cond_0

    .line 13
    .line 14
    monitor-exit v2

    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    goto/16 :goto_6

    .line 18
    .line 19
    :cond_0
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    :try_start_1
    invoke-virtual {v0}, Lm0/q;->d()Lb0/j;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    iget v3, v2, Lb0/j;->e:I

    .line 25
    .line 26
    const/4 v4, 0x2

    .line 27
    if-ne v3, v4, :cond_1

    .line 28
    .line 29
    iget-object v4, v0, Lm0/q;->n:Ljava/lang/Object;

    .line 30
    .line 31
    monitor-enter v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 32
    :try_start_2
    monitor-exit v4

    .line 33
    goto :goto_0

    .line 34
    :catchall_1
    move-exception v1

    .line 35
    monitor-exit v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 36
    :try_start_3
    throw v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 37
    :catchall_2
    move-exception v1

    .line 38
    goto/16 :goto_3

    .line 39
    .line 40
    :cond_1
    :goto_0
    if-nez v3, :cond_4

    .line 41
    .line 42
    :try_start_4
    const-string v1, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    .line 43
    .line 44
    sget v3, La0/m;->a:I

    .line 45
    .line 46
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    iget-object v1, v0, Lm0/q;->m:Li1/n;

    .line 50
    .line 51
    iget-object v3, v0, Lm0/q;->k:Landroid/content/Context;

    .line 52
    .line 53
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    const/4 v1, 0x1

    .line 57
    new-array v1, v1, [Lb0/j;

    .line 58
    .line 59
    const/4 v4, 0x0

    .line 60
    aput-object v2, v1, v4

    .line 61
    .line 62
    sget-object v5, Lx/g;->a:Landroid/support/v4/media/session/b;

    .line 63
    .line 64
    invoke-virtual {v5, v3, v1, v4}, Landroid/support/v4/media/session/b;->w(Landroid/content/Context;[Lb0/j;I)Landroid/graphics/Typeface;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    iget-object v3, v0, Lm0/q;->k:Landroid/content/Context;

    .line 69
    .line 70
    iget-object v2, v2, Lb0/j;->a:Landroid/net/Uri;

    .line 71
    .line 72
    invoke-static {v3, v2}, Lb4/a;->F(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    .line 73
    .line 74
    .line 75
    move-result-object v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_5

    .line 76
    if-eqz v2, :cond_3

    .line 77
    .line 78
    if-eqz v1, :cond_3

    .line 79
    .line 80
    :try_start_5
    const-string v3, "EmojiCompat.MetadataRepo.create"

    .line 81
    .line 82
    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    new-instance v3, Ll4/i;

    .line 86
    .line 87
    invoke-static {v2}, La/a;->D(Ljava/nio/MappedByteBuffer;)Ln0/b;

    .line 88
    .line 89
    .line 90
    move-result-object v2

    .line 91
    invoke-direct {v3, v1, v2}, Ll4/i;-><init>(Landroid/graphics/Typeface;Ln0/b;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    .line 92
    .line 93
    .line 94
    :try_start_6
    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_5

    .line 95
    .line 96
    .line 97
    :try_start_7
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 98
    .line 99
    .line 100
    iget-object v1, v0, Lm0/q;->n:Ljava/lang/Object;

    .line 101
    .line 102
    monitor-enter v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .line 103
    :try_start_8
    iget-object v2, v0, Lm0/q;->r:Lw7/d;

    .line 104
    .line 105
    if-eqz v2, :cond_2

    .line 106
    .line 107
    invoke-virtual {v2, v3}, Lw7/d;->u(Ll4/i;)V

    .line 108
    .line 109
    .line 110
    goto :goto_1

    .line 111
    :catchall_3
    move-exception v2

    .line 112
    goto :goto_2

    .line 113
    :cond_2
    :goto_1
    monitor-exit v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    .line 114
    :try_start_9
    invoke-virtual {v0}, Lm0/q;->b()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    .line 115
    .line 116
    .line 117
    return-void

    .line 118
    :goto_2
    :try_start_a
    monitor-exit v1
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    .line 119
    :try_start_b
    throw v2
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    .line 120
    :catchall_4
    move-exception v1

    .line 121
    :try_start_c
    sget v2, La0/m;->a:I

    .line 122
    .line 123
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 124
    .line 125
    .line 126
    throw v1

    .line 127
    :cond_3
    new-instance v1, Ljava/lang/RuntimeException;

    .line 128
    .line 129
    const-string v2, "Unable to open file."

    .line 130
    .line 131
    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 132
    .line 133
    .line 134
    throw v1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_5

    .line 135
    :catchall_5
    move-exception v1

    .line 136
    :try_start_d
    sget v2, La0/m;->a:I

    .line 137
    .line 138
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 139
    .line 140
    .line 141
    throw v1

    .line 142
    :cond_4
    new-instance v2, Ljava/lang/RuntimeException;

    .line 143
    .line 144
    new-instance v4, Ljava/lang/StringBuilder;

    .line 145
    .line 146
    invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 150
    .line 151
    .line 152
    const-string v1, ")"

    .line 153
    .line 154
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-direct {v2, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    throw v2
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    .line 165
    :goto_3
    iget-object v3, v0, Lm0/q;->n:Ljava/lang/Object;

    .line 166
    .line 167
    monitor-enter v3

    .line 168
    :try_start_e
    iget-object v2, v0, Lm0/q;->r:Lw7/d;

    .line 169
    .line 170
    if-eqz v2, :cond_5

    .line 171
    .line 172
    invoke-virtual {v2, v1}, Lw7/d;->t(Ljava/lang/Throwable;)V

    .line 173
    .line 174
    .line 175
    goto :goto_4

    .line 176
    :catchall_6
    move-exception v0

    .line 177
    goto :goto_5

    .line 178
    :cond_5
    :goto_4
    monitor-exit v3
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_6

    .line 179
    invoke-virtual {v0}, Lm0/q;->b()V

    .line 180
    .line 181
    .line 182
    return-void

    .line 183
    :goto_5
    :try_start_f
    monitor-exit v3
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_6

    .line 184
    throw v0

    .line 185
    :goto_6
    :try_start_10
    monitor-exit v2
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_0

    .line 186
    throw v0
.end method

.method private final c()V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lm1/f;

    .line 4
    .line 5
    iget-object v1, v0, Lm1/f;->a:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v1

    .line 8
    :try_start_0
    iget-boolean v2, v0, Lm1/f;->m:Z

    .line 9
    .line 10
    if-eqz v2, :cond_0

    .line 11
    .line 12
    monitor-exit v1

    .line 13
    return-void

    .line 14
    :catchall_0
    move-exception v0

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    iget-wide v2, v0, Lm1/f;->l:J

    .line 17
    .line 18
    const-wide/16 v4, 0x1

    .line 19
    .line 20
    sub-long/2addr v2, v4

    .line 21
    iput-wide v2, v0, Lm1/f;->l:J

    .line 22
    .line 23
    const-wide/16 v4, 0x0

    .line 24
    .line 25
    cmp-long v2, v2, v4

    .line 26
    .line 27
    if-lez v2, :cond_1

    .line 28
    .line 29
    monitor-exit v1

    .line 30
    return-void

    .line 31
    :cond_1
    if-gez v2, :cond_2

    .line 32
    .line 33
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 34
    .line 35
    invoke-direct {v2}, Ljava/lang/IllegalStateException;-><init>()V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v0, v2}, Lm1/f;->c(Ljava/lang/IllegalStateException;)V

    .line 39
    .line 40
    .line 41
    monitor-exit v1

    .line 42
    return-void

    .line 43
    :cond_2
    invoke-virtual {v0}, Lm1/f;->a()V

    .line 44
    .line 45
    .line 46
    monitor-exit v1

    .line 47
    return-void

    .line 48
    :goto_0
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 49
    throw v0
.end method

.method private final d()V
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 4
    .line 5
    iget-object v1, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->r:Ln4/k;

    .line 6
    .line 7
    iget-object v1, v1, Ln4/i;->k:Ljava/lang/Object;

    .line 8
    .line 9
    instance-of v1, v1, Ln4/a;

    .line 10
    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    return-void

    .line 14
    :cond_0
    iget-object v1, v0, Lc4/p;->l:Landroidx/work/WorkerParameters;

    .line 15
    .line 16
    iget-object v1, v1, Landroidx/work/WorkerParameters;->b:Lc4/f;

    .line 17
    .line 18
    const-string v2, "androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME"

    .line 19
    .line 20
    iget-object v1, v1, Lc4/f;->a:Ljava/util/HashMap;

    .line 21
    .line 22
    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    instance-of v2, v1, Ljava/lang/String;

    .line 27
    .line 28
    if-eqz v2, :cond_1

    .line 29
    .line 30
    check-cast v1, Ljava/lang/String;

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    const/4 v1, 0x0

    .line 34
    :goto_0
    invoke-static {}, Lc4/q;->c()Lc4/q;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    const-string v3, "get()"

    .line 39
    .line 40
    invoke-static {v2, v3}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    if-eqz v1, :cond_7

    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    if-nez v3, :cond_2

    .line 50
    .line 51
    goto/16 :goto_3

    .line 52
    .line 53
    :cond_2
    iget-object v2, v0, Lc4/p;->l:Landroidx/work/WorkerParameters;

    .line 54
    .line 55
    iget-object v2, v2, Landroidx/work/WorkerParameters;->f:Lc4/d0;

    .line 56
    .line 57
    iget-object v3, v0, Lc4/p;->k:Landroid/content/Context;

    .line 58
    .line 59
    iget-object v4, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->o:Landroidx/work/WorkerParameters;

    .line 60
    .line 61
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    invoke-static {v3, v1, v4}, Lc4/d0;->a(Landroid/content/Context;Ljava/lang/String;Landroidx/work/WorkerParameters;)Lc4/p;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    iput-object v1, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->s:Lc4/p;

    .line 69
    .line 70
    if-nez v1, :cond_3

    .line 71
    .line 72
    sget-object v1, Lp4/b;->a:Ljava/lang/String;

    .line 73
    .line 74
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->r:Ln4/k;

    .line 75
    .line 76
    const-string v1, "future"

    .line 77
    .line 78
    invoke-static {v0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    new-instance v1, Lc4/l;

    .line 82
    .line 83
    invoke-direct {v1}, Lc4/l;-><init>()V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v0, v1}, Ln4/k;->i(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    return-void

    .line 90
    :cond_3
    iget-object v1, v0, Lc4/p;->k:Landroid/content/Context;

    .line 91
    .line 92
    invoke-static {v1}, Ld4/q;->V(Landroid/content/Context;)Ld4/q;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    iget-object v2, v1, Ld4/q;->c:Landroidx/work/impl/WorkDatabase;

    .line 97
    .line 98
    invoke-virtual {v2}, Landroidx/work/impl/WorkDatabase;->t()Ll4/r;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    iget-object v3, v0, Lc4/p;->l:Landroidx/work/WorkerParameters;

    .line 103
    .line 104
    iget-object v3, v3, Landroidx/work/WorkerParameters;->a:Ljava/util/UUID;

    .line 105
    .line 106
    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    const-string v4, "id.toString()"

    .line 111
    .line 112
    invoke-static {v3, v4}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v2, v3}, Ll4/r;->k(Ljava/lang/String;)Ll4/q;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    if-nez v2, :cond_4

    .line 120
    .line 121
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->r:Ln4/k;

    .line 122
    .line 123
    const-string v1, "future"

    .line 124
    .line 125
    invoke-static {v0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    sget-object v1, Lp4/b;->a:Ljava/lang/String;

    .line 129
    .line 130
    new-instance v1, Lc4/l;

    .line 131
    .line 132
    invoke-direct {v1}, Lc4/l;-><init>()V

    .line 133
    .line 134
    .line 135
    invoke-virtual {v0, v1}, Ln4/k;->i(Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    return-void

    .line 139
    :cond_4
    new-instance v3, Lh4/i;

    .line 140
    .line 141
    iget-object v4, v1, Ld4/q;->j:Ll4/i;

    .line 142
    .line 143
    const-string v5, "workManagerImpl.trackers"

    .line 144
    .line 145
    invoke-static {v4, v5}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    invoke-direct {v3, v4}, Lh4/i;-><init>(Ll4/i;)V

    .line 149
    .line 150
    .line 151
    iget-object v1, v1, Ld4/q;->d:Ll4/i;

    .line 152
    .line 153
    iget-object v1, v1, Ll4/i;->l:Ljava/lang/Object;

    .line 154
    .line 155
    check-cast v1, Lf7/k0;

    .line 156
    .line 157
    const-string v4, "workManagerImpl.workTask\u2026r.taskCoroutineDispatcher"

    .line 158
    .line 159
    invoke-static {v1, v4}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    invoke-static {v3, v2, v1, v0}, Lh4/j;->a(Lh4/i;Ll4/q;Lf7/k0;Lh4/e;)Lf7/v0;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    iget-object v4, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->r:Ln4/k;

    .line 167
    .line 168
    new-instance v5, Landroidx/lifecycle/z;

    .line 169
    .line 170
    const/16 v6, 0x1b

    .line 171
    .line 172
    invoke-direct {v5, v6, v1}, Landroidx/lifecycle/z;-><init>(ILjava/lang/Object;)V

    .line 173
    .line 174
    .line 175
    new-instance v1, Li/q;

    .line 176
    .line 177
    const/4 v6, 0x1

    .line 178
    invoke-direct {v1, v6}, Li/q;-><init>(I)V

    .line 179
    .line 180
    .line 181
    invoke-virtual {v4, v5, v1}, Ln4/i;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 182
    .line 183
    .line 184
    invoke-virtual {v3, v2}, Lh4/i;->d(Ll4/q;)Z

    .line 185
    .line 186
    .line 187
    move-result v1

    .line 188
    if-eqz v1, :cond_6

    .line 189
    .line 190
    sget-object v1, Lp4/b;->a:Ljava/lang/String;

    .line 191
    .line 192
    :try_start_0
    iget-object v1, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->s:Lc4/p;

    .line 193
    .line 194
    invoke-static {v1}, La7/h;->b(Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v1}, Lc4/p;->c()Ln4/k;

    .line 198
    .line 199
    .line 200
    move-result-object v1

    .line 201
    const-string v2, "delegate!!.startWork()"

    .line 202
    .line 203
    invoke-static {v1, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    new-instance v2, Lp4/a;

    .line 207
    .line 208
    const/4 v3, 0x0

    .line 209
    invoke-direct {v2, v0, v3, v1}, Lp4/a;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 210
    .line 211
    .line 212
    iget-object v3, v0, Lc4/p;->l:Landroidx/work/WorkerParameters;

    .line 213
    .line 214
    iget-object v3, v3, Landroidx/work/WorkerParameters;->d:Ljava/util/concurrent/ExecutorService;

    .line 215
    .line 216
    invoke-virtual {v1, v2, v3}, Ln4/i;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 217
    .line 218
    .line 219
    return-void

    .line 220
    :catchall_0
    sget-object v1, Lp4/b;->a:Ljava/lang/String;

    .line 221
    .line 222
    iget-object v1, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->p:Ljava/lang/Object;

    .line 223
    .line 224
    monitor-enter v1

    .line 225
    :try_start_1
    iget-boolean v2, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->q:Z

    .line 226
    .line 227
    if-eqz v2, :cond_5

    .line 228
    .line 229
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->r:Ln4/k;

    .line 230
    .line 231
    const-string v2, "future"

    .line 232
    .line 233
    invoke-static {v0, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    new-instance v2, Lc4/m;

    .line 237
    .line 238
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 239
    .line 240
    .line 241
    invoke-virtual {v0, v2}, Ln4/k;->i(Ljava/lang/Object;)Z

    .line 242
    .line 243
    .line 244
    goto :goto_1

    .line 245
    :catchall_1
    move-exception v0

    .line 246
    goto :goto_2

    .line 247
    :cond_5
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->r:Ln4/k;

    .line 248
    .line 249
    const-string v2, "future"

    .line 250
    .line 251
    invoke-static {v0, v2}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 252
    .line 253
    .line 254
    new-instance v2, Lc4/l;

    .line 255
    .line 256
    invoke-direct {v2}, Lc4/l;-><init>()V

    .line 257
    .line 258
    .line 259
    invoke-virtual {v0, v2}, Ln4/k;->i(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 260
    .line 261
    .line 262
    :goto_1
    monitor-exit v1

    .line 263
    return-void

    .line 264
    :goto_2
    monitor-exit v1

    .line 265
    throw v0

    .line 266
    :cond_6
    sget-object v1, Lp4/b;->a:Ljava/lang/String;

    .line 267
    .line 268
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->r:Ln4/k;

    .line 269
    .line 270
    const-string v1, "future"

    .line 271
    .line 272
    invoke-static {v0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    new-instance v1, Lc4/m;

    .line 276
    .line 277
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 278
    .line 279
    .line 280
    invoke-virtual {v0, v1}, Ln4/k;->i(Ljava/lang/Object;)Z

    .line 281
    .line 282
    .line 283
    return-void

    .line 284
    :cond_7
    :goto_3
    sget-object v1, Lp4/b;->a:Ljava/lang/String;

    .line 285
    .line 286
    const-string v3, "No worker to delegate to."

    .line 287
    .line 288
    invoke-virtual {v2, v1, v3}, Lc4/q;->a(Ljava/lang/String;Ljava/lang/String;)V

    .line 289
    .line 290
    .line 291
    iget-object v0, v0, Landroidx/work/impl/workers/ConstraintTrackingWorker;->r:Ln4/k;

    .line 292
    .line 293
    const-string v1, "future"

    .line 294
    .line 295
    invoke-static {v0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 296
    .line 297
    .line 298
    new-instance v1, Lc4/l;

    .line 299
    .line 300
    invoke-direct {v1}, Lc4/l;-><init>()V

    .line 301
    .line 302
    .line 303
    invoke-virtual {v0, v1}, Ln4/k;->i(Ljava/lang/Object;)Z

    .line 304
    .line 305
    .line 306
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 15

    .line 1
    iget v0, p0, Landroidx/lifecycle/z;->k:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    const/16 v2, 0xa

    .line 5
    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, Lu1/p;

    .line 15
    .line 16
    iget-object v1, v0, Lu1/p;->p:Lu1/k;

    .line 17
    .line 18
    iget-boolean v1, v1, Lu1/k;->A0:Z

    .line 19
    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 23
    .line 24
    const/16 v3, 0x20

    .line 25
    .line 26
    if-lt v1, v3, :cond_0

    .line 27
    .line 28
    iget-object v1, v0, Lu1/p;->r:Lh5/r;

    .line 29
    .line 30
    if-eqz v1, :cond_0

    .line 31
    .line 32
    iget-boolean v1, v1, Lh5/r;->k:Z

    .line 33
    .line 34
    if-eqz v1, :cond_0

    .line 35
    .line 36
    iget-object v0, v0, Li/b0;->k:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v0, Ld1/u0;

    .line 39
    .line 40
    if-eqz v0, :cond_0

    .line 41
    .line 42
    iget-object v0, v0, Ld1/u0;->q:Ly0/h0;

    .line 43
    .line 44
    invoke-virtual {v0, v2, v5}, Ly0/h0;->c(ILjava/lang/Object;)Ly0/g0;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-virtual {v0}, Ly0/g0;->b()V

    .line 49
    .line 50
    .line 51
    :cond_0
    return-void

    .line 52
    :pswitch_0
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v0, Landroid/app/Activity;

    .line 55
    .line 56
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-nez v1, :cond_a

    .line 61
    .line 62
    sget-object v1, Lu/c;->g:Landroid/os/Handler;

    .line 63
    .line 64
    sget-object v2, Lu/c;->f:Ljava/lang/reflect/Method;

    .line 65
    .line 66
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 67
    .line 68
    const/16 v7, 0x1c

    .line 69
    .line 70
    if-lt v6, v7, :cond_1

    .line 71
    .line 72
    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V

    .line 73
    .line 74
    .line 75
    goto/16 :goto_5

    .line 76
    .line 77
    :cond_1
    const/16 v7, 0x1b

    .line 78
    .line 79
    const/16 v8, 0x1a

    .line 80
    .line 81
    if-eq v6, v8, :cond_2

    .line 82
    .line 83
    if-ne v6, v7, :cond_3

    .line 84
    .line 85
    :cond_2
    if-nez v2, :cond_3

    .line 86
    .line 87
    goto/16 :goto_4

    .line 88
    .line 89
    :cond_3
    sget-object v9, Lu/c;->e:Ljava/lang/reflect/Method;

    .line 90
    .line 91
    if-nez v9, :cond_4

    .line 92
    .line 93
    sget-object v9, Lu/c;->d:Ljava/lang/reflect/Method;

    .line 94
    .line 95
    if-nez v9, :cond_4

    .line 96
    .line 97
    goto/16 :goto_4

    .line 98
    .line 99
    :cond_4
    :try_start_0
    sget-object v9, Lu/c;->c:Ljava/lang/reflect/Field;

    .line 100
    .line 101
    invoke-virtual {v9, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v9

    .line 105
    if-nez v9, :cond_5

    .line 106
    .line 107
    goto/16 :goto_4

    .line 108
    .line 109
    :cond_5
    sget-object v10, Lu/c;->b:Ljava/lang/reflect/Field;

    .line 110
    .line 111
    invoke-virtual {v10, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v10

    .line 115
    if-nez v10, :cond_6

    .line 116
    .line 117
    goto :goto_4

    .line 118
    :cond_6
    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 119
    .line 120
    .line 121
    move-result-object v11

    .line 122
    new-instance v12, Lu/b;

    .line 123
    .line 124
    invoke-direct {v12, v0}, Lu/b;-><init>(Landroid/app/Activity;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v11, v12}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 128
    .line 129
    .line 130
    new-instance v13, Lcom/google/common/util/concurrent/l;

    .line 131
    .line 132
    const/16 v14, 0x11

    .line 133
    .line 134
    invoke-direct {v13, v12, v14, v9}, Lcom/google/common/util/concurrent/l;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v1, v13}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 138
    .line 139
    .line 140
    if-eq v6, v8, :cond_8

    .line 141
    .line 142
    if-ne v6, v7, :cond_7

    .line 143
    .line 144
    goto :goto_0

    .line 145
    :cond_7
    move v6, v3

    .line 146
    goto :goto_1

    .line 147
    :cond_8
    :goto_0
    move v6, v4

    .line 148
    :goto_1
    const/16 v7, 0x12

    .line 149
    .line 150
    if-eqz v6, :cond_9

    .line 151
    .line 152
    :try_start_1
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 153
    .line 154
    .line 155
    move-result-object v6

    .line 156
    const/16 v8, 0x9

    .line 157
    .line 158
    new-array v8, v8, [Ljava/lang/Object;

    .line 159
    .line 160
    aput-object v9, v8, v3

    .line 161
    .line 162
    aput-object v5, v8, v4

    .line 163
    .line 164
    const/4 v3, 0x2

    .line 165
    aput-object v5, v8, v3

    .line 166
    .line 167
    const/4 v3, 0x3

    .line 168
    aput-object v6, v8, v3

    .line 169
    .line 170
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 171
    .line 172
    const/4 v4, 0x4

    .line 173
    aput-object v3, v8, v4

    .line 174
    .line 175
    const/4 v4, 0x5

    .line 176
    aput-object v5, v8, v4

    .line 177
    .line 178
    const/4 v4, 0x6

    .line 179
    aput-object v5, v8, v4

    .line 180
    .line 181
    const/4 v4, 0x7

    .line 182
    aput-object v3, v8, v4

    .line 183
    .line 184
    const/16 v4, 0x8

    .line 185
    .line 186
    aput-object v3, v8, v4

    .line 187
    .line 188
    invoke-virtual {v2, v10, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    goto :goto_2

    .line 192
    :catchall_0
    move-exception v2

    .line 193
    goto :goto_3

    .line 194
    :cond_9
    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 195
    .line 196
    .line 197
    :goto_2
    :try_start_2
    new-instance v2, Lcom/google/common/util/concurrent/l;

    .line 198
    .line 199
    invoke-direct {v2, v11, v7, v12}, Lcom/google/common/util/concurrent/l;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 200
    .line 201
    .line 202
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 203
    .line 204
    .line 205
    goto :goto_5

    .line 206
    :goto_3
    new-instance v3, Lcom/google/common/util/concurrent/l;

    .line 207
    .line 208
    invoke-direct {v3, v11, v7, v12}, Lcom/google/common/util/concurrent/l;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 209
    .line 210
    .line 211
    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 212
    .line 213
    .line 214
    throw v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 215
    :catchall_1
    :goto_4
    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V

    .line 216
    .line 217
    .line 218
    :cond_a
    :goto_5
    return-void

    .line 219
    :pswitch_1
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 220
    .line 221
    check-cast v0, Lf7/v0;

    .line 222
    .line 223
    invoke-virtual {v0, v5}, Lf7/b1;->c(Ljava/util/concurrent/CancellationException;)V

    .line 224
    .line 225
    .line 226
    return-void

    .line 227
    :pswitch_2
    invoke-direct {p0}, Landroidx/lifecycle/z;->d()V

    .line 228
    .line 229
    .line 230
    return-void

    .line 231
    :pswitch_3
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 232
    .line 233
    check-cast v0, Landroid/os/HandlerThread;

    .line 234
    .line 235
    invoke-virtual {v0}, Landroid/os/HandlerThread;->quit()Z

    .line 236
    .line 237
    .line 238
    return-void

    .line 239
    :pswitch_4
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 240
    .line 241
    check-cast v0, Ljava/util/ArrayList;

    .line 242
    .line 243
    invoke-static {v0}, Lo6/j;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object v0

    .line 247
    check-cast v0, Landroid/widget/EditText;

    .line 248
    .line 249
    if-eqz v0, :cond_b

    .line 250
    .line 251
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 252
    .line 253
    .line 254
    :cond_b
    return-void

    .line 255
    :pswitch_5
    sget-object v0, Lm6/f1;->a:Ljava/util/concurrent/ConcurrentHashMap;

    .line 256
    .line 257
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 258
    .line 259
    check-cast v0, Ljava/lang/String;

    .line 260
    .line 261
    invoke-static {v0}, Lm6/f1;->e(Ljava/lang/String;)V

    .line 262
    .line 263
    .line 264
    return-void

    .line 265
    :pswitch_6
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 266
    .line 267
    check-cast v0, Landroidx/media3/ui/PlayerView;

    .line 268
    .line 269
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 270
    .line 271
    .line 272
    return-void

    .line 273
    :pswitch_7
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 274
    .line 275
    check-cast v0, Lm3/t;

    .line 276
    .line 277
    invoke-virtual {v0}, Lm3/t;->s()V

    .line 278
    .line 279
    .line 280
    return-void

    .line 281
    :pswitch_8
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 282
    .line 283
    check-cast v0, Lm3/e;

    .line 284
    .line 285
    invoke-virtual {v0, v3}, Lm3/e;->d(Z)V

    .line 286
    .line 287
    .line 288
    return-void

    .line 289
    :pswitch_9
    invoke-direct {p0}, Landroidx/lifecycle/z;->c()V

    .line 290
    .line 291
    .line 292
    return-void

    .line 293
    :pswitch_a
    invoke-direct {p0}, Landroidx/lifecycle/z;->b()V

    .line 294
    .line 295
    .line 296
    return-void

    .line 297
    :pswitch_b
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 298
    .line 299
    check-cast v0, Lk3/a4;

    .line 300
    .line 301
    invoke-virtual {v0}, Lk3/a4;->release()V

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :pswitch_c
    invoke-direct {p0}, Landroidx/lifecycle/z;->a()V

    .line 306
    .line 307
    .line 308
    return-void

    .line 309
    :pswitch_d
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 310
    .line 311
    check-cast v0, Lk3/v;

    .line 312
    .line 313
    invoke-virtual {v0}, Lk3/v;->N()V

    .line 314
    .line 315
    .line 316
    return-void

    .line 317
    :pswitch_e
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 318
    .line 319
    check-cast v0, Landroidx/lifecycle/c0;

    .line 320
    .line 321
    invoke-virtual {v0}, Landroidx/lifecycle/c0;->B()V

    .line 322
    .line 323
    .line 324
    return-void

    .line 325
    :pswitch_f
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 326
    .line 327
    check-cast v0, Li1/c;

    .line 328
    .line 329
    invoke-virtual {v0, v5}, Li1/c;->e(Li1/l;)V

    .line 330
    .line 331
    .line 332
    return-void

    .line 333
    :pswitch_10
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 334
    .line 335
    check-cast v0, Li1/f;

    .line 336
    .line 337
    iget-boolean v1, v0, Li1/f;->m:Z

    .line 338
    .line 339
    if-eqz v1, :cond_c

    .line 340
    .line 341
    goto :goto_6

    .line 342
    :cond_c
    iget-object v1, v0, Li1/f;->l:Li1/i;

    .line 343
    .line 344
    if-eqz v1, :cond_d

    .line 345
    .line 346
    iget-object v2, v0, Li1/f;->k:Li1/l;

    .line 347
    .line 348
    invoke-interface {v1, v2}, Li1/i;->e(Li1/l;)V

    .line 349
    .line 350
    .line 351
    :cond_d
    iget-object v1, v0, Li1/f;->n:Li1/g;

    .line 352
    .line 353
    iget-object v1, v1, Li1/g;->w:Ljava/util/Set;

    .line 354
    .line 355
    invoke-interface {v1, v0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 356
    .line 357
    .line 358
    iput-boolean v4, v0, Li1/f;->m:Z

    .line 359
    .line 360
    :goto_6
    return-void

    .line 361
    :pswitch_11
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 362
    .line 363
    check-cast v0, Lf1/r0;

    .line 364
    .line 365
    iget-wide v1, v0, Lf1/r0;->d0:J

    .line 366
    .line 367
    const-wide/32 v5, 0x493e0

    .line 368
    .line 369
    .line 370
    cmp-long v1, v1, v5

    .line 371
    .line 372
    if-ltz v1, :cond_e

    .line 373
    .line 374
    iget-object v1, v0, Lf1/r0;->n:Landroidx/lifecycle/c0;

    .line 375
    .line 376
    iget v2, v1, Landroidx/lifecycle/c0;->k:I

    .line 377
    .line 378
    packed-switch v2, :pswitch_data_1

    .line 379
    .line 380
    .line 381
    iget-object v1, v1, Landroidx/lifecycle/c0;->l:Ljava/lang/Object;

    .line 382
    .line 383
    check-cast v1, Lf1/v0;

    .line 384
    .line 385
    iput-boolean v4, v1, Lf1/v0;->j1:Z

    .line 386
    .line 387
    goto :goto_7

    .line 388
    :pswitch_12
    iget-object v1, v1, Landroidx/lifecycle/c0;->l:Ljava/lang/Object;

    .line 389
    .line 390
    check-cast v1, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;

    .line 391
    .line 392
    iput-boolean v4, v1, Landroidx/media3/decoder/ffmpeg/FfmpegAudioRenderer;->a0:Z

    .line 393
    .line 394
    :goto_7
    const-wide/16 v1, 0x0

    .line 395
    .line 396
    iput-wide v1, v0, Lf1/r0;->d0:J

    .line 397
    .line 398
    :cond_e
    return-void

    .line 399
    :pswitch_13
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 400
    .line 401
    check-cast v0, Ly0/q;

    .line 402
    .line 403
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 404
    .line 405
    .line 406
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 407
    .line 408
    .line 409
    move-result-object v3

    .line 410
    iget-object v4, v0, Ly0/q;->a:Ljava/lang/Thread;

    .line 411
    .line 412
    if-ne v3, v4, :cond_f

    .line 413
    .line 414
    new-instance v3, Le1/f;

    .line 415
    .line 416
    invoke-direct {v3, v2}, Le1/f;-><init>(I)V

    .line 417
    .line 418
    .line 419
    invoke-virtual {v0, v1, v3}, Ly0/q;->f(ILy0/n;)V

    .line 420
    .line 421
    .line 422
    :cond_f
    return-void

    .line 423
    :pswitch_14
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 424
    .line 425
    check-cast v0, Lf1/f;

    .line 426
    .line 427
    invoke-virtual {v0}, Lf1/f;->c()V

    .line 428
    .line 429
    .line 430
    return-void

    .line 431
    :pswitch_15
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 432
    .line 433
    check-cast v0, Le1/g;

    .line 434
    .line 435
    invoke-virtual {v0}, Le1/g;->W()Le1/a;

    .line 436
    .line 437
    .line 438
    move-result-object v1

    .line 439
    new-instance v3, Le1/d;

    .line 440
    .line 441
    invoke-direct {v3, v2}, Le1/d;-><init>(I)V

    .line 442
    .line 443
    .line 444
    const/16 v2, 0x404

    .line 445
    .line 446
    invoke-virtual {v0, v1, v2, v3}, Le1/g;->b0(Le1/a;ILy0/n;)V

    .line 447
    .line 448
    .line 449
    iget-object v0, v0, Le1/g;->p:Ly0/q;

    .line 450
    .line 451
    invoke-virtual {v0}, Ly0/q;->d()V

    .line 452
    .line 453
    .line 454
    return-void

    .line 455
    :pswitch_16
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 456
    .line 457
    check-cast v0, Ld1/u1;

    .line 458
    .line 459
    :try_start_3
    monitor-enter v0

    .line 460
    monitor-exit v0
    :try_end_3
    .catch Ld1/k; {:try_start_3 .. :try_end_3} :catch_0

    .line 461
    :try_start_4
    iget-object v1, v0, Ld1/u1;->a:Ld1/t1;

    .line 462
    .line 463
    iget v2, v0, Ld1/u1;->c:I

    .line 464
    .line 465
    iget-object v3, v0, Ld1/u1;->d:Ljava/lang/Object;

    .line 466
    .line 467
    invoke-interface {v1, v2, v3}, Ld1/t1;->b(ILjava/lang/Object;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 468
    .line 469
    .line 470
    :try_start_5
    invoke-virtual {v0, v4}, Ld1/u1;->a(Z)V

    .line 471
    .line 472
    .line 473
    return-void

    .line 474
    :catchall_2
    move-exception v1

    .line 475
    invoke-virtual {v0, v4}, Ld1/u1;->a(Z)V

    .line 476
    .line 477
    .line 478
    throw v1
    :try_end_5
    .catch Ld1/k; {:try_start_5 .. :try_end_5} :catch_0

    .line 479
    :catch_0
    move-exception v0

    .line 480
    const-string v1, "ExoPlayerImplInternal"

    .line 481
    .line 482
    const-string v2, "Unexpected error delivering message on external thread."

    .line 483
    .line 484
    invoke-static {v1, v2, v0}, Ly0/a;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 485
    .line 486
    .line 487
    new-instance v1, Ljava/lang/RuntimeException;

    .line 488
    .line 489
    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 490
    .line 491
    .line 492
    throw v1

    .line 493
    :pswitch_17
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 494
    .line 495
    check-cast v0, Ld1/u0;

    .line 496
    .line 497
    iget-object v0, v0, Ld1/u0;->G:Le1/g;

    .line 498
    .line 499
    invoke-virtual {v0}, Le1/g;->W()Le1/a;

    .line 500
    .line 501
    .line 502
    move-result-object v1

    .line 503
    new-instance v2, La2/p;

    .line 504
    .line 505
    const/16 v3, 0x18

    .line 506
    .line 507
    invoke-direct {v2, v3}, La2/p;-><init>(I)V

    .line 508
    .line 509
    .line 510
    const/16 v3, 0x40a

    .line 511
    .line 512
    invoke-virtual {v0, v1, v3, v2}, Le1/g;->b0(Le1/a;ILy0/n;)V

    .line 513
    .line 514
    .line 515
    return-void

    .line 516
    :pswitch_18
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 517
    .line 518
    check-cast v0, Ld1/k0;

    .line 519
    .line 520
    iget-object v2, v0, Ld1/k0;->M:Lo/p;

    .line 521
    .line 522
    iget-object v4, v0, Ld1/k0;->o:Landroid/content/Context;

    .line 523
    .line 524
    sget-object v5, Ly0/k0;->a:Ljava/lang/String;

    .line 525
    .line 526
    invoke-static {v4}, Lw0/h;->m(Landroid/content/Context;)Landroid/media/AudioManager;

    .line 527
    .line 528
    .line 529
    move-result-object v4

    .line 530
    invoke-virtual {v4}, Landroid/media/AudioManager;->generateAudioSessionId()I

    .line 531
    .line 532
    .line 533
    move-result v4

    .line 534
    if-eq v4, v1, :cond_10

    .line 535
    .line 536
    goto :goto_8

    .line 537
    :cond_10
    move v4, v3

    .line 538
    :goto_8
    invoke-virtual {v2}, Lo/p;->j()Ljava/lang/Object;

    .line 539
    .line 540
    .line 541
    move-result-object v1

    .line 542
    check-cast v1, Ljava/lang/Integer;

    .line 543
    .line 544
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 545
    .line 546
    .line 547
    move-result v1

    .line 548
    if-eq v1, v4, :cond_12

    .line 549
    .line 550
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 551
    .line 552
    .line 553
    move-result-object v1

    .line 554
    iput-object v1, v2, Lo/p;->f:Ljava/lang/Object;

    .line 555
    .line 556
    new-instance v5, Ly0/b;

    .line 557
    .line 558
    invoke-direct {v5, v2, v1, v3}, Ly0/b;-><init>(Lo/p;Ljava/lang/Object;I)V

    .line 559
    .line 560
    .line 561
    iget-object v1, v2, Lo/p;->c:Ljava/lang/Object;

    .line 562
    .line 563
    check-cast v1, Ly0/h0;

    .line 564
    .line 565
    iget-object v2, v1, Ly0/h0;->a:Landroid/os/Handler;

    .line 566
    .line 567
    invoke-virtual {v2}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 568
    .line 569
    .line 570
    move-result-object v2

    .line 571
    invoke-virtual {v2}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 572
    .line 573
    .line 574
    move-result-object v2

    .line 575
    invoke-virtual {v2}, Ljava/lang/Thread;->isAlive()Z

    .line 576
    .line 577
    .line 578
    move-result v2

    .line 579
    if-nez v2, :cond_11

    .line 580
    .line 581
    goto :goto_9

    .line 582
    :cond_11
    invoke-virtual {v1, v5}, Ly0/h0;->e(Ljava/lang/Runnable;)Z

    .line 583
    .line 584
    .line 585
    :goto_9
    iget-object v0, v0, Ld1/k0;->v:Ld1/u0;

    .line 586
    .line 587
    iget-object v0, v0, Ld1/u0;->q:Ly0/h0;

    .line 588
    .line 589
    const/16 v1, 0x28

    .line 590
    .line 591
    invoke-virtual {v0, v1, v4, v3}, Ly0/h0;->b(III)Ly0/g0;

    .line 592
    .line 593
    .line 594
    move-result-object v1

    .line 595
    iget-object v0, v0, Ly0/h0;->a:Landroid/os/Handler;

    .line 596
    .line 597
    iget-object v2, v1, Ly0/g0;->a:Landroid/os/Message;

    .line 598
    .line 599
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 600
    .line 601
    .line 602
    invoke-virtual {v0, v2}, Landroid/os/Handler;->sendMessageAtFrontOfQueue(Landroid/os/Message;)Z

    .line 603
    .line 604
    .line 605
    invoke-virtual {v1}, Ly0/g0;->a()V

    .line 606
    .line 607
    .line 608
    :cond_12
    return-void

    .line 609
    :pswitch_19
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 610
    .line 611
    check-cast v0, Landroidx/work/CoroutineWorker;

    .line 612
    .line 613
    iget-object v1, v0, Landroidx/work/CoroutineWorker;->p:Ln4/k;

    .line 614
    .line 615
    iget-object v1, v1, Ln4/i;->k:Ljava/lang/Object;

    .line 616
    .line 617
    instance-of v1, v1, Ln4/a;

    .line 618
    .line 619
    if-eqz v1, :cond_13

    .line 620
    .line 621
    iget-object v0, v0, Landroidx/work/CoroutineWorker;->o:Lf7/v0;

    .line 622
    .line 623
    invoke-virtual {v0, v5}, Lf7/b1;->c(Ljava/util/concurrent/CancellationException;)V

    .line 624
    .line 625
    .line 626
    :cond_13
    return-void

    .line 627
    :pswitch_1a
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 628
    .line 629
    check-cast v0, Li/h;

    .line 630
    .line 631
    invoke-static {v0}, Li/h;->b(Li/h;)V

    .line 632
    .line 633
    .line 634
    return-void

    .line 635
    :pswitch_1b
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 636
    .line 637
    check-cast v0, Lc/j;

    .line 638
    .line 639
    iget-object v1, v0, Lc/j;->l:Ljava/lang/Runnable;

    .line 640
    .line 641
    if-eqz v1, :cond_14

    .line 642
    .line 643
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    .line 644
    .line 645
    .line 646
    iput-object v5, v0, Lc/j;->l:Ljava/lang/Runnable;

    .line 647
    .line 648
    :cond_14
    return-void

    .line 649
    :pswitch_1c
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 650
    .line 651
    check-cast v0, Li/k;

    .line 652
    .line 653
    invoke-virtual {v0}, Landroid/app/Activity;->invalidateOptionsMenu()V

    .line 654
    .line 655
    .line 656
    return-void

    .line 657
    :pswitch_1d
    iget-object v0, p0, Landroidx/lifecycle/z;->l:Ljava/lang/Object;

    .line 658
    .line 659
    check-cast v0, Landroidx/lifecycle/d0;

    .line 660
    .line 661
    iget-object v1, v0, Landroidx/lifecycle/d0;->p:Landroidx/lifecycle/t;

    .line 662
    .line 663
    iget v2, v0, Landroidx/lifecycle/d0;->l:I

    .line 664
    .line 665
    if-nez v2, :cond_15

    .line 666
    .line 667
    iput-boolean v4, v0, Landroidx/lifecycle/d0;->m:Z

    .line 668
    .line 669
    sget-object v2, Landroidx/lifecycle/j;->ON_PAUSE:Landroidx/lifecycle/j;

    .line 670
    .line 671
    invoke-virtual {v1, v2}, Landroidx/lifecycle/t;->d(Landroidx/lifecycle/j;)V

    .line 672
    .line 673
    .line 674
    :cond_15
    iget v2, v0, Landroidx/lifecycle/d0;->k:I

    .line 675
    .line 676
    if-nez v2, :cond_16

    .line 677
    .line 678
    iget-boolean v2, v0, Landroidx/lifecycle/d0;->m:Z

    .line 679
    .line 680
    if-eqz v2, :cond_16

    .line 681
    .line 682
    sget-object v2, Landroidx/lifecycle/j;->ON_STOP:Landroidx/lifecycle/j;

    .line 683
    .line 684
    invoke-virtual {v1, v2}, Landroidx/lifecycle/t;->d(Landroidx/lifecycle/j;)V

    .line 685
    .line 686
    .line 687
    iput-boolean v4, v0, Landroidx/lifecycle/d0;->n:Z

    .line 688
    .line 689
    :cond_16
    return-void

    .line 690
    nop

    .line 691
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    :pswitch_data_1
    .packed-switch 0xf
        :pswitch_12
    .end packed-switch
.end method
