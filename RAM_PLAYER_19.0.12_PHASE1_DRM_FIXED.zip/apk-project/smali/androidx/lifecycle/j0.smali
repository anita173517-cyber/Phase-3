.class public final Landroidx/lifecycle/j0;
.super La7/i;
.source "SourceFile"

# interfaces
.implements Lz6/a;


# instance fields
.field public final synthetic l:I

.field public final synthetic m:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Landroidx/lifecycle/j0;->l:I

    iput-object p2, p0, Landroidx/lifecycle/j0;->m:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, La7/i;-><init>(I)V

    return-void
.end method

.method public constructor <init>(Lz6/a;)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, Landroidx/lifecycle/j0;->l:I

    .line 2
    check-cast p1, La7/i;

    iput-object p1, p0, Landroidx/lifecycle/j0;->m:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, La7/i;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final b()Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, Landroidx/lifecycle/j0;->l:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/lifecycle/j0;->m:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lw3/g;

    .line 9
    .line 10
    iget-object v2, v0, Lw3/g;->k:Landroid/content/Context;

    .line 11
    .line 12
    iget-object v1, v0, Lw3/g;->l:Ljava/lang/String;

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    iget-boolean v3, v0, Lw3/g;->n:Z

    .line 17
    .line 18
    if-eqz v3, :cond_0

    .line 19
    .line 20
    new-instance v3, Ljava/io/File;

    .line 21
    .line 22
    invoke-virtual {v2}, Landroid/content/Context;->getNoBackupFilesDir()Ljava/io/File;

    .line 23
    .line 24
    .line 25
    move-result-object v4

    .line 26
    const-string v5, "context.noBackupFilesDir"

    .line 27
    .line 28
    invoke-static {v4, v5}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-direct {v3, v4, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    new-instance v1, Lw3/f;

    .line 35
    .line 36
    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    new-instance v4, Lu4/k;

    .line 41
    .line 42
    const/4 v5, 0x6

    .line 43
    invoke-direct {v4, v5}, Lu4/k;-><init>(I)V

    .line 44
    .line 45
    .line 46
    iget-object v5, v0, Lw3/g;->m:Le1/l;

    .line 47
    .line 48
    iget-boolean v6, v0, Lw3/g;->o:Z

    .line 49
    .line 50
    invoke-direct/range {v1 .. v6}, Lw3/f;-><init>(Landroid/content/Context;Ljava/lang/String;Lu4/k;Le1/l;Z)V

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_0
    new-instance v1, Lw3/f;

    .line 55
    .line 56
    iget-object v3, v0, Lw3/g;->l:Ljava/lang/String;

    .line 57
    .line 58
    new-instance v4, Lu4/k;

    .line 59
    .line 60
    const/4 v5, 0x6

    .line 61
    invoke-direct {v4, v5}, Lu4/k;-><init>(I)V

    .line 62
    .line 63
    .line 64
    iget-object v5, v0, Lw3/g;->m:Le1/l;

    .line 65
    .line 66
    iget-boolean v6, v0, Lw3/g;->o:Z

    .line 67
    .line 68
    invoke-direct/range {v1 .. v6}, Lw3/f;-><init>(Landroid/content/Context;Ljava/lang/String;Lu4/k;Le1/l;Z)V

    .line 69
    .line 70
    .line 71
    :goto_0
    iget-boolean v0, v0, Lw3/g;->q:Z

    .line 72
    .line 73
    invoke-virtual {v1, v0}, Landroid/database/sqlite/SQLiteOpenHelper;->setWriteAheadLoggingEnabled(Z)V

    .line 74
    .line 75
    .line 76
    return-object v1

    .line 77
    :pswitch_0
    iget-object v0, p0, Landroidx/lifecycle/j0;->m:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v0, Le6/f;

    .line 80
    .line 81
    invoke-virtual {v0}, Le6/f;->b()Lw3/i;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    return-object v0

    .line 86
    :pswitch_1
    :try_start_0
    iget-object v0, p0, Landroidx/lifecycle/j0;->m:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v0, La7/i;

    .line 89
    .line 90
    invoke-interface {v0}, Lz6/a;->b()Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    check-cast v0, Ljava/util/List;
    :try_end_0
    .catch Ljavax/net/ssl/SSLPeerUnverifiedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 95
    .line 96
    goto :goto_1

    .line 97
    :catch_0
    sget-object v0, Lo6/r;->k:Lo6/r;

    .line 98
    .line 99
    :goto_1
    return-object v0

    .line 100
    :pswitch_2
    iget-object v0, p0, Landroidx/lifecycle/j0;->m:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v0, Ljava/util/List;

    .line 103
    .line 104
    return-object v0

    .line 105
    :pswitch_3
    iget-object v0, p0, Landroidx/lifecycle/j0;->m:Ljava/lang/Object;

    .line 106
    .line 107
    check-cast v0, [Li7/d;

    .line 108
    .line 109
    array-length v0, v0

    .line 110
    new-array v0, v0, [Lh4/c;

    .line 111
    .line 112
    return-object v0

    .line 113
    :pswitch_4
    iget-object v0, p0, Landroidx/lifecycle/j0;->m:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v0, Li/k;

    .line 116
    .line 117
    new-instance v1, La2/h;

    .line 118
    .line 119
    const/4 v2, 0x6

    .line 120
    invoke-direct {v1, v2}, La2/h;-><init>(I)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v0}, Lc/k;->f()Landroidx/lifecycle/p0;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    new-instance v3, Ls0/b;

    .line 128
    .line 129
    sget-object v4, Ls0/a;->l:Ls0/a;

    .line 130
    .line 131
    invoke-direct {v3, v4}, Ls0/b;-><init>(Le6/e;)V

    .line 132
    .line 133
    .line 134
    iget-object v4, v3, Le6/e;->k:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast v4, Ljava/util/LinkedHashMap;

    .line 137
    .line 138
    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 139
    .line 140
    .line 141
    move-result-object v5

    .line 142
    if-eqz v5, :cond_1

    .line 143
    .line 144
    sget-object v5, Landroidx/lifecycle/i0;->n:La2/h;

    .line 145
    .line 146
    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 147
    .line 148
    .line 149
    move-result-object v6

    .line 150
    invoke-interface {v4, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    :cond_1
    sget-object v5, Landroidx/lifecycle/i0;->k:La2/h;

    .line 154
    .line 155
    invoke-interface {v4, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    sget-object v5, Landroidx/lifecycle/i0;->l:La2/h;

    .line 159
    .line 160
    invoke-interface {v4, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 164
    .line 165
    .line 166
    move-result-object v5

    .line 167
    if-eqz v5, :cond_2

    .line 168
    .line 169
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 170
    .line 171
    .line 172
    move-result-object v5

    .line 173
    invoke-virtual {v5}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 174
    .line 175
    .line 176
    move-result-object v5

    .line 177
    if-eqz v5, :cond_2

    .line 178
    .line 179
    sget-object v5, Landroidx/lifecycle/i0;->m:La2/h;

    .line 180
    .line 181
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    invoke-interface {v4, v5, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    :cond_2
    const-string v0, "store"

    .line 193
    .line 194
    invoke-static {v2, v0}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    new-instance v0, Ll4/t;

    .line 198
    .line 199
    invoke-direct {v0, v2, v1, v3}, Ll4/t;-><init>(Landroidx/lifecycle/p0;Landroidx/lifecycle/o0;Le6/e;)V

    .line 200
    .line 201
    .line 202
    const-class v1, Landroidx/lifecycle/l0;

    .line 203
    .line 204
    invoke-static {v1}, La7/n;->a(Ljava/lang/Class;)La7/e;

    .line 205
    .line 206
    .line 207
    move-result-object v1

    .line 208
    const-string v2, "androidx.lifecycle.internal.SavedStateHandlesVM"

    .line 209
    .line 210
    invoke-virtual {v0, v1, v2}, Ll4/t;->B(La7/e;Ljava/lang/String;)Landroidx/lifecycle/n0;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    check-cast v0, Landroidx/lifecycle/l0;

    .line 215
    .line 216
    return-object v0

    .line 217
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
