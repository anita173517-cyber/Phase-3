.class public final Landroidx/lifecycle/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic k:I

.field public final l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Landroidx/lifecycle/w;->k:I

    iput-object p2, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lu4/k;I)V
    .locals 0

    const/4 p2, 0x1

    iput p2, p0, Landroidx/lifecycle/w;->k:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    return-void
.end method

.method private final b()V
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lq3/g;

    .line 4
    .line 5
    iget-object v0, v0, Lq3/g;->a:Landroidx/work/impl/WorkDatabase_Impl;

    .line 6
    .line 7
    iget-object v0, v0, Landroidx/work/impl/WorkDatabase;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    const-string v1, "readWriteLock.readLock()"

    .line 14
    .line 15
    invoke-static {v0, v1}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    .line 19
    .line 20
    .line 21
    :try_start_0
    iget-object v1, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v1, Lq3/g;

    .line 24
    .line 25
    invoke-virtual {v1}, Lq3/g;->a()Z

    .line 26
    .line 27
    .line 28
    move-result v1
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 29
    if-nez v1, :cond_0

    .line 30
    .line 31
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_0
    :try_start_1
    iget-object v1, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v1, Lq3/g;

    .line 38
    .line 39
    iget-object v1, v1, Lq3/g;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 40
    .line 41
    const/4 v2, 0x1

    .line 42
    const/4 v3, 0x0

    .line 43
    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 44
    .line 45
    .line 46
    move-result v1
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 47
    if-nez v1, :cond_1

    .line 48
    .line 49
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_1
    :try_start_2
    iget-object v1, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 54
    .line 55
    check-cast v1, Lq3/g;

    .line 56
    .line 57
    iget-object v1, v1, Lq3/g;->a:Landroidx/work/impl/WorkDatabase_Impl;

    .line 58
    .line 59
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->h()Lv3/c;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    invoke-interface {v1}, Lv3/c;->y()Lw3/c;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-virtual {v1}, Lw3/c;->o()Z

    .line 68
    .line 69
    .line 70
    move-result v1
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 71
    if-eqz v1, :cond_2

    .line 72
    .line 73
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :cond_2
    :try_start_3
    iget-object v1, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v1, Lq3/g;

    .line 80
    .line 81
    iget-object v1, v1, Lq3/g;->a:Landroidx/work/impl/WorkDatabase_Impl;

    .line 82
    .line 83
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->h()Lv3/c;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-interface {v1}, Lv3/c;->y()Lw3/c;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    invoke-virtual {v1}, Lw3/c;->c()V
    :try_end_3
    .catch Ljava/lang/IllegalStateException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 92
    .line 93
    .line 94
    :try_start_4
    invoke-virtual {p0}, Landroidx/lifecycle/w;->a()Lp6/i;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    invoke-virtual {v1}, Lw3/c;->E()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 99
    .line 100
    .line 101
    :try_start_5
    invoke-virtual {v1}, Lw3/c;->g()V
    :try_end_5
    .catch Ljava/lang/IllegalStateException; {:try_start_5 .. :try_end_5} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 102
    .line 103
    .line 104
    :goto_0
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 105
    .line 106
    .line 107
    goto :goto_3

    .line 108
    :catchall_0
    move-exception v1

    .line 109
    goto :goto_7

    .line 110
    :catch_0
    move-exception v1

    .line 111
    goto :goto_1

    .line 112
    :catch_1
    move-exception v1

    .line 113
    goto :goto_2

    .line 114
    :catchall_1
    move-exception v2

    .line 115
    :try_start_6
    invoke-virtual {v1}, Lw3/c;->g()V

    .line 116
    .line 117
    .line 118
    throw v2
    :try_end_6
    .catch Ljava/lang/IllegalStateException; {:try_start_6 .. :try_end_6} :catch_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 119
    :goto_1
    :try_start_7
    const-string v2, "ROOM"

    .line 120
    .line 121
    const-string v3, "Cannot run invalidation tracker. Is the db closed?"

    .line 122
    .line 123
    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 124
    .line 125
    .line 126
    sget-object v2, Lo6/t;->k:Lo6/t;

    .line 127
    .line 128
    goto :goto_0

    .line 129
    :goto_2
    const-string v2, "ROOM"

    .line 130
    .line 131
    const-string v3, "Cannot run invalidation tracker. Is the db closed?"

    .line 132
    .line 133
    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 134
    .line 135
    .line 136
    sget-object v2, Lo6/t;->k:Lo6/t;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    .line 137
    .line 138
    goto :goto_0

    .line 139
    :goto_3
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 140
    .line 141
    .line 142
    move-result v0

    .line 143
    if-nez v0, :cond_4

    .line 144
    .line 145
    iget-object v0, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 146
    .line 147
    check-cast v0, Lq3/g;

    .line 148
    .line 149
    iget-object v1, v0, Lq3/g;->i:Lq/f;

    .line 150
    .line 151
    monitor-enter v1

    .line 152
    :try_start_8
    iget-object v0, v0, Lq3/g;->i:Lq/f;

    .line 153
    .line 154
    invoke-virtual {v0}, Lq/f;->iterator()Ljava/util/Iterator;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    :goto_4
    move-object v3, v0

    .line 159
    check-cast v3, Lq/b;

    .line 160
    .line 161
    invoke-virtual {v3}, Lq/b;->hasNext()Z

    .line 162
    .line 163
    .line 164
    move-result v4

    .line 165
    if-eqz v4, :cond_3

    .line 166
    .line 167
    invoke-virtual {v3}, Lq/b;->next()Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    move-result-object v3

    .line 171
    check-cast v3, Ljava/util/Map$Entry;

    .line 172
    .line 173
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    move-result-object v3

    .line 177
    check-cast v3, Lq3/f;

    .line 178
    .line 179
    invoke-virtual {v3, v2}, Lq3/f;->a(Ljava/util/Set;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 180
    .line 181
    .line 182
    goto :goto_4

    .line 183
    :catchall_2
    move-exception v0

    .line 184
    goto :goto_5

    .line 185
    :cond_3
    monitor-exit v1

    .line 186
    goto :goto_6

    .line 187
    :goto_5
    monitor-exit v1

    .line 188
    throw v0

    .line 189
    :cond_4
    :goto_6
    return-void

    .line 190
    :goto_7
    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    .line 191
    .line 192
    .line 193
    throw v1
.end method

.method private final c()V
    .locals 8

    .line 1
    :cond_0
    :goto_0
    iget-object v0, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lr7/d;

    .line 4
    .line 5
    monitor-enter v0

    .line 6
    :try_start_0
    invoke-virtual {v0}, Lr7/d;->c()Lr7/a;

    .line 7
    .line 8
    .line 9
    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 10
    monitor-exit v0

    .line 11
    if-nez v1, :cond_1

    .line 12
    .line 13
    return-void

    .line 14
    :cond_1
    iget-object v0, v1, Lr7/a;->c:Lr7/c;

    .line 15
    .line 16
    invoke-static {v0}, La7/h;->b(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v2, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v2, Lr7/d;

    .line 22
    .line 23
    sget-object v3, Lr7/d;->j:Ljava/util/logging/Logger;

    .line 24
    .line 25
    sget-object v4, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    .line 26
    .line 27
    invoke-virtual {v3, v4}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_2

    .line 32
    .line 33
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 34
    .line 35
    .line 36
    move-result-wide v4

    .line 37
    const-string v6, "starting"

    .line 38
    .line 39
    invoke-static {v1, v0, v6}, Ll3/e;->b(Lr7/a;Lr7/c;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_2
    const-wide/16 v4, -0x1

    .line 44
    .line 45
    :goto_1
    :try_start_1
    invoke-static {v2, v1}, Lr7/d;->a(Lr7/d;Lr7/a;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 46
    .line 47
    .line 48
    if-eqz v3, :cond_0

    .line 49
    .line 50
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 51
    .line 52
    .line 53
    move-result-wide v2

    .line 54
    sub-long/2addr v2, v4

    .line 55
    invoke-static {v2, v3}, Ll3/e;->t(J)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    const-string v3, "finished run in "

    .line 60
    .line 61
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v2

    .line 65
    invoke-static {v1, v0, v2}, Ll3/e;->b(Lr7/a;Lr7/c;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    goto :goto_0

    .line 69
    :catchall_0
    move-exception v6

    .line 70
    :try_start_2
    iget-object v2, v2, Lr7/d;->a:Ll6/b;

    .line 71
    .line 72
    iget-object v2, v2, Ll6/b;->k:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v2, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 75
    .line 76
    invoke-virtual {v2, p0}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    .line 77
    .line 78
    .line 79
    throw v6
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 80
    :catchall_1
    move-exception v2

    .line 81
    if-eqz v3, :cond_3

    .line 82
    .line 83
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 84
    .line 85
    .line 86
    move-result-wide v6

    .line 87
    sub-long/2addr v6, v4

    .line 88
    invoke-static {v6, v7}, Ll3/e;->t(J)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v3

    .line 92
    const-string v4, "failed a run in "

    .line 93
    .line 94
    invoke-virtual {v4, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 95
    .line 96
    .line 97
    move-result-object v3

    .line 98
    invoke-static {v1, v0, v3}, Ll3/e;->b(Lr7/a;Lr7/c;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    :cond_3
    throw v2

    .line 102
    :catchall_2
    move-exception v1

    .line 103
    monitor-exit v0

    .line 104
    throw v1
.end method


# virtual methods
.method public a()Lp6/i;
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lq3/g;

    .line 4
    .line 5
    new-instance v1, Lp6/i;

    .line 6
    .line 7
    invoke-direct {v1}, Lp6/i;-><init>()V

    .line 8
    .line 9
    .line 10
    iget-object v0, v0, Lq3/g;->a:Landroidx/work/impl/WorkDatabase_Impl;

    .line 11
    .line 12
    new-instance v2, Lk3/f1;

    .line 13
    .line 14
    const-string v3, "SELECT * FROM room_table_modification_log WHERE invalidated = 1;"

    .line 15
    .line 16
    const/4 v4, 0x7

    .line 17
    invoke-direct {v2, v3, v4}, Lk3/f1;-><init>(Ljava/lang/String;I)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v0, v2}, Landroidx/work/impl/WorkDatabase;->m(Lv3/e;)Landroid/database/Cursor;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    :goto_0
    :try_start_0
    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_0

    .line 29
    .line 30
    const/4 v2, 0x0

    .line 31
    invoke-interface {v0, v2}, Landroid/database/Cursor;->getInt(I)I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    invoke-virtual {v1, v2}, Lp6/i;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 40
    .line 41
    .line 42
    goto :goto_0

    .line 43
    :catchall_0
    move-exception v1

    .line 44
    goto :goto_1

    .line 45
    :cond_0
    invoke-interface {v0}, Ljava/io/Closeable;->close()V

    .line 46
    .line 47
    .line 48
    invoke-static {v1}, Ll3/e;->g(Lp6/i;)Lp6/i;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    iget-object v1, v0, Lp6/i;->k:Lp6/f;

    .line 53
    .line 54
    invoke-virtual {v1}, Lp6/f;->isEmpty()Z

    .line 55
    .line 56
    .line 57
    move-result v1

    .line 58
    if-nez v1, :cond_3

    .line 59
    .line 60
    iget-object v1, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 61
    .line 62
    check-cast v1, Lq3/g;

    .line 63
    .line 64
    iget-object v1, v1, Lq3/g;->g:Lw3/i;

    .line 65
    .line 66
    const-string v2, "Required value was null."

    .line 67
    .line 68
    if-eqz v1, :cond_2

    .line 69
    .line 70
    iget-object v1, p0, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v1, Lq3/g;

    .line 73
    .line 74
    iget-object v1, v1, Lq3/g;->g:Lw3/i;

    .line 75
    .line 76
    if-eqz v1, :cond_1

    .line 77
    .line 78
    invoke-virtual {v1}, Lw3/i;->a()I

    .line 79
    .line 80
    .line 81
    return-object v0

    .line 82
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 83
    .line 84
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    throw v0

    .line 88
    :cond_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 89
    .line 90
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    throw v0

    .line 94
    :cond_3
    return-object v0

    .line 95
    :goto_1
    :try_start_1
    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 96
    :catchall_1
    move-exception v2

    .line 97
    invoke-static {v0, v1}, Ll3/e;->n(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 98
    .line 99
    .line 100
    throw v2
.end method

.method public final run()V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Landroidx/lifecycle/w;->k:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lv1/k;

    .line 13
    .line 14
    invoke-interface {v0}, Lv1/k;->d()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, Ll4/t;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    :goto_0
    :try_start_0
    iget-object v2, v0, Ll4/t;->m:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v2, Ljava/lang/ref/ReferenceQueue;

    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/ref/ReferenceQueue;->remove()Ljava/lang/ref/Reference;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    check-cast v2, Lu4/a;

    .line 34
    .line 35
    invoke-virtual {v0, v2}, Ll4/t;->q(Lu4/a;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :catch_0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    .line 44
    .line 45
    .line 46
    goto :goto_0

    .line 47
    :pswitch_1
    const/16 v0, 0xa

    .line 48
    .line 49
    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V

    .line 50
    .line 51
    .line 52
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v0, Ljava/lang/Runnable;

    .line 55
    .line 56
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :pswitch_2
    invoke-direct {v1}, Landroidx/lifecycle/w;->c()V

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :pswitch_3
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v0, Lr0/o;

    .line 67
    .line 68
    invoke-virtual {v0, v3}, Lr0/o;->e(Z)Z

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :pswitch_4
    invoke-direct {v1}, Landroidx/lifecycle/w;->b()V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :pswitch_5
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v0, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;

    .line 79
    .line 80
    invoke-virtual {v0}, Landroidx/recyclerview/widget/StaggeredGridLayoutManager;->u0()Z

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :pswitch_6
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v0, Lp3/s;

    .line 87
    .line 88
    iget-object v4, v0, Lp3/s;->z:Landroid/animation/ValueAnimator;

    .line 89
    .line 90
    iget v5, v0, Lp3/s;->A:I

    .line 91
    .line 92
    const/4 v6, 0x2

    .line 93
    if-eq v5, v3, :cond_0

    .line 94
    .line 95
    if-eq v5, v6, :cond_1

    .line 96
    .line 97
    goto :goto_1

    .line 98
    :cond_0
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->cancel()V

    .line 99
    .line 100
    .line 101
    :cond_1
    const/4 v5, 0x3

    .line 102
    iput v5, v0, Lp3/s;->A:I

    .line 103
    .line 104
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    check-cast v0, Ljava/lang/Float;

    .line 109
    .line 110
    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    new-array v5, v6, [F

    .line 115
    .line 116
    aput v0, v5, v2

    .line 117
    .line 118
    const/4 v0, 0x0

    .line 119
    aput v0, v5, v3

    .line 120
    .line 121
    invoke-virtual {v4, v5}, Landroid/animation/ValueAnimator;->setFloatValues([F)V

    .line 122
    .line 123
    .line 124
    const/16 v0, 0x1f4

    .line 125
    .line 126
    int-to-long v2, v0

    .line 127
    invoke-virtual {v4, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    .line 128
    .line 129
    .line 130
    invoke-virtual {v4}, Landroid/animation/ValueAnimator;->start()V

    .line 131
    .line 132
    .line 133
    :goto_1
    return-void

    .line 134
    :pswitch_7
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 135
    .line 136
    check-cast v0, Landroidx/appcompat/widget/Toolbar;

    .line 137
    .line 138
    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->k:Landroidx/appcompat/widget/ActionMenuView;

    .line 139
    .line 140
    if-eqz v0, :cond_2

    .line 141
    .line 142
    iget-object v0, v0, Landroidx/appcompat/widget/ActionMenuView;->D:Lo/k;

    .line 143
    .line 144
    if-eqz v0, :cond_2

    .line 145
    .line 146
    invoke-virtual {v0}, Lo/k;->l()Z

    .line 147
    .line 148
    .line 149
    :cond_2
    return-void

    .line 150
    :pswitch_8
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    .line 153
    .line 154
    iget-boolean v3, v0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->p:Z

    .line 155
    .line 156
    if-eqz v3, :cond_3

    .line 157
    .line 158
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 159
    .line 160
    .line 161
    move-result-object v3

    .line 162
    const-string v4, "input_method"

    .line 163
    .line 164
    invoke-virtual {v3, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v3

    .line 168
    check-cast v3, Landroid/view/inputmethod/InputMethodManager;

    .line 169
    .line 170
    invoke-virtual {v3, v0, v2}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    .line 171
    .line 172
    .line 173
    iput-boolean v2, v0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->p:Z

    .line 174
    .line 175
    :cond_3
    return-void

    .line 176
    :pswitch_9
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v0, Lo/s1;

    .line 179
    .line 180
    const/4 v2, 0x0

    .line 181
    iput-object v2, v0, Lo/s1;->v:Landroidx/lifecycle/w;

    .line 182
    .line 183
    invoke-virtual {v0}, Lo/s1;->drawableStateChanged()V

    .line 184
    .line 185
    .line 186
    return-void

    .line 187
    :pswitch_a
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 188
    .line 189
    check-cast v0, Lk/e;

    .line 190
    .line 191
    invoke-virtual {v0, v3}, Lk/e;->a(Z)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 195
    .line 196
    .line 197
    return-void

    .line 198
    :pswitch_b
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 199
    .line 200
    check-cast v0, Lj0/g;

    .line 201
    .line 202
    iget-object v3, v0, Lj0/g;->m:Lo/s1;

    .line 203
    .line 204
    iget-object v4, v0, Lj0/g;->k:Lj0/a;

    .line 205
    .line 206
    iget-boolean v5, v0, Lj0/g;->y:Z

    .line 207
    .line 208
    if-nez v5, :cond_4

    .line 209
    .line 210
    goto/16 :goto_3

    .line 211
    .line 212
    :cond_4
    iget-boolean v5, v0, Lj0/g;->w:Z

    .line 213
    .line 214
    if-eqz v5, :cond_5

    .line 215
    .line 216
    iput-boolean v2, v0, Lj0/g;->w:Z

    .line 217
    .line 218
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 219
    .line 220
    .line 221
    move-result-wide v5

    .line 222
    iput-wide v5, v4, Lj0/a;->e:J

    .line 223
    .line 224
    const-wide/16 v7, -0x1

    .line 225
    .line 226
    iput-wide v7, v4, Lj0/a;->g:J

    .line 227
    .line 228
    iput-wide v5, v4, Lj0/a;->f:J

    .line 229
    .line 230
    const/high16 v5, 0x3f000000    # 0.5f

    .line 231
    .line 232
    iput v5, v4, Lj0/a;->h:F

    .line 233
    .line 234
    :cond_5
    iget-wide v5, v4, Lj0/a;->g:J

    .line 235
    .line 236
    const-wide/16 v7, 0x0

    .line 237
    .line 238
    cmp-long v5, v5, v7

    .line 239
    .line 240
    if-lez v5, :cond_6

    .line 241
    .line 242
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 243
    .line 244
    .line 245
    move-result-wide v5

    .line 246
    iget-wide v9, v4, Lj0/a;->g:J

    .line 247
    .line 248
    iget v11, v4, Lj0/a;->i:I

    .line 249
    .line 250
    int-to-long v11, v11

    .line 251
    add-long/2addr v9, v11

    .line 252
    cmp-long v5, v5, v9

    .line 253
    .line 254
    if-lez v5, :cond_6

    .line 255
    .line 256
    goto :goto_2

    .line 257
    :cond_6
    invoke-virtual {v0}, Lj0/g;->e()Z

    .line 258
    .line 259
    .line 260
    move-result v5

    .line 261
    if-nez v5, :cond_7

    .line 262
    .line 263
    :goto_2
    iput-boolean v2, v0, Lj0/g;->y:Z

    .line 264
    .line 265
    goto :goto_3

    .line 266
    :cond_7
    iget-boolean v5, v0, Lj0/g;->x:Z

    .line 267
    .line 268
    if-eqz v5, :cond_8

    .line 269
    .line 270
    iput-boolean v2, v0, Lj0/g;->x:Z

    .line 271
    .line 272
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 273
    .line 274
    .line 275
    move-result-wide v9

    .line 276
    const/4 v15, 0x0

    .line 277
    const/16 v16, 0x0

    .line 278
    .line 279
    const/4 v13, 0x3

    .line 280
    const/4 v14, 0x0

    .line 281
    move-wide v11, v9

    .line 282
    invoke-static/range {v9 .. v16}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 283
    .line 284
    .line 285
    move-result-object v2

    .line 286
    invoke-virtual {v3, v2}, Lo/s1;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 287
    .line 288
    .line 289
    invoke-virtual {v2}, Landroid/view/MotionEvent;->recycle()V

    .line 290
    .line 291
    .line 292
    :cond_8
    iget-wide v5, v4, Lj0/a;->f:J

    .line 293
    .line 294
    cmp-long v2, v5, v7

    .line 295
    .line 296
    if-eqz v2, :cond_9

    .line 297
    .line 298
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    .line 299
    .line 300
    .line 301
    move-result-wide v5

    .line 302
    invoke-virtual {v4, v5, v6}, Lj0/a;->a(J)F

    .line 303
    .line 304
    .line 305
    move-result v2

    .line 306
    const/high16 v7, -0x3f800000    # -4.0f

    .line 307
    .line 308
    mul-float/2addr v7, v2

    .line 309
    mul-float/2addr v7, v2

    .line 310
    const/high16 v8, 0x40800000    # 4.0f

    .line 311
    .line 312
    mul-float/2addr v2, v8

    .line 313
    add-float/2addr v2, v7

    .line 314
    iget-wide v7, v4, Lj0/a;->f:J

    .line 315
    .line 316
    sub-long v7, v5, v7

    .line 317
    .line 318
    iput-wide v5, v4, Lj0/a;->f:J

    .line 319
    .line 320
    long-to-float v5, v7

    .line 321
    mul-float/2addr v5, v2

    .line 322
    iget v2, v4, Lj0/a;->d:F

    .line 323
    .line 324
    mul-float/2addr v5, v2

    .line 325
    float-to-int v2, v5

    .line 326
    iget-object v0, v0, Lj0/g;->A:Lo/s1;

    .line 327
    .line 328
    invoke-virtual {v0, v2}, Landroid/widget/AbsListView;->scrollListBy(I)V

    .line 329
    .line 330
    .line 331
    sget-object v0, Le0/k0;->a:Ljava/util/WeakHashMap;

    .line 332
    .line 333
    invoke-virtual {v3, v1}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 334
    .line 335
    .line 336
    :goto_3
    return-void

    .line 337
    :cond_9
    new-instance v0, Ljava/lang/RuntimeException;

    .line 338
    .line 339
    const-string v2, "Cannot compute scroll delta before calling start()"

    .line 340
    .line 341
    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 342
    .line 343
    .line 344
    throw v0

    .line 345
    :pswitch_c
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 346
    .line 347
    check-cast v0, Lcom/bumptech/glide/m;

    .line 348
    .line 349
    iget-object v2, v0, Lcom/bumptech/glide/m;->m:Lh5/g;

    .line 350
    .line 351
    invoke-interface {v2, v0}, Lh5/g;->e(Lh5/i;)V

    .line 352
    .line 353
    .line 354
    return-void

    .line 355
    :pswitch_d
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 356
    .line 357
    move-object v2, v0

    .line 358
    check-cast v2, Landroidx/work/Worker;

    .line 359
    .line 360
    :try_start_1
    invoke-virtual {v2}, Landroidx/work/Worker;->f()Lc4/n;

    .line 361
    .line 362
    .line 363
    move-result-object v0

    .line 364
    iget-object v3, v2, Landroidx/work/Worker;->o:Ln4/k;

    .line 365
    .line 366
    invoke-virtual {v3, v0}, Ln4/k;->i(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 367
    .line 368
    .line 369
    goto :goto_4

    .line 370
    :catchall_0
    move-exception v0

    .line 371
    iget-object v2, v2, Landroidx/work/Worker;->o:Ln4/k;

    .line 372
    .line 373
    invoke-virtual {v2, v0}, Ln4/k;->j(Ljava/lang/Throwable;)Z

    .line 374
    .line 375
    .line 376
    :goto_4
    return-void

    .line 377
    :pswitch_e
    :try_start_2
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 378
    .line 379
    check-cast v0, Li/k;

    .line 380
    .line 381
    invoke-static {v0}, Lc/k;->d(Li/k;)V
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_1

    .line 382
    .line 383
    .line 384
    goto :goto_5

    .line 385
    :catch_1
    move-exception v0

    .line 386
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 387
    .line 388
    .line 389
    move-result-object v2

    .line 390
    const-string v3, "Can not perform this action after onSaveInstanceState"

    .line 391
    .line 392
    invoke-static {v2, v3}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 393
    .line 394
    .line 395
    move-result v2

    .line 396
    if-eqz v2, :cond_a

    .line 397
    .line 398
    :goto_5
    return-void

    .line 399
    :cond_a
    throw v0

    .line 400
    :pswitch_f
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 401
    .line 402
    check-cast v0, Lu4/k;

    .line 403
    .line 404
    iget-object v0, v0, Lu4/k;->l:Ljava/lang/Object;

    .line 405
    .line 406
    return-void

    .line 407
    :pswitch_10
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 408
    .line 409
    check-cast v0, Landroidx/lifecycle/x;

    .line 410
    .line 411
    iget-object v4, v0, Landroidx/lifecycle/x;->a:Ljava/lang/Object;

    .line 412
    .line 413
    monitor-enter v4

    .line 414
    :try_start_3
    iget-object v0, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 415
    .line 416
    check-cast v0, Landroidx/lifecycle/x;

    .line 417
    .line 418
    iget-object v0, v0, Landroidx/lifecycle/x;->d:Ljava/lang/Object;

    .line 419
    .line 420
    iget-object v5, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 421
    .line 422
    check-cast v5, Landroidx/lifecycle/x;

    .line 423
    .line 424
    sget-object v6, Landroidx/lifecycle/x;->h:Ljava/lang/Object;

    .line 425
    .line 426
    iput-object v6, v5, Landroidx/lifecycle/x;->d:Ljava/lang/Object;

    .line 427
    .line 428
    monitor-exit v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 429
    iget-object v4, v1, Landroidx/lifecycle/w;->l:Ljava/lang/Object;

    .line 430
    .line 431
    check-cast v4, Landroidx/lifecycle/x;

    .line 432
    .line 433
    invoke-static {}, Lp/a;->I()Lp/a;

    .line 434
    .line 435
    .line 436
    move-result-object v5

    .line 437
    iget-object v5, v5, Lp/a;->e:Lp/c;

    .line 438
    .line 439
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 440
    .line 441
    .line 442
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 443
    .line 444
    .line 445
    move-result-object v5

    .line 446
    invoke-virtual {v5}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 447
    .line 448
    .line 449
    move-result-object v5

    .line 450
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 451
    .line 452
    .line 453
    move-result-object v6

    .line 454
    if-ne v5, v6, :cond_e

    .line 455
    .line 456
    iput-object v0, v4, Landroidx/lifecycle/x;->c:Ljava/lang/Object;

    .line 457
    .line 458
    iget-boolean v0, v4, Landroidx/lifecycle/x;->e:Z

    .line 459
    .line 460
    if-eqz v0, :cond_b

    .line 461
    .line 462
    iput-boolean v3, v4, Landroidx/lifecycle/x;->f:Z

    .line 463
    .line 464
    goto :goto_6

    .line 465
    :cond_b
    iput-boolean v3, v4, Landroidx/lifecycle/x;->e:Z

    .line 466
    .line 467
    :cond_c
    iput-boolean v2, v4, Landroidx/lifecycle/x;->f:Z

    .line 468
    .line 469
    iget-object v0, v4, Landroidx/lifecycle/x;->b:Lq/f;

    .line 470
    .line 471
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 472
    .line 473
    .line 474
    new-instance v3, Lq/d;

    .line 475
    .line 476
    invoke-direct {v3, v0}, Lq/d;-><init>(Lq/f;)V

    .line 477
    .line 478
    .line 479
    iget-object v0, v0, Lq/f;->m:Ljava/util/WeakHashMap;

    .line 480
    .line 481
    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 482
    .line 483
    invoke-virtual {v0, v3, v5}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 484
    .line 485
    .line 486
    invoke-virtual {v3}, Lq/d;->hasNext()Z

    .line 487
    .line 488
    .line 489
    move-result v0

    .line 490
    if-nez v0, :cond_d

    .line 491
    .line 492
    iget-boolean v0, v4, Landroidx/lifecycle/x;->f:Z

    .line 493
    .line 494
    if-nez v0, :cond_c

    .line 495
    .line 496
    iput-boolean v2, v4, Landroidx/lifecycle/x;->e:Z

    .line 497
    .line 498
    :goto_6
    return-void

    .line 499
    :cond_d
    invoke-virtual {v3}, Lq/d;->next()Ljava/lang/Object;

    .line 500
    .line 501
    .line 502
    move-result-object v0

    .line 503
    check-cast v0, Ljava/util/Map$Entry;

    .line 504
    .line 505
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 506
    .line 507
    .line 508
    move-result-object v0

    .line 509
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 510
    .line 511
    .line 512
    new-instance v0, Ljava/lang/ClassCastException;

    .line 513
    .line 514
    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    .line 515
    .line 516
    .line 517
    throw v0

    .line 518
    :cond_e
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 519
    .line 520
    const-string v2, "Cannot invoke setValue on a background thread"

    .line 521
    .line 522
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 523
    .line 524
    .line 525
    throw v0

    .line 526
    :catchall_1
    move-exception v0

    .line 527
    :try_start_4
    monitor-exit v4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 528
    throw v0

    .line 529
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
