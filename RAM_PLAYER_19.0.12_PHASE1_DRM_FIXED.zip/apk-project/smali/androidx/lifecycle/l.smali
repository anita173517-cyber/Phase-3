.class public final Landroidx/lifecycle/l;
.super Lt6/h;
.source "SourceFile"

# interfaces
.implements Lz6/p;


# instance fields
.field public final synthetic o:I

.field public synthetic p:Ljava/lang/Object;

.field public final synthetic q:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Lr6/d;I)V
    .locals 0

    .line 1
    iput p4, p0, Landroidx/lifecycle/l;->o:I

    iput-object p1, p0, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/lifecycle/l;->q:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lt6/h;-><init>(ILr6/d;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Lr6/d;I)V
    .locals 0

    .line 2
    iput p3, p0, Landroidx/lifecycle/l;->o:I

    iput-object p1, p0, Landroidx/lifecycle/l;->q:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lt6/h;-><init>(ILr6/d;)V

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Landroidx/lifecycle/l;->o:I

    .line 2
    .line 3
    check-cast p1, Lf7/s;

    .line 4
    .line 5
    check-cast p2, Lr6/d;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/l;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Landroidx/lifecycle/l;

    .line 15
    .line 16
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, Landroidx/lifecycle/l;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    return-object p1

    .line 23
    :pswitch_0
    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/l;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, Landroidx/lifecycle/l;

    .line 28
    .line 29
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 30
    .line 31
    invoke-virtual {p1, p2}, Landroidx/lifecycle/l;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    return-object p1

    .line 36
    :pswitch_1
    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/l;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, Landroidx/lifecycle/l;

    .line 41
    .line 42
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 43
    .line 44
    invoke-virtual {p1, p2}, Landroidx/lifecycle/l;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    return-object p2

    .line 48
    :pswitch_2
    invoke-virtual {p0, p1, p2}, Landroidx/lifecycle/l;->g(Ljava/lang/Object;Lr6/d;)Lr6/d;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    check-cast p1, Landroidx/lifecycle/l;

    .line 53
    .line 54
    sget-object p2, Ln6/j;->a:Ln6/j;

    .line 55
    .line 56
    invoke-virtual {p1, p2}, Landroidx/lifecycle/l;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    return-object p2

    .line 60
    nop

    .line 61
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final g(Ljava/lang/Object;Lr6/d;)Lr6/d;
    .locals 3

    .line 1
    iget v0, p0, Landroidx/lifecycle/l;->o:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, Landroidx/lifecycle/l;

    .line 7
    .line 8
    iget-object v1, p0, Landroidx/lifecycle/l;->q:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lcom/harindra/iptvpro/PlayerActivity;

    .line 11
    .line 12
    const/4 v2, 0x3

    .line 13
    invoke-direct {v0, v1, p2, v2}, Landroidx/lifecycle/l;-><init>(Ljava/lang/Object;Lr6/d;I)V

    .line 14
    .line 15
    .line 16
    iput-object p1, v0, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    .line 17
    .line 18
    return-object v0

    .line 19
    :pswitch_0
    new-instance p1, Landroidx/lifecycle/l;

    .line 20
    .line 21
    iget-object v0, p0, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lcom/harindra/iptvpro/PlayerActivity;

    .line 24
    .line 25
    iget-object v1, p0, Landroidx/lifecycle/l;->q:Ljava/lang/Object;

    .line 26
    .line 27
    check-cast v1, Ljava/util/Set;

    .line 28
    .line 29
    const/4 v2, 0x2

    .line 30
    invoke-direct {p1, v0, v1, p2, v2}, Landroidx/lifecycle/l;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Lr6/d;I)V

    .line 31
    .line 32
    .line 33
    return-object p1

    .line 34
    :pswitch_1
    new-instance p1, Landroidx/lifecycle/l;

    .line 35
    .line 36
    iget-object v0, p0, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v0, Lcom/harindra/iptvpro/PlayerActivity;

    .line 39
    .line 40
    iget-object v1, p0, Landroidx/lifecycle/l;->q:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast v1, Ljava/lang/String;

    .line 43
    .line 44
    const/4 v2, 0x1

    .line 45
    invoke-direct {p1, v0, v1, p2, v2}, Landroidx/lifecycle/l;-><init>(Lcom/harindra/iptvpro/PlayerActivity;Ljava/lang/Object;Lr6/d;I)V

    .line 46
    .line 47
    .line 48
    return-object p1

    .line 49
    :pswitch_2
    new-instance v0, Landroidx/lifecycle/l;

    .line 50
    .line 51
    iget-object v1, p0, Landroidx/lifecycle/l;->q:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v1, Landroidx/lifecycle/m;

    .line 54
    .line 55
    const/4 v2, 0x0

    .line 56
    invoke-direct {v0, v1, p2, v2}, Landroidx/lifecycle/l;-><init>(Ljava/lang/Object;Lr6/d;I)V

    .line 57
    .line 58
    .line 59
    iput-object p1, v0, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    .line 60
    .line 61
    return-object v0

    .line 62
    nop

    .line 63
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 26

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Landroidx/lifecycle/l;->o:I

    .line 4
    .line 5
    sget-object v2, Ln6/j;->a:Ln6/j;

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    iget-object v4, v1, Landroidx/lifecycle/l;->q:Ljava/lang/Object;

    .line 9
    .line 10
    packed-switch v0, :pswitch_data_0

    .line 11
    .line 12
    .line 13
    iget-object v0, v1, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Lf7/s;

    .line 16
    .line 17
    invoke-static/range {p1 .. p1}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    check-cast v4, Lcom/harindra/iptvpro/PlayerActivity;

    .line 21
    .line 22
    :try_start_0
    invoke-static {v4}, Lm6/g0;->b(Landroid/content/Context;)Lm6/e0;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v0}, Lm6/g0;->a(Lm6/e0;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 30
    goto :goto_0

    .line 31
    :catchall_0
    move-exception v0

    .line 32
    invoke-static {v0}, Lw7/d;->g(Ljava/lang/Throwable;)Ln6/e;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    :goto_0
    invoke-static {v0}, Ln6/f;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 37
    .line 38
    .line 39
    move-result-object v2

    .line 40
    if-nez v2, :cond_0

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_0
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    const-string v2, "Hardware probe failed: "

    .line 52
    .line 53
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    :goto_1
    return-object v0

    .line 58
    :pswitch_0
    invoke-static/range {p1 .. p1}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    iget-object v0, v1, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v0, Lcom/harindra/iptvpro/PlayerActivity;

    .line 64
    .line 65
    iget-object v2, v0, Lcom/harindra/iptvpro/PlayerActivity;->T2:Ljava/util/List;

    .line 66
    .line 67
    iget-object v5, v0, Lcom/harindra/iptvpro/PlayerActivity;->w1:Ljava/lang/Object;

    .line 68
    .line 69
    iget-object v0, v0, Lcom/harindra/iptvpro/PlayerActivity;->y1:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v4, Ljava/util/Set;

    .line 72
    .line 73
    const-string v6, "liveChannels"

    .line 74
    .line 75
    invoke-static {v2, v6}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    const-string v6, "vodMovies"

    .line 79
    .line 80
    invoke-static {v5, v6}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    const-string v6, "seriesGroups"

    .line 84
    .line 85
    invoke-static {v0, v6}, La7/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    new-instance v6, Ljava/util/LinkedHashMap;

    .line 89
    .line 90
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 91
    .line 92
    .line 93
    move-result v7

    .line 94
    const/16 v8, 0x1000

    .line 95
    .line 96
    if-le v7, v8, :cond_1

    .line 97
    .line 98
    move v7, v8

    .line 99
    :cond_1
    invoke-direct {v6, v7}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 100
    .line 101
    .line 102
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 103
    .line 104
    .line 105
    move-result v7

    .line 106
    const/4 v8, 0x0

    .line 107
    move v9, v8

    .line 108
    move v14, v9

    .line 109
    move v15, v14

    .line 110
    move/from16 v17, v15

    .line 111
    .line 112
    :goto_2
    if-ge v9, v7, :cond_7

    .line 113
    .line 114
    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v10

    .line 118
    check-cast v10, Lm6/n;

    .line 119
    .line 120
    iget-object v11, v10, Lm6/n;->h:Ljava/lang/String;

    .line 121
    .line 122
    invoke-static {v11}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 123
    .line 124
    .line 125
    move-result v11

    .line 126
    if-nez v11, :cond_2

    .line 127
    .line 128
    add-int/lit8 v14, v14, 0x1

    .line 129
    .line 130
    :cond_2
    iget-object v11, v10, Lm6/n;->f:Ljava/lang/String;

    .line 131
    .line 132
    invoke-static {v11}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 133
    .line 134
    .line 135
    move-result v11

    .line 136
    if-nez v11, :cond_3

    .line 137
    .line 138
    add-int/lit8 v15, v15, 0x1

    .line 139
    .line 140
    :cond_3
    iget-object v11, v10, Lm6/n;->g:Ljava/lang/String;

    .line 141
    .line 142
    invoke-static {v11}, Le7/e;->Y(Ljava/lang/CharSequence;)Z

    .line 143
    .line 144
    .line 145
    move-result v11

    .line 146
    if-nez v11, :cond_4

    .line 147
    .line 148
    add-int/lit8 v17, v17, 0x1

    .line 149
    .line 150
    :cond_4
    iget-object v10, v10, Lm6/n;->c:Ljava/lang/String;

    .line 151
    .line 152
    invoke-static {v10}, Lm6/c;->p(Ljava/lang/String;)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v10

    .line 156
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 157
    .line 158
    .line 159
    move-result v11

    .line 160
    const/4 v12, 0x3

    .line 161
    if-lt v11, v12, :cond_6

    .line 162
    .line 163
    invoke-virtual {v6, v10}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v11

    .line 167
    if-nez v11, :cond_5

    .line 168
    .line 169
    new-instance v11, Ljava/util/ArrayList;

    .line 170
    .line 171
    const/4 v12, 0x2

    .line 172
    invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 173
    .line 174
    .line 175
    invoke-interface {v6, v10, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 176
    .line 177
    .line 178
    :cond_5
    check-cast v11, Ljava/util/ArrayList;

    .line 179
    .line 180
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 181
    .line 182
    .line 183
    move-result-object v10

    .line 184
    invoke-virtual {v11, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 185
    .line 186
    .line 187
    :cond_6
    add-int/lit8 v9, v9, 0x1

    .line 188
    .line 189
    goto :goto_2

    .line 190
    :cond_7
    new-instance v7, Ljava/util/ArrayList;

    .line 191
    .line 192
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 193
    .line 194
    .line 195
    invoke-virtual {v6}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 196
    .line 197
    .line 198
    move-result-object v6

    .line 199
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 200
    .line 201
    .line 202
    move-result-object v6

    .line 203
    :cond_8
    :goto_3
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 204
    .line 205
    .line 206
    move-result v9

    .line 207
    if-eqz v9, :cond_d

    .line 208
    .line 209
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object v9

    .line 213
    check-cast v9, Ljava/util/Map$Entry;

    .line 214
    .line 215
    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v10

    .line 219
    move-object/from16 v19, v10

    .line 220
    .line 221
    check-cast v19, Ljava/lang/String;

    .line 222
    .line 223
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v9

    .line 227
    check-cast v9, Ljava/util/ArrayList;

    .line 228
    .line 229
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 230
    .line 231
    .line 232
    move-result v10

    .line 233
    if-le v10, v3, :cond_8

    .line 234
    .line 235
    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v10

    .line 239
    const-string v11, "get(...)"

    .line 240
    .line 241
    invoke-static {v10, v11}, La7/h;->d(Ljava/lang/Object;Ljava/lang/String;)V

    .line 242
    .line 243
    .line 244
    check-cast v10, Ljava/lang/Number;

    .line 245
    .line 246
    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    .line 247
    .line 248
    .line 249
    move-result v10

    .line 250
    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v10

    .line 254
    check-cast v10, Lm6/n;

    .line 255
    .line 256
    new-instance v11, Ljava/util/ArrayList;

    .line 257
    .line 258
    const/16 v12, 0xa

    .line 259
    .line 260
    invoke-static {v9, v12}, Lo6/l;->O(Ljava/lang/Iterable;I)I

    .line 261
    .line 262
    .line 263
    move-result v13

    .line 264
    invoke-direct {v11, v13}, Ljava/util/ArrayList;-><init>(I)V

    .line 265
    .line 266
    .line 267
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 268
    .line 269
    .line 270
    move-result v13

    .line 271
    :goto_4
    if-ge v8, v13, :cond_9

    .line 272
    .line 273
    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object v16

    .line 277
    add-int/lit8 v8, v8, 0x1

    .line 278
    .line 279
    check-cast v16, Ljava/lang/Number;

    .line 280
    .line 281
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->intValue()I

    .line 282
    .line 283
    .line 284
    move-result v3

    .line 285
    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 286
    .line 287
    .line 288
    move-result-object v3

    .line 289
    check-cast v3, Lm6/n;

    .line 290
    .line 291
    iget-object v3, v3, Lm6/n;->e:Ljava/lang/String;

    .line 292
    .line 293
    invoke-virtual {v11, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 294
    .line 295
    .line 296
    const/4 v3, 0x1

    .line 297
    goto :goto_4

    .line 298
    :cond_9
    invoke-static {v11}, Lo6/j;->n0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 299
    .line 300
    .line 301
    move-result-object v3

    .line 302
    iget-object v8, v10, Lm6/n;->c:Ljava/lang/String;

    .line 303
    .line 304
    iget-object v10, v10, Lm6/n;->d:Ljava/lang/String;

    .line 305
    .line 306
    new-instance v11, Ljava/util/ArrayList;

    .line 307
    .line 308
    invoke-static {v9, v12}, Lo6/l;->O(Ljava/lang/Iterable;I)I

    .line 309
    .line 310
    .line 311
    move-result v12

    .line 312
    invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 316
    .line 317
    .line 318
    move-result v12

    .line 319
    const/4 v13, 0x0

    .line 320
    :goto_5
    if-ge v13, v12, :cond_a

    .line 321
    .line 322
    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 323
    .line 324
    .line 325
    move-result-object v16

    .line 326
    add-int/lit8 v13, v13, 0x1

    .line 327
    .line 328
    check-cast v16, Ljava/lang/Number;

    .line 329
    .line 330
    move-object/from16 v25, v0

    .line 331
    .line 332
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->intValue()I

    .line 333
    .line 334
    .line 335
    move-result v0

    .line 336
    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 337
    .line 338
    .line 339
    move-result-object v0

    .line 340
    check-cast v0, Lm6/n;

    .line 341
    .line 342
    iget-object v0, v0, Lm6/n;->a:Ljava/lang/String;

    .line 343
    .line 344
    invoke-virtual {v11, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 345
    .line 346
    .line 347
    move-object/from16 v0, v25

    .line 348
    .line 349
    goto :goto_5

    .line 350
    :cond_a
    move-object/from16 v25, v0

    .line 351
    .line 352
    invoke-interface {v3}, Ljava/util/Set;->size()I

    .line 353
    .line 354
    .line 355
    move-result v0

    .line 356
    const/4 v3, 0x1

    .line 357
    if-le v0, v3, :cond_b

    .line 358
    .line 359
    const/16 v24, 0x1

    .line 360
    .line 361
    goto :goto_6

    .line 362
    :cond_b
    const/16 v24, 0x0

    .line 363
    .line 364
    :goto_6
    new-instance v18, Lm6/x5;

    .line 365
    .line 366
    move-object/from16 v20, v8

    .line 367
    .line 368
    move-object/from16 v22, v9

    .line 369
    .line 370
    move-object/from16 v21, v10

    .line 371
    .line 372
    move-object/from16 v23, v11

    .line 373
    .line 374
    invoke-direct/range {v18 .. v24}, Lm6/x5;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/util/ArrayList;Z)V

    .line 375
    .line 376
    .line 377
    move-object/from16 v0, v18

    .line 378
    .line 379
    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 380
    .line 381
    .line 382
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 383
    .line 384
    .line 385
    move-result v0

    .line 386
    const/16 v3, 0x50

    .line 387
    .line 388
    if-lt v0, v3, :cond_c

    .line 389
    .line 390
    goto :goto_7

    .line 391
    :cond_c
    move-object/from16 v0, v25

    .line 392
    .line 393
    const/4 v3, 0x1

    .line 394
    const/4 v8, 0x0

    .line 395
    goto/16 :goto_3

    .line 396
    .line 397
    :cond_d
    move-object/from16 v25, v0

    .line 398
    .line 399
    :goto_7
    new-instance v10, Lm6/y5;

    .line 400
    .line 401
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 402
    .line 403
    .line 404
    move-result v11

    .line 405
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 406
    .line 407
    .line 408
    move-result v12

    .line 409
    invoke-interface/range {v25 .. v25}, Ljava/util/List;->size()I

    .line 410
    .line 411
    .line 412
    move-result v13

    .line 413
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 414
    .line 415
    .line 416
    move-result v0

    .line 417
    sub-int/2addr v0, v15

    .line 418
    if-gez v0, :cond_e

    .line 419
    .line 420
    const/16 v16, 0x0

    .line 421
    .line 422
    goto :goto_8

    .line 423
    :cond_e
    move/from16 v16, v0

    .line 424
    .line 425
    :goto_8
    invoke-interface {v4}, Ljava/util/Set;->size()I

    .line 426
    .line 427
    .line 428
    move-result v18

    .line 429
    move-object/from16 v19, v7

    .line 430
    .line 431
    invoke-direct/range {v10 .. v19}, Lm6/y5;-><init>(IIIIIIIILjava/util/ArrayList;)V

    .line 432
    .line 433
    .line 434
    return-object v10

    .line 435
    :pswitch_1
    invoke-static/range {p1 .. p1}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 436
    .line 437
    .line 438
    iget-object v0, v1, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    .line 439
    .line 440
    check-cast v0, Lcom/harindra/iptvpro/PlayerActivity;

    .line 441
    .line 442
    check-cast v4, Ljava/lang/String;

    .line 443
    .line 444
    const/4 v3, 0x1

    .line 445
    invoke-static {v0, v4, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 446
    .line 447
    .line 448
    move-result-object v0

    .line 449
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 450
    .line 451
    .line 452
    return-object v2

    .line 453
    :pswitch_2
    invoke-static/range {p1 .. p1}, Lw7/d;->E(Ljava/lang/Object;)V

    .line 454
    .line 455
    .line 456
    iget-object v0, v1, Landroidx/lifecycle/l;->p:Ljava/lang/Object;

    .line 457
    .line 458
    check-cast v0, Lf7/s;

    .line 459
    .line 460
    check-cast v4, Landroidx/lifecycle/m;

    .line 461
    .line 462
    iget-object v3, v4, Landroidx/lifecycle/m;->k:Landroidx/lifecycle/t;

    .line 463
    .line 464
    iget-object v5, v3, Landroidx/lifecycle/t;->d:Landroidx/lifecycle/k;

    .line 465
    .line 466
    sget-object v6, Landroidx/lifecycle/k;->l:Landroidx/lifecycle/k;

    .line 467
    .line 468
    invoke-virtual {v5, v6}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 469
    .line 470
    .line 471
    move-result v5

    .line 472
    if-ltz v5, :cond_f

    .line 473
    .line 474
    invoke-virtual {v3, v4}, Landroidx/lifecycle/t;->a(Landroidx/lifecycle/q;)V

    .line 475
    .line 476
    .line 477
    goto :goto_9

    .line 478
    :cond_f
    invoke-interface {v0}, Lf7/s;->g()Lr6/i;

    .line 479
    .line 480
    .line 481
    move-result-object v0

    .line 482
    sget-object v3, Lf7/r;->l:Lf7/r;

    .line 483
    .line 484
    invoke-interface {v0, v3}, Lr6/i;->e(Lr6/h;)Lr6/g;

    .line 485
    .line 486
    .line 487
    move-result-object v0

    .line 488
    check-cast v0, Lf7/s0;

    .line 489
    .line 490
    if-eqz v0, :cond_10

    .line 491
    .line 492
    const/4 v3, 0x0

    .line 493
    invoke-interface {v0, v3}, Lf7/s0;->c(Ljava/util/concurrent/CancellationException;)V

    .line 494
    .line 495
    .line 496
    :cond_10
    :goto_9
    return-object v2

    .line 497
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
