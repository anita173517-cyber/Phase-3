.class public final La1/x;
.super La1/n;
.source "SourceFile"
