.class public interface abstract La1/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv0/l;


# virtual methods
.method public abstract B(La1/q;)J
.end method

.method public abstract close()V
.end method

.method public abstract j(La1/h0;)V
.end method

.method public abstract l()Ljava/util/Map;
.end method

.method public abstract w()Landroid/net/Uri;
.end method
