.class public final La1/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lm1/j;


# instance fields
.field public final k:Landroid/content/Context;

.field public l:I


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 0

    .line 1
    packed-switch p2, :pswitch_data_0

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, La1/l;->k:Landroid/content/Context;

    .line 8
    .line 9
    const/4 p1, -0x1

    .line 10
    iput p1, p0, La1/l;->l:I

    .line 11
    .line 12
    return-void

    .line 13
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, La1/l;->k:Landroid/content/Context;

    .line 17
    .line 18
    const/4 p1, 0x0

    .line 19
    iput p1, p0, La1/l;->l:I

    .line 20
    .line 21
    return-void

    .line 22
    nop

    .line 23
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public p(Le6/q;)Lm1/k;
    .locals 6

    .line 1
    iget v0, p0, La1/l;->l:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eq v0, v1, :cond_2

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 9
    .line 10
    const/16 v2, 0x1f

    .line 11
    .line 12
    if-lt v0, v2, :cond_0

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_0
    iget-object v2, p0, La1/l;->k:Landroid/content/Context;

    .line 16
    .line 17
    if-eqz v2, :cond_1

    .line 18
    .line 19
    const/16 v3, 0x1c

    .line 20
    .line 21
    if-lt v0, v3, :cond_1

    .line 22
    .line 23
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    const-string v2, "com.amazon.hardware.tv_screen"

    .line 28
    .line 29
    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    if-eqz v0, :cond_1

    .line 34
    .line 35
    goto :goto_0

    .line 36
    :cond_1
    new-instance v0, Li1/n;

    .line 37
    .line 38
    const/16 v1, 0x14

    .line 39
    .line 40
    invoke-direct {v0, v1}, Li1/n;-><init>(I)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0, p1}, Li1/n;->p(Le6/q;)Lm1/k;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    return-object p1

    .line 48
    :cond_2
    :goto_0
    iget-object v0, p1, Le6/q;->d:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v0, Lv0/t;

    .line 51
    .line 52
    iget-object v0, v0, Lv0/t;->p:Ljava/lang/String;

    .line 53
    .line 54
    invoke-static {v0}, Lv0/q0;->i(Ljava/lang/String;)I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    new-instance v2, Ljava/lang/StringBuilder;

    .line 59
    .line 60
    const-string v3, "Creating an asynchronous MediaCodec adapter for track type "

    .line 61
    .line 62
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    invoke-static {v0}, Ly0/k0;->L(I)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v2

    .line 76
    const-string v3, "DMCodecAdapterFactory"

    .line 77
    .line 78
    invoke-static {v3, v2}, Ly0/a;->g(Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    new-instance v2, Lh5/u;

    .line 82
    .line 83
    new-instance v3, Lm1/c;

    .line 84
    .line 85
    const/4 v4, 0x0

    .line 86
    invoke-direct {v3, v0, v4}, Lm1/c;-><init>(II)V

    .line 87
    .line 88
    .line 89
    new-instance v4, Lm1/c;

    .line 90
    .line 91
    const/4 v5, 0x1

    .line 92
    invoke-direct {v4, v0, v5}, Lm1/c;-><init>(II)V

    .line 93
    .line 94
    .line 95
    invoke-direct {v2, v3, v4}, Lh5/u;-><init>(Lm1/c;Lm1/c;)V

    .line 96
    .line 97
    .line 98
    iput-boolean v1, v2, Lh5/u;->l:Z

    .line 99
    .line 100
    invoke-virtual {v2, p1}, Lh5/u;->b(Le6/q;)Lk3/a4;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    return-object p1
.end method
